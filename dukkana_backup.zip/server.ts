import 'dotenv/config';
import http from 'http';
import express from 'express';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';
import { ADMIN_PHONE_E164, ADMIN_PHONE_LOCAL } from './src/types/index';
import { validateIraqiPhone } from './src/utils/phoneAuth';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json());

// Server-side in-memory secure stores (Server-Authoritative Database)
interface ServerUser {
  id: string;
  phone: string;
  displayName: string;
  role: 'customer' | 'merchant' | 'admin';
  governorate?: string;
  merchantStoreId?: string;
  createdAt: string;
  status: 'active' | 'suspended';
  passwordHash?: string;
  passwordSalt?: string;
}

interface ServerSession {
  token: string;
  userId: string;
  phone: string;
  role: 'customer' | 'merchant' | 'admin';
  createdAt: number;
  expiresAt: number;
}

interface ServerOTPSession {
  phone: string;
  code: string;
  expiresAt: number;
  attemptsRemaining: number;
}

const serverUsers = new Map<string, ServerUser>();
const serverSessions = new Map<string, ServerSession>();
const serverOTPs = new Map<string, ServerOTPSession>();

interface ServerResetToken {
  phone: string;
  expiresAt: number;
}
const serverResetTokens = new Map<string, ServerResetToken>();

// ==========================================
// Password Hashing & Security Helpers
// ==========================================
function hashPassword(password: string): { salt: string; hash: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return { salt, hash };
}

function verifyPassword(password: string, salt: string, expectedHash: string): boolean {
  try {
    const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    const hashBuf = Buffer.from(hash, 'hex');
    const expBuf = Buffer.from(expectedHash, 'hex');
    if (hashBuf.length !== expBuf.length) return false;
    return crypto.timingSafeEqual(hashBuf, expBuf);
  } catch {
    return false;
  }
}

function sanitizeUser(user: ServerUser): Omit<ServerUser, 'passwordHash' | 'passwordSalt'> & { hasPassword: boolean } {
  const { passwordHash, passwordSalt, ...rest } = user;
  return {
    ...rest,
    hasPassword: Boolean(passwordHash && passwordSalt),
  };
}

// Invalidate all active sessions for a given phone (e.g. after password reset)
function invalidateUserSessions(phone: string): void {
  for (const [token, session] of serverSessions.entries()) {
    if (session.phone === phone) {
      serverSessions.delete(token);
    }
  }
}

// ==========================================
// Rate Limiting (Brute-Force & Flood Protection)
// ==========================================
// Failed login tracking: Map<phone, { failedCount: number; lockedUntil: number }>
const loginAttempts = new Map<string, { failedCount: number; lockedUntil: number }>();

// OTP rate limit tracking: Map<phone, { lastRequestedAt: number; countInWindow: number; windowStart: number }>
const otpRateLimits = new Map<string, { lastRequestedAt: number; countInWindow: number; windowStart: number }>();

function checkLoginRateLimit(phone: string): { allowed: boolean; remainingLockoutSeconds?: number } {
  const record = loginAttempts.get(phone);
  if (!record) return { allowed: true };
  const now = Date.now();
  if (record.lockedUntil > now) {
    const remaining = Math.ceil((record.lockedUntil - now) / 1000);
    return { allowed: false, remainingLockoutSeconds: remaining };
  }
  if (record.lockedUntil <= now && record.failedCount >= 5) {
    loginAttempts.delete(phone);
  }
  return { allowed: true };
}

function recordFailedLogin(phone: string): { lockedNow: boolean; remainingAttempts: number } {
  const now = Date.now();
  const record = loginAttempts.get(phone) || { failedCount: 0, lockedUntil: 0 };
  record.failedCount += 1;
  if (record.failedCount >= 5) {
    record.lockedUntil = now + 15 * 60 * 1000; // 15 minutes lockout
    loginAttempts.set(phone, record);
    return { lockedNow: true, remainingAttempts: 0 };
  }
  loginAttempts.set(phone, record);
  return { lockedNow: false, remainingAttempts: 5 - record.failedCount };
}

function resetFailedLogin(phone: string): void {
  loginAttempts.delete(phone);
}

function checkOTPRateLimit(phone: string): { allowed: boolean; waitSeconds?: number; reason?: string } {
  const now = Date.now();
  const record = otpRateLimits.get(phone);
  if (!record) {
    otpRateLimits.set(phone, { lastRequestedAt: now, countInWindow: 1, windowStart: now });
    return { allowed: true };
  }

  // Cooldown: 60 seconds
  const elapsedSinceLast = now - record.lastRequestedAt;
  if (elapsedSinceLast < 60 * 1000) {
    const wait = Math.ceil((60 * 1000 - elapsedSinceLast) / 1000);
    return { allowed: false, waitSeconds: wait, reason: `يرجى الانتظار ${wait} ثانية قبل طلب رمز جديد.` };
  }

  // Hourly limit: max 5 OTPs per 60 minutes
  if (now - record.windowStart > 60 * 60 * 1000) {
    record.windowStart = now;
    record.countInWindow = 1;
    record.lastRequestedAt = now;
    return { allowed: true };
  }

  if (record.countInWindow >= 5) {
    const wait = Math.ceil((60 * 60 * 1000 - (now - record.windowStart)) / 60000);
    return {
      allowed: false,
      reason: `تم تجاوز الحد الأقصى لطلبات رمز التحقق (5 طلبات خلال ساعة). يرجى المحاولة بعد ${wait} دقيقة.`,
    };
  }

  record.countInWindow += 1;
  record.lastRequestedAt = now;
  return { allowed: true };
}

// Seed demo users with hashed password ('123456') for smooth testing
const defaultDemoPass = hashPassword('123456');

// Seed verified merchant in server DB
serverUsers.set('+9647701112233', {
  id: 'usr_merch_1',
  phone: '+9647701112233',
  displayName: 'الحاج مهدي التميمي (تمور النخيل)',
  role: 'merchant',
  merchantStoreId: 'merch_dates_1',
  governorate: 'بغداد',
  createdAt: '2026-09-01T10:00:00Z',
  status: 'active',
  passwordSalt: defaultDemoPass.salt,
  passwordHash: defaultDemoPass.hash,
});

// Seed merchant without password in server DB (usr_merch_5 - requires password creation)
serverUsers.set('+9647705556677', {
  id: 'usr_merch_5',
  phone: '+9647705556677',
  displayName: 'الأستاذ حيدر الرشيد (أزياء الرشيد)',
  role: 'merchant',
  merchantStoreId: 'merch_fashion_5',
  governorate: 'بغداد',
  createdAt: '2026-09-18T10:00:00Z',
  status: 'active',
});

// Seed demo customer in server DB
serverUsers.set('+9647701234567', {
  id: 'usr_customer_demo',
  phone: '+9647701234567',
  displayName: 'علي كريم الربيعي',
  role: 'customer',
  governorate: 'بغداد',
  createdAt: '2026-09-25T11:00:00Z',
  status: 'active',
  passwordSalt: defaultDemoPass.salt,
  passwordHash: defaultDemoPass.hash,
});

// Seed canonical Admin account in server DB with default password ('123456')
serverUsers.set(ADMIN_PHONE_E164, {
  id: 'usr_admin',
  phone: ADMIN_PHONE_E164,
  displayName: 'مدير منصة دكانة الرئيسي',
  role: 'admin',
  governorate: 'بغداد',
  createdAt: '2026-09-01T10:00:00Z',
  status: 'active',
  passwordSalt: defaultDemoPass.salt,
  passwordHash: defaultDemoPass.hash,
});

// Helper: generate random session token
function generateToken(): string {
  return `duk_sec_${Date.now()}_${Math.random().toString(36).substring(2, 12)}`;
}

// ==========================================
// Real SMS Dispatcher Engine (Official OTPIQ Gateway)
// Endpoint: POST https://api.otpiq.com/api/sms
// Authentication: Bearer OTPIQ_API_KEY
// ==========================================
async function dispatchOtpiqSMS(
  normalizedE164: string,
  code: string,
  customMessage?: string
): Promise<{ success: boolean; error?: string; provider?: string; smsId?: string; remainingCredit?: number }> {
  const rawApiKey = process.env.OTPIQ_API_KEY;

  if (!rawApiKey || !rawApiKey.trim()) {
    return {
      success: false,
      error:
        'خدمة إرسال SMS الحقيقية عبر OTPIQ غير مربوطة حالياً. لم يتم إدخال مفتاح OTPIQ_API_KEY في متغيرات البيئة.',
      provider: 'otpiq',
    };
  }

  // Sanitize API key (strip accidental quotes or excess whitespace)
  const apiKey = rawApiKey.trim().replace(/^['"]|['"]$/g, '');

  // Iraqi Phone Number Normalization for OTPIQ:
  // Must be clean numeric string without spaces or symbols (e.g. '9647862214922')
  const phoneNumber = normalizedE164.replace(/\D/g, '');
  const cleanCode = String(code).trim();
  const messageText =
    customMessage ||
    `رمز التحقق الخاص بك في تطبيق دكانة هو: ${cleanCode}. لا تشارك هذا الرمز مع أي شخص حفاظاً على أمان حسابك.`;

  try {
    const response = await fetch('https://api.otpiq.com/api/sms', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        phoneNumber,
        smsType: 'verification',
        verificationCode: cleanCode,
        message: messageText,
      }),
    });

    const responseText = await response.text();
    let responseData: any = null;
    try {
      responseData = JSON.parse(responseText);
    } catch {
      responseData = { raw: responseText };
    }

    if (!response.ok) {
      // Extract the actual error message from OTPIQ API response (e.g. responseData.error or responseData.message)
      const errMsg =
        responseData?.error ||
        responseData?.message ||
        responseData?.msg ||
        (typeof responseData?.raw === 'string' && responseData.raw ? responseData.raw : null) ||
        `خطأ من خادم OTPIQ (رمز الحالة: ${response.status})`;
      return {
        success: false,
        error: `فشل إرسال رسالة SMS عبر OTPIQ: ${errMsg}`,
        provider: 'otpiq',
      };
    }

    // Check if provider payload itself indicates failure
    if (
      responseData &&
      (responseData.success === false ||
        responseData.status === 'failed' ||
        responseData.status === 'error' ||
        Boolean(responseData.error))
    ) {
      return {
        success: false,
        error: `فشل الإرسال من مزود OTPIQ: ${
          responseData.error || responseData.message || 'فشلت معالجة الطلب'
        }`,
        provider: 'otpiq',
      };
    }

    // Check account balance coverage
    if (responseData && responseData.canCover === false) {
      return {
        success: false,
        error: 'رصيد حساب OTPIQ غير كافٍ لإتمام إرسال رسالة SMS.',
        provider: 'otpiq',
      };
    }

    return {
      success: true,
      provider: 'otpiq',
      smsId: responseData?.smsId,
      remainingCredit: responseData?.remainingCredit,
    };
  } catch (err: any) {
    return {
      success: false,
      error: `فشل الاتصال بخدمة OTPIQ: ${err?.message || 'تعذر الوصول إلى مزود الخدمة'}`,
      provider: 'otpiq',
    };
  }
}

// ==========================================
// 1. API: Health Check & SMS Provider Status
// ==========================================
app.get('/api/health', (req, res) => {
  const isOtpiqSet = !!(process.env.OTPIQ_API_KEY && process.env.OTPIQ_API_KEY.trim());
  res.json({
    status: 'ok',
    serverTime: new Date().toISOString(),
    smsProvider: isOtpiqSet ? 'otpiq' : 'not_configured',
  });
});

// ==========================================
// 2. API: Request OTP (Server-Side with Real Dispatch)
// ==========================================
app.post('/api/auth/request-otp', async (req, res) => {
  const { phone } = req.body;
  const validation = validateIraqiPhone(phone);
  if (!validation.isValid) {
    return res.status(400).json({ success: false, message: validation.errorMessage || 'رقم هاتف غير صالح.' });
  }

  const normalized = validation.normalizedE164; // Strictly +9647XXXXXXXXX (no duplicate country code or leading 0)
  const code = Math.floor(100000 + Math.random() * 900000).toString();

  const dispatchResult = await dispatchOtpiqSMS(normalized, code);

  if (!dispatchResult.success) {
    let friendlyMessage = dispatchResult.error || 'فشل إرسال رمز التحقق عبر مزود SMS.';
    if (friendlyMessage.includes('trial mode') || friendlyMessage.includes('own phone number')) {
      friendlyMessage =
        'تنبيه من مزود OTPIQ: الحساب حالياً في الوضع التجريبي (Trial Mode) ويسمح بإرسال رسائل SMS فقط إلى رقم الهاتف المسجل في حساب OTPIQ (07862214922). لتفعيل إرسال الرسائل لجميع أرقام الزبائن والتجار، يرجى تفعيل الرصيد في حسابك على OTPIQ.';
    }

    return res.status(400).json({
      success: false,
      smsConfigured: Boolean(process.env.OTPIQ_API_KEY),
      normalizedPhone: normalized,
      message: friendlyMessage,
      rawError: dispatchResult.error,
    });
  }

  serverOTPs.set(normalized, {
    phone: normalized,
    code,
    expiresAt: Date.now() + 5 * 60 * 1000,
    attemptsRemaining: 3,
  });

  // Never return the OTP code in the response
  res.json({
    success: true,
    smsConfigured: true,
    message: `تم إرسال رمز التحقق بنجاح إلى الرقم ${validation.localDisplay} (${normalized}) في رسالة SMS حقيقية عبر OTPIQ.`,
  });
});

// ==========================================
// 3. API: Verify OTP Only (Issues short-lived reset/register token)
// ==========================================
app.post('/api/auth/verify-otp', (req, res) => {
  const { phone, otpCode } = req.body;
  const validation = validateIraqiPhone(phone);
  if (!validation.isValid) {
    return res.status(400).json({ success: false, message: validation.errorMessage || 'رقم هاتف غير صالح.' });
  }

  const normalized = validation.normalizedE164;
  const session = serverOTPs.get(normalized);

  if (!session) {
    return res.status(400).json({
      success: false,
      message: 'لم يتم العثور على طلب رمز تحقق نشط أو انتهت صلاحيته. يرجى طلب رمز جديد.',
    });
  }

  if (Date.now() > session.expiresAt) {
    serverOTPs.delete(normalized);
    return res.status(400).json({
      success: false,
      message: 'انتهت صلاحية رمز التحقق (5 دقائق). يرجى طلب رمز جديد.',
    });
  }

  const cleanEntered = (otpCode || '').toString().trim().replace(/\D/g, '');
  if (cleanEntered !== session.code) {
    session.attemptsRemaining -= 1;
    if (session.attemptsRemaining <= 0) {
      serverOTPs.delete(normalized);
      return res.status(400).json({
        success: false,
        message: 'تم استنفاد كافة المحاولات المتاحة لهذا الرمز (3 محاولات). يرجى طلب رمز جديد.',
      });
    }
    return res.status(400).json({
      success: false,
      message: `رمز التحقق غير صحيح. متبقي لديك ${session.attemptsRemaining} محاولات.`,
      attemptsRemaining: session.attemptsRemaining,
    });
  }

  // OTP verified successfully
  serverOTPs.delete(normalized);

  // Generate a verified token valid for 15 minutes for password creation/reset
  const resetToken = `rst_${Date.now()}_${crypto.randomBytes(16).toString('hex')}`;
  serverResetTokens.set(resetToken, {
    phone: normalized,
    expiresAt: Date.now() + 15 * 60 * 1000,
  });

  const existingUser = serverUsers.get(normalized);
  const hasPassword = Boolean(existingUser && existingUser.passwordHash && existingUser.passwordSalt);

  let token: string | undefined = undefined;
  if (existingUser && hasPassword) {
    token = generateToken();
    serverSessions.set(token, {
      token,
      userId: existingUser.id,
      phone: normalized,
      role: existingUser.role,
      createdAt: Date.now(),
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    });
  }

  res.json({
    success: true,
    message: existingUser && hasPassword
      ? (existingUser.role === 'admin'
        ? 'تم التحقق بنجاح. أهلاً بك في لوحة الإدارة الرئيسية لمنصة دكانة.'
        : 'تم التحقق وتسجيل الدخول بنجاح.')
      : 'تم التحقق من رمز OTP بنجاح.',
    resetToken,
    userExists: Boolean(existingUser),
    hasPassword,
    user: existingUser ? sanitizeUser(existingUser) : undefined,
    token,
  });
});

// ==========================================
// 4. API: Login with Phone & Password (Direct, No OTP sent)
// ==========================================
app.post('/api/auth/login-password', (req, res) => {
  const { phone, password } = req.body;
  const validation = validateIraqiPhone(phone);
  if (!validation.isValid) {
    return res.status(400).json({ success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح.' });
  }

  const normalized = validation.normalizedE164;

  // Rate Limiting Check (5 failed attempts -> 15 min lock)
  const limit = checkLoginRateLimit(normalized);
  if (!limit.allowed) {
    return res.status(429).json({
      success: false,
      message: `تم قفل محاولات تسجيل الدخول مؤقتاً لتكرار الخطأ. يرجى المحاولة بعد ${limit.remainingLockoutSeconds} ثانية أو استخدام "نسيت كلمة المرور".`,
      remainingLockoutSeconds: limit.remainingLockoutSeconds,
    });
  }

  if (!password || typeof password !== 'string') {
    return res.status(400).json({ success: false, message: 'يرجى إدخال كلمة المرور.' });
  }

  let user = serverUsers.get(normalized);

  // If user does not exist in server users
  if (!user || user.status === 'suspended') {
    const fail = recordFailedLogin(normalized);
    if (fail.lockedNow) {
      return res.status(429).json({
        success: false,
        message: 'تم قفل الحساب مؤقتاً لمدة 15 دقيقة بعد 5 محاولات خاطئة. يرجى استخدام "نسيت كلمة المرور".',
      });
    }
    // Uniform safe Arabic error without disclosing registration existence
    return res.status(401).json({
      success: false,
      message: 'رقم الهاتف أو كلمة المرور غير صحيحة.',
      remainingAttempts: fail.remainingAttempts,
    });
  }

  // If user exists but hasn't set up a password yet
  if (!user.passwordHash || !user.passwordSalt) {
    return res.status(200).json({
      success: false,
      requiresPasswordSetup: true,
      message: 'لم يتم تعيين كلمة مرور لهذا الحساب بعد. يرجى التحقق برمز OTP لإنشاء كلمة مرور جديدة.',
    });
  }

  // Verify hashed password safely
  const isValid = verifyPassword(password, user.passwordSalt, user.passwordHash);
  if (!isValid) {
    const fail = recordFailedLogin(normalized);
    if (fail.lockedNow) {
      return res.status(429).json({
        success: false,
        message: 'تم قفل الحساب مؤقتاً لمدة 15 دقيقة بعد 5 محاولات خاطئة. يرجى استخدام "نسيت كلمة المرور".',
      });
    }
    return res.status(401).json({
      success: false,
      message: 'رقم الهاتف أو كلمة المرور غير صحيحة.',
      remainingAttempts: fail.remainingAttempts,
    });
  }

  // Password matches: reset failed attempts
  resetFailedLogin(normalized);

  // Issue session token
  const token = generateToken();
  serverSessions.set(token, {
    token,
    userId: user.id,
    phone: normalized,
    role: user.role,
    createdAt: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });

  res.json({
    success: true,
    message: user.role === 'admin'
      ? 'تم التحقق بنجاح. أهلاً بك في لوحة الإدارة الرئيسية لمنصة دكانة.'
      : 'تم تسجيل الدخول بنجاح.',
    user: sanitizeUser(user),
    token,
  });
});

// ==========================================
// 5. API: Reset / Set Password (Using Verified Reset Token)
// Also available at /api/auth/set-password
// ==========================================
app.post(['/api/auth/reset-password', '/api/auth/set-password'], (req, res) => {
  const { phone, resetToken, newPassword } = req.body;
  const validation = validateIraqiPhone(phone);
  if (!validation.isValid) {
    return res.status(400).json({ success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح.' });
  }

  const normalized = validation.normalizedE164;

  if (!resetToken) {
    return res.status(400).json({ success: false, message: 'رمز التحقق مفقود أو غير صالح.' });
  }

  const tokenData = serverResetTokens.get(resetToken);
  if (!tokenData || tokenData.phone !== normalized || Date.now() > tokenData.expiresAt) {
    serverResetTokens.delete(resetToken);
    return res.status(400).json({
      success: false,
      message: 'انتهت صلاحية جلسة إعادة تعيين كلمة المرور. يرجى التحقق برمز OTP جديد.',
    });
  }

  if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 6) {
    return res.status(400).json({
      success: false,
      message: 'يجب ألا تقل كلمة المرور عن 6 أحرف أو أرقام.',
    });
  }

  // Token is valid: remove it so it cannot be reused
  serverResetTokens.delete(resetToken);

  let user = serverUsers.get(normalized);
  if (!user) {
    const isMasterAdmin = normalized === ADMIN_PHONE_E164;
    user = {
      id: isMasterAdmin ? 'usr_admin' : `usr_${Date.now()}`,
      phone: normalized,
      displayName: isMasterAdmin ? 'مدير منصة دكانة الرئيسي' : `مستخدم دكانة`,
      role: isMasterAdmin ? 'admin' : 'customer',
      governorate: 'بغداد',
      createdAt: new Date().toISOString(),
      status: 'active',
    };
    serverUsers.set(normalized, user);
  }

  // Strong password hash
  const { salt, hash } = hashPassword(newPassword);
  user.passwordSalt = salt;
  user.passwordHash = hash;

  // Invalidate any old sessions after password reset
  invalidateUserSessions(normalized);

  // Clear any failed login rate limit lockouts
  resetFailedLogin(normalized);

  // Issue new session token
  const token = generateToken();
  serverSessions.set(token, {
    token,
    userId: user.id,
    phone: normalized,
    role: user.role,
    createdAt: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });

  res.json({
    success: true,
    message: 'تم تعيين كلمة المرور بنجاح وتسجيل دخولك إلى الحساب.',
    user: sanitizeUser(user),
    token,
  });
});

// ==========================================
// 6. API: Verify OTP & Register New User with Password
// Also available at /api/auth/complete-registration
// ==========================================
app.post(['/api/auth/register', '/api/auth/complete-registration'], (req, res) => {
  const {
    accountType,
    phone,
    otpCode,
    resetToken,
    password,
    fullName,
    governorate,
    storeName,
    storeDescription,
    address,
  } = req.body;

  const validation = validateIraqiPhone(phone);
  if (!validation.isValid) {
    return res.status(400).json({ success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح.' });
  }

  const normalized = validation.normalizedE164;
  const isAdminPhone = normalized === ADMIN_PHONE_E164;

  // Verification via resetToken OR direct otpCode
  let isVerified = false;
  if (resetToken) {
    const tokenData = serverResetTokens.get(resetToken);
    if (tokenData && tokenData.phone === normalized && Date.now() <= tokenData.expiresAt) {
      isVerified = true;
      serverResetTokens.delete(resetToken);
    }
  }

  if (!isVerified && otpCode) {
    const cleanEntered = (otpCode || '').toString().trim().replace(/\D/g, '');
    const session = serverOTPs.get(normalized);
    if (session && cleanEntered === session.code && Date.now() <= session.expiresAt) {
      isVerified = true;
      serverOTPs.delete(normalized);
    }
  }

  if (!isVerified) {
    return res.status(401).json({
      success: false,
      message: 'رمز التحقق غير صحيح أو منتهي الصلاحية. يرجى طلب رمز جديد.',
    });
  }

  // Password validation & hashing
  if (!password || typeof password !== 'string' || password.length < 6) {
    return res.status(400).json({
      success: false,
      message: 'يجب أن تحتوي كلمة المرور على 6 أحرف أو أرقام على الأقل.',
    });
  }

  const { salt, hash } = hashPassword(password);

  // SERVER-SIDE STRICT ROLE AUTHORIZATION:
  // ONLY ADMIN_PHONE_E164 can be granted 'admin' role
  if (accountType === 'admin_staff') {
    if (!isAdminPhone) {
      return res.status(403).json({
        success: false,
        message: 'تم رفض إنشاء الحساب من جهة الخادم: رقم الهاتف هذا غير مصرح له بصلاحيات الإدارة. رقم المدير المعتمد الوحيد هو 07862214922.',
      });
    }
  }

  const assignedRole: 'customer' | 'merchant' | 'admin' =
    accountType === 'admin_staff' && isAdminPhone
      ? 'admin'
      : accountType === 'merchant'
      ? 'merchant'
      : 'customer';

  const userId = assignedRole === 'admin' ? 'usr_admin' : `usr_${Date.now()}`;
  const newUser: ServerUser = {
    id: userId,
    phone: normalized,
    displayName: (fullName || '').trim() || (assignedRole === 'admin' ? 'مدير منصة دكانة' : 'مستخدم دكانة'),
    role: assignedRole,
    governorate: governorate || 'بغداد',
    merchantStoreId: assignedRole === 'merchant' ? `merch_${Date.now()}` : undefined,
    createdAt: new Date().toISOString(),
    status: 'active',
    passwordSalt: salt,
    passwordHash: hash,
  };

  serverUsers.set(normalized, newUser);

  // Issue session token
  const token = generateToken();
  serverSessions.set(token, {
    token,
    userId: newUser.id,
    phone: normalized,
    role: assignedRole,
    createdAt: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });

  res.json({
    success: true,
    message: assignedRole === 'admin'
      ? 'تم التحقق بنجاح وتفعيل صلاحية المدير الرسمي وتعيين كلمة المرور.'
      : 'تم إنشاء الحساب وتعيين كلمة المرور بنجاح.',
    user: sanitizeUser(newUser),
    token,
  });
});

// ==========================================
// 7. API: Verify OTP & Login (Or Unified Auth Dispatcher)
// ==========================================
app.post('/api/auth/login', (req, res) => {
  const { phone, otpCode, password } = req.body;

  // If password provided, dispatch directly to password flow
  if (password && typeof password === 'string') {
    const validation = validateIraqiPhone(phone);
    if (!validation.isValid) {
      return res.status(400).json({ success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح.' });
    }
    const normalized = validation.normalizedE164;
    const limit = checkLoginRateLimit(normalized);
    if (!limit.allowed) {
      return res.status(429).json({
        success: false,
        message: `تم قفل محاولات تسجيل الدخول مؤقتاً لتكرار الخطأ. يرجى المحاولة بعد ${limit.remainingLockoutSeconds} ثانية أو استخدام "نسيت كلمة المرور".`,
      });
    }
    let user = serverUsers.get(normalized);
    if (!user || !user.passwordSalt || !user.passwordHash || user.status === 'suspended') {
      const fail = recordFailedLogin(normalized);
      return res.status(401).json({
        success: false,
        message: 'رقم الهاتف أو كلمة المرور غير صحيحة.',
        remainingAttempts: fail.remainingAttempts,
      });
    }
    const isValid = verifyPassword(password, user.passwordSalt, user.passwordHash);
    if (!isValid) {
      const fail = recordFailedLogin(normalized);
      return res.status(401).json({
        success: false,
        message: 'رقم الهاتف أو كلمة المرور غير صحيحة.',
        remainingAttempts: fail.remainingAttempts,
      });
    }
    resetFailedLogin(normalized);
    const token = generateToken();
    serverSessions.set(token, {
      token,
      userId: user.id,
      phone: normalized,
      role: user.role,
      createdAt: Date.now(),
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    });
    return res.json({
      success: true,
      message: 'تم تسجيل الدخول بنجاح.',
      user: sanitizeUser(user),
      token,
    });
  }

  // Otherwise, verify OTP flow
  const validation = validateIraqiPhone(phone);
  if (!validation.isValid) {
    return res.status(400).json({ success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح.' });
  }

  const normalized = validation.normalizedE164;
  const isAdminPhone = normalized === ADMIN_PHONE_E164;

  const cleanEntered = (otpCode || '').toString().trim().replace(/\D/g, '');
  const session = serverOTPs.get(normalized);
  const isValidOTP = !!session && cleanEntered === session.code && Date.now() <= session.expiresAt;

  if (!isValidOTP) {
    return res.status(401).json({ success: false, message: 'رمز التحقق غير صحيح أو منتهي الصلاحية.' });
  }
  serverOTPs.delete(normalized);

  // Retrieve user or instantiate canonical admin if matching admin phone
  let user = serverUsers.get(normalized);
  if (!user && isAdminPhone) {
    const adminPass = hashPassword('123456');
    user = {
      id: 'usr_admin',
      phone: ADMIN_PHONE_E164,
      displayName: 'مدير منصة دكانة الرئيسي',
      role: 'admin',
      governorate: 'بغداد',
      createdAt: new Date().toISOString(),
      status: 'active',
      passwordSalt: adminPass.salt,
      passwordHash: adminPass.hash,
    };
    serverUsers.set(ADMIN_PHONE_E164, user);
  }

  if (!user) {
    const resetToken = `rst_${Date.now()}_${crypto.randomBytes(16).toString('hex')}`;
    serverResetTokens.set(resetToken, {
      phone: normalized,
      expiresAt: Date.now() + 15 * 60 * 1000,
    });

    return res.json({
      success: true,
      requiresPasswordSetup: true,
      resetToken,
      message: 'تم التحقق بنجاح. يرجى إنشاء كلمة مرور لحسابك للمتابعة.',
    });
  }

  // Check if existing user does NOT have a password yet -> Force password creation
  if (!user.passwordHash || !user.passwordSalt) {
    const resetToken = `rst_${Date.now()}_${crypto.randomBytes(16).toString('hex')}`;
    serverResetTokens.set(resetToken, {
      phone: normalized,
      expiresAt: Date.now() + 15 * 60 * 1000,
    });

    return res.json({
      success: true,
      requiresPasswordSetup: true,
      resetToken,
      message: 'تم التحقق بنجاح. يرجى إنشاء كلمة مرور لحسابك للمتابعة.',
      user: sanitizeUser(user),
    });
  }

  // Issue session token
  const token = generateToken();
  serverSessions.set(token, {
    token,
    userId: user.id,
    phone: normalized,
    role: user.role,
    createdAt: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });

  res.json({
    success: true,
    message: isAdminPhone
      ? 'تم التحقق بنجاح. أهلاً بك في لوحة الإدارة الرئيسية لمنصة دكانة.'
      : 'تم تسجيل الدخول بنجاح.',
    user: sanitizeUser(user),
    token,
  });
});

// ==========================================
// 5. API: Server-Side Admin Access Verification Guard
// ==========================================
app.post('/api/admin/verify-access', (req, res) => {
  const authHeader = req.headers.authorization;
  const bearerToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : null;
  const token = bearerToken || req.body.token;
  const phone = req.body.phone;

  // 1. Strict Phone Check
  const validation = validateIraqiPhone(phone || '');
  if (!validation.isValid || validation.normalizedE164 !== ADMIN_PHONE_E164) {
    return res.status(403).json({
      authorized: false,
      error: 'رفض أمني من الخادم: رقم الهاتف غير مصرح له كمدير. لوحة الإدارة محصورة بالرقم المعتمد 07862214922.',
    });
  }

  // 2. Token Check if provided
  if (token) {
    const session = serverSessions.get(token);
    if (!session || session.phone !== ADMIN_PHONE_E164 || session.role !== 'admin') {
      return res.status(403).json({
        authorized: false,
        error: 'رفض أمني من الخادم: جلسة المدير غير صالحة أو منتهية الصلاحية.',
      });
    }
  }

  // Authorized
  res.json({
    authorized: true,
    role: 'admin',
    phone: ADMIN_PHONE_E164,
    serverVerifiedAt: new Date().toISOString(),
  });
});

// ==========================================
// Vite Integration (Dev) / Static Serving (Prod)
// ==========================================
async function startServer() {
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : {
          server: httpServer,
        },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`Dukkana Full-Stack Platform server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
