export type IraqiGovernorate =
  | 'بغداد'
  | 'البصرة'
  | 'نينوى'
  | 'أربيل'
  | 'الأنبار'
  | 'كركوك'
  | 'النجف'
  | 'كربلاء'
  | 'بابل'
  | 'واسط'
  | 'صلاح الدين'
  | 'ديالى'
  | 'ذي قار'
  | 'ميسان'
  | 'المثنى'
  | 'القادسية'
  | 'دهوك'
  | 'السليمانية';

export const ADMIN_PHONE_E164 = '+9647862214922';
export const ADMIN_PHONE_LOCAL = '07862214922';

export type UserRole = 'customer' | 'merchant' | 'admin' | 'support';

export type MerchantStatus = 'pending' | 'approved' | 'rejected' | 'suspended';

export type ProductApprovalStatus = 'pending' | 'approved' | 'rejected' | 'suspended';

export type OrderStatus =
  | 'new'              // طلب جديد
  | 'confirmed'        // تم تأكيد الطلب
  | 'preparing'        // قيد التجهيز
  | 'out_for_delivery' // خرج للتوصيل
  | 'delivered'        // تم التوصيل
  | 'cancelled';       // ملغي

export interface Address {
  id: string;
  governorate: IraqiGovernorate;
  cityOrDistrict: string;
  nearestLandmark: string;
  fullAddress: string;
  isDefault?: boolean;
}

export interface User {
  id: string;
  phone: string; // E.164: +9647XXXXXXXXX
  displayName: string;
  role: UserRole;
  governorate?: IraqiGovernorate;
  addresses: Address[];
  createdAt: string;
  status: 'active' | 'suspended' | 'deleted';
  merchantStoreId?: string;
  hasPassword?: boolean;
}

export interface MerchantStore {
  id: string;
  userId: string;
  storeName: string;
  description: string;
  governorate: IraqiGovernorate;
  phone: string;
  logoUrl?: string;
  status: MerchantStatus;
  rejectionReason?: string;
  commissionRate: number; // e.g. 5 means 5%
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  iconName?: string;
  displayOrder: number;
}

export interface Product {
  id: string;
  merchantId: string;
  storeName: string;
  name: string;
  description: string;
  price: number; // in IQD (الدينار العراقي)
  originalPrice?: number;
  discountPercent?: number; // e.g. 10, 30, 50
  finalPrice: number;
  categoryId: string;
  categoryName: string;
  imageUrl: string;
  inStock: boolean;
  approvalStatus: ProductApprovalStatus;
  rejectionReason?: string;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  unitPrice: number;
  quantity: number;
  totalPrice: number;
}

export interface OrderStatusHistoryItem {
  status: OrderStatus;
  timestamp: string;
  note?: string;
}

export interface Order {
  id: string; // DUK-XXXXXX
  customerId: string;
  customerName: string;
  customerPhone: string;
  recipientName: string;
  recipientPhone: string;
  governorate: IraqiGovernorate;
  detailedAddress: string;
  notes?: string;
  merchantId: string;
  storeName: string;
  items: OrderItem[];
  subtotal: number;
  discountTotal: number;
  deliveryFee: number;
  finalTotal: number;
  paymentMethod: 'cod'; // الدفع عند الاستلام فقط
  status: OrderStatus;
  statusHistory: OrderStatusHistoryItem[];
  commissionRate: number;
  commissionAmount: number; // calculated ONLY when status === 'delivered', 0 if cancelled
  createdAt: string;
  deliveredAt?: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  orderId: string;
  productId: string;
  productName: string;
  rating: number; // 1 to 5
  comment?: string;
  createdAt: string;
  status: 'published' | 'hidden' | 'deleted';
  isVerifiedPurchase: true; // Verified COD delivered order
}

export interface ReviewReport {
  id: string;
  reviewId: string;
  reporterUserId: string;
  reporterPhone: string;
  reason: 'inappropriate' | 'spam' | 'fake' | 'harassment' | 'offensive' | 'prohibited_item';
  details: string;
  status: 'pending' | 'reviewed' | 'dismissed' | 'action_taken';
  createdAt: string;
}

export interface SupportInquiry {
  id: string;
  senderName: string;
  senderPhone: string;
  subject: string;
  message: string;
  category: 'order' | 'merchant' | 'payment' | 'general' | 'complaint';
  status: 'new' | 'in_progress' | 'resolved';
  reply?: string;
  repliedAt?: string;
  createdAt: string;
}

export interface AppSettings {
  appName: string;
  defaultCommissionRate: number; // percentage, e.g. 5
  supportWhatsApp: string; // e.g. +9647701234567
  supportPhone: string;
  minOrderAmount: number;
  allowMerchantRegistration: boolean;
  termsLastUpdated: string;
}
