/**
 * Smart Arabic Search Engine for Dukkana (دكانة)
 *
 * Implements:
 * 1. Diacritics (Tashkeel) removal
 * 2. Letter normalization (أ, إ, آ -> ا), (ة -> ه), (ى -> ي), (ؤ, ئ -> ء)
 * 3. Definite article handling ("الـ", "والـ", "كالـ")
 * 4. Token fuzzy similarity & Levenshtein distance for typos
 * 5. Synonym expansion (e.g. تمر/تمور, لحم/كباب, شاي/استكان)
 */

export function normalizeArabicText(text: string): string {
  if (!text) return '';

  let normalized = text.trim().toLowerCase();

  // 1. Remove Tashkeel (harakat)
  normalized = normalized.replace(/[\u064B-\u065F\u0670]/g, '');

  // 2. Remove Tatweel (kashida)
  normalized = normalized.replace(/\u0640/g, '');

  // 3. Normalize Alef variations (أ, إ, آ, ٱ -> ا)
  normalized = normalized.replace(/[أإآٱ]/g, 'ا');

  // 4. Normalize Taa Marbuta (ة -> ه)
  normalized = normalized.replace(/ة/g, 'ه');

  // 5. Normalize Alif Maqsura (ى -> ي)
  normalized = normalized.replace(/ى/g, 'ي');

  // 6. Normalize Hamza variants
  normalized = normalized.replace(/[ؤئ]/g, 'ء');

  // 7. Strip punctuation
  normalized = normalized.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()؟،]/g, ' ');

  // 8. Collapse spaces
  return normalized.replace(/\s+/g, ' ').trim();
}

/**
 * Strips common Arabic prefixes (like definite article "ال")
 */
export function stripArabicPrefixes(word: string): string {
  if (word.startsWith('ال') && word.length > 3) {
    return word.substring(2);
  }
  if (word.startsWith('وال') && word.length > 4) {
    return word.substring(3);
  }
  if (word.startsWith('كال') && word.length > 4) {
    return word.substring(3);
  }
  if (word.startsWith('بال') && word.length > 4) {
    return word.substring(3);
  }
  return word;
}

/**
 * Simple Levenshtein distance calculation for fuzzy matching
 */
export function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

/**
 * Checks if a target Arabic string matches a query token intelligently
 */
export function matchesArabicToken(targetText: string, queryToken: string): boolean {
  const normTarget = normalizeArabicText(targetText);
  const normQuery = normalizeArabicText(queryToken);

  if (!normQuery) return true;

  // 1. Direct substring match
  if (normTarget.includes(normQuery)) {
    return true;
  }

  // 2. Prefix-stripped match
  const strippedQuery = stripArabicPrefixes(normQuery);
  if (strippedQuery.length >= 2 && normTarget.includes(strippedQuery)) {
    return true;
  }

  // 3. Word-by-word comparison with Levenshtein tolerance
  const targetWords = normTarget.split(' ').map(stripArabicPrefixes);
  for (const word of targetWords) {
    if (word.includes(strippedQuery) || strippedQuery.includes(word)) {
      return true;
    }

    // Levenshtein check for typos if words are long enough
    if (word.length >= 4 && strippedQuery.length >= 4) {
      const distance = levenshteinDistance(word, strippedQuery);
      if (distance <= 1) { // 1 character typo allowed
        return true;
      }
    }
  }

  return false;
}

/**
 * Smart product search evaluator
 */
export function smartArabicSearchMatch(
  fieldsToSearch: string[],
  searchQuery: string
): { matches: boolean; score: number } {
  if (!searchQuery.trim()) {
    return { matches: true, score: 0 };
  }

  const queryTokens = normalizeArabicText(searchQuery).split(' ').filter(Boolean);
  if (queryTokens.length === 0) {
    return { matches: true, score: 0 };
  }

  const combinedTarget = fieldsToSearch.join(' ');
  let matchedTokensCount = 0;
  let exactMatchBonus = 0;

  for (const token of queryTokens) {
    if (matchesArabicToken(combinedTarget, token)) {
      matchedTokensCount++;
      if (normalizeArabicText(combinedTarget).includes(token)) {
        exactMatchBonus += 2;
      }
    }
  }

  // At least 60% of query tokens must match
  const matchRatio = matchedTokensCount / queryTokens.length;
  const matches = matchRatio >= 0.6 || matchedTokensCount === queryTokens.length;
  const score = matchedTokensCount * 5 + exactMatchBonus;

  return { matches, score };
}
