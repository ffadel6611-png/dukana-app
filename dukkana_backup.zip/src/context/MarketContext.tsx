import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Category,
  MerchantStore,
  Order,
  Review,
  ReviewReport,
  AppSettings,
  CartItem,
  OrderStatus,
  IraqiGovernorate,
  MerchantStatus,
  ProductApprovalStatus,
  SupportInquiry,
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_MERCHANTS,
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_REVIEWS,
  INITIAL_SETTINGS,
  INITIAL_INQUIRIES,
} from '../data/initialData';
import { IRAQI_GOVERNORATES } from '../data/governorates';
import { smartArabicSearchMatch } from '../utils/arabicSearch';

interface SplitCheckoutData {
  recipientName: string;
  recipientPhone: string;
  governorate: IraqiGovernorate;
  detailedAddress: string;
  notes?: string;
}

interface MarketContextType {
  products: Product[];
  categories: Category[];
  merchants: MerchantStore[];
  orders: Order[];
  reviews: Review[];
  reports: ReviewReport[];
  settings: AppSettings;
  cart: CartItem[];
  selectedCategorySlug: string;
  searchQuery: string;
  selectedDiscount: number | null; // 10, 30, 50 or null
  selectedGovernorate: IraqiGovernorate | 'all';

  // Filters & Search
  setSearchQuery: (query: string) => void;
  setSelectedCategorySlug: (slug: string) => void;
  setSelectedDiscount: (discount: number | null) => void;
  setSelectedGovernorate: (gov: IraqiGovernorate | 'all') => void;
  getFilteredProductsForCustomer: () => Product[];

  // Cart Management
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  getCartGroupsByMerchant: () => { merchantId: string; storeName: string; items: CartItem[]; subtotal: number }[];
  getCartTotalCount: () => number;

  // Checkout (Split Orders by Merchant)
  executeSplitCheckout: (
    customerId: string,
    customerName: string,
    customerPhone: string,
    data: SplitCheckoutData
  ) => { success: boolean; createdOrders: Order[]; message: string };

  // Orders Management
  updateOrderStatus: (orderId: string, newStatus: OrderStatus, note?: string) => void;
  getCustomerOrders: (customerId: string) => Order[];
  getMerchantOrders: (merchantId: string) => Order[];

  // Product Management (Merchant & Admin)
  addProduct: (productData: Omit<Product, 'id' | 'createdAt' | 'approvalStatus'>) => void;
  updateProduct: (productId: string, updates: Partial<Product>) => void;
  deleteProduct: (productId: string) => void;
  setProductApproval: (productId: string, status: ProductApprovalStatus, reason?: string) => void;

  // Merchant Management
  registerMerchantStore: (storeData: Omit<MerchantStore, 'id' | 'createdAt' | 'status' | 'commissionRate'> & { id?: string; status?: MerchantStatus }) => MerchantStore;
  updateMerchantStore: (merchantId: string, updates: Partial<MerchantStore>) => void;
  setMerchantStatus: (merchantId: string, status: MerchantStatus, reason?: string) => void;

  // Category Management (Admin)
  addCategory: (name: string, description?: string) => void;
  updateCategory: (id: string, name: string, description?: string) => void;
  deleteCategory: (id: string) => void;

  // Reviews & UGC Moderation
  getProductReviews: (productId: string) => Review[];
  canUserReviewProduct: (userId: string, productId: string) => { canReview: boolean; orderId?: string; reason?: string };
  submitReview: (userId: string, userName: string, userPhone: string, productId: string, orderId: string, rating: number, comment?: string) => { success: boolean; message: string };
  reportReview: (reviewId: string, reporterUserId: string, reporterPhone: string, reason: ReviewReport['reason'], details: string) => { success: boolean; message: string };
  setReviewStatus: (reviewId: string, status: Review['status']) => void;
  resolveReport: (reportId: string, action: 'dismissed' | 'action_taken') => void;

  // Support Team Inquiries
  inquiries: SupportInquiry[];
  submitSupportInquiry: (
    senderName: string,
    senderPhone: string,
    subject: string,
    message: string,
    category: SupportInquiry['category']
  ) => { success: boolean; message: string };
  replySupportInquiry: (inquiryId: string, replyText: string) => void;

  // Settings (Admin)
  updateSettings: (newSettings: Partial<AppSettings>) => void;
}

const MarketContext = createContext<MarketContextType | undefined>(undefined);

const PRODUCTS_KEY = 'dukkana_products_db_v2';
const MERCHANTS_KEY = 'dukkana_merchants_db_v2';
const CATEGORIES_KEY = 'dukkana_categories_db_v2';
const ORDERS_KEY = 'dukkana_orders_db_v2';
const REVIEWS_KEY = 'dukkana_reviews_db_v2';
const REPORTS_KEY = 'dukkana_reports_db_v2';
const INQUIRIES_KEY = 'dukkana_inquiries_db_v2';
const SETTINGS_KEY = 'dukkana_settings_db_v2';
const CART_KEY = 'dukkana_cart_v2';

export const MarketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(PRODUCTS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [merchants, setMerchants] = useState<MerchantStore[]>(() => {
    const saved = localStorage.getItem(MERCHANTS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_MERCHANTS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem(CATEGORIES_KEY);
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(ORDERS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem(REVIEWS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [reports, setReports] = useState<ReviewReport[]>(() => {
    const saved = localStorage.getItem(REPORTS_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  const [inquiries, setInquiries] = useState<SupportInquiry[]>(() => {
    const saved = localStorage.getItem(INQUIRIES_KEY);
    return saved ? JSON.parse(saved) : INITIAL_INQUIRIES;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem(SETTINGS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem(CART_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedDiscount, setSelectedDiscount] = useState<number | null>(null);
  const [selectedGovernorate, setSelectedGovernorate] = useState<IraqiGovernorate | 'all'>('all');

  useEffect(() => {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(MERCHANTS_KEY, JSON.stringify(merchants));
  }, [merchants]);

  useEffect(() => {
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
  }, [reports]);

  useEffect(() => {
    localStorage.setItem(INQUIRIES_KEY, JSON.stringify(inquiries));
  }, [inquiries]);

  useEffect(() => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const getCartTotalCount = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  // Group items by Merchant for split multi-vendor order structure
  const getCartGroupsByMerchant = () => {
    const groupsMap = new Map<string, { merchantId: string; storeName: string; items: CartItem[]; subtotal: number }>();

    for (const item of cart) {
      const mId = item.product.merchantId;
      const existing = groupsMap.get(mId);
      const itemSubtotal = item.product.finalPrice * item.quantity;

      if (existing) {
        existing.items.push(item);
        existing.subtotal += itemSubtotal;
      } else {
        groupsMap.set(mId, {
          merchantId: mId,
          storeName: item.product.storeName,
          items: [item],
          subtotal: itemSubtotal,
        });
      }
    }

    return Array.from(groupsMap.values());
  };

  // Customer filtered products
  const getFilteredProductsForCustomer = () => {
    // Only approved products from approved merchants are visible to customers!
    const approvedMerchantIds = new Set(
      merchants.filter(m => m.status === 'approved').map(m => m.id)
    );

    let list = products.filter(
      p => p.approvalStatus === 'approved' && approvedMerchantIds.has(p.merchantId)
    );

    // Filter by governorate
    if (selectedGovernorate !== 'all') {
      const merchantsInGov = new Set(
        merchants.filter(m => m.governorate === selectedGovernorate).map(m => m.id)
      );
      list = list.filter(p => merchantsInGov.has(p.merchantId));
    }

    // Filter by category
    if (selectedCategorySlug !== 'all') {
      const cat = categories.find(c => c.slug === selectedCategorySlug);
      if (cat) {
        list = list.filter(p => p.categoryId === cat.id);
      }
    }

    // Filter by discount (10%, 30%, 50%)
    if (selectedDiscount !== null) {
      list = list.filter(p => (p.discountPercent || 0) >= selectedDiscount);
    }

    // Smart Arabic Search
    if (searchQuery.trim()) {
      list = list
        .map(product => {
          const searchFields = [
            product.name,
            product.description,
            product.storeName,
            product.categoryName,
          ];
          const matchResult = smartArabicSearchMatch(searchFields, searchQuery);
          return { product, matchResult };
        })
        .filter(item => item.matchResult.matches)
        .sort((a, b) => b.matchResult.score - a.matchResult.score)
        .map(item => item.product);
    }

    return list;
  };

  // Execute Split Checkout
  const executeSplitCheckout = (
    customerId: string,
    customerName: string,
    customerPhone: string,
    data: SplitCheckoutData
  ) => {
    if (cart.length === 0) {
      return { success: false, createdOrders: [], message: 'السلة فارغة.' };
    }

    const merchantGroups = getCartGroupsByMerchant();
    const createdOrders: Order[] = [];
    const now = new Date().toISOString();

    for (const group of merchantGroups) {
      const orderNumber = `DUK-${Math.floor(100000 + Math.random() * 900000)}`;
      const merchant = merchants.find(m => m.id === group.merchantId);
      const commissionRate = merchant ? merchant.commissionRate : settings.defaultCommissionRate;
      const govDetail = IRAQI_GOVERNORATES.find(g => g.id === data.governorate);
      const deliveryFee = govDetail ? govDetail.deliveryFee : 5000;
      const finalTotal = group.subtotal + deliveryFee;

      const newOrder: Order = {
        id: orderNumber,
        customerId,
        customerName,
        customerPhone,
        recipientName: data.recipientName,
        recipientPhone: data.recipientPhone,
        governorate: data.governorate,
        detailedAddress: data.detailedAddress,
        notes: data.notes,
        merchantId: group.merchantId,
        storeName: group.storeName,
        items: group.items.map(item => ({
          productId: item.product.id,
          productName: item.product.name,
          productImage: item.product.imageUrl,
          unitPrice: item.product.finalPrice,
          quantity: item.quantity,
          totalPrice: item.product.finalPrice * item.quantity,
        })),
        subtotal: group.subtotal,
        discountTotal: group.items.reduce((acc, item) => {
          const orig = item.product.originalPrice || item.product.finalPrice;
          return acc + (orig - item.product.finalPrice) * item.quantity;
        }, 0),
        deliveryFee,
        finalTotal,
        paymentMethod: 'cod',
        status: 'new',
        statusHistory: [
          { status: 'new', timestamp: now, note: 'تم إنشاء الطلب بنجاح وهو بانتظار تأكيد التاجر' },
        ],
        commissionRate,
        commissionAmount: 0, // Zero until delivered!
        createdAt: now,
      };

      createdOrders.push(newOrder);
    }

    setOrders(prev => [...createdOrders, ...prev]);
    clearCart();

    return {
      success: true,
      createdOrders,
      message: `تم إنشاء ${createdOrders.length} ${createdOrders.length > 1 ? 'طلبات مستقلة' : 'طلب'} بنجاح للدفع عند الاستلام.`,
    };
  };

  // Update Order Status
  const updateOrderStatus = (orderId: string, newStatus: OrderStatus, note?: string) => {
    const now = new Date().toISOString();
    setOrders(prev =>
      prev.map(ord => {
        if (ord.id !== orderId) return ord;

        // Platform Commission Calculation Rule:
        // Calculated strictly upon 'delivered' (تم التوصيل), 0 if cancelled (ملغي)
        let commissionAmount = ord.commissionAmount;
        let deliveredAt = ord.deliveredAt;

        if (newStatus === 'delivered') {
          commissionAmount = Math.round(ord.subtotal * (ord.commissionRate / 100));
          deliveredAt = now;
        } else if (newStatus === 'cancelled') {
          commissionAmount = 0;
        }

        const statusLabel =
          newStatus === 'confirmed'
            ? 'تم تأكيد الطلب'
            : newStatus === 'preparing'
            ? 'الطلب قيد التجهيز والتغليف'
            : newStatus === 'out_for_delivery'
            ? 'خرج الطلب للتوصيل مع مندوب المتجر'
            : newStatus === 'delivered'
            ? 'تم تسليم الطلب واستلام المبلغ نقداً بنجاح'
            : newStatus === 'cancelled'
            ? 'تم إلغاء الطلب'
            : 'تحديث حالة الطلب';

        return {
          ...ord,
          status: newStatus,
          deliveredAt,
          commissionAmount,
          statusHistory: [
            ...ord.statusHistory,
            { status: newStatus, timestamp: now, note: note || statusLabel },
          ],
        };
      })
    );
  };

  const getCustomerOrders = (customerId: string) => {
    return orders.filter(o => o.customerId === customerId);
  };

  const getMerchantOrders = (merchantId: string) => {
    return orders.filter(o => o.merchantId === merchantId);
  };

  // Product actions
  const addProduct = (productData: Omit<Product, 'id' | 'createdAt' | 'approvalStatus'>) => {
    const newProduct: Product = {
      ...productData,
      id: `prod_${Date.now()}`,
      createdAt: new Date().toISOString(),
      approvalStatus: 'pending', // Requires admin approval!
    };
    setProducts(prev => [newProduct, ...prev]);
  };

  const updateProduct = (productId: string, updates: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => (p.id === productId ? { ...p, ...updates } : p))
    );
  };

  const deleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const setProductApproval = (productId: string, status: ProductApprovalStatus, reason?: string) => {
    setProducts(prev =>
      prev.map(p =>
        p.id === productId
          ? { ...p, approvalStatus: status, rejectionReason: reason }
          : p
      )
    );
  };

  // Merchant actions
  const registerMerchantStore = (
    storeData: Omit<MerchantStore, 'id' | 'createdAt' | 'status' | 'commissionRate'> & { id?: string; status?: MerchantStatus }
  ): MerchantStore => {
    const newStore: MerchantStore = {
      ...storeData,
      id: storeData.id || `merch_${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: storeData.status || 'approved', // auto-approve so merchant can manage their store immediately
      commissionRate: settings.defaultCommissionRate,
    };
    setMerchants(prev => [newStore, ...prev]);
    return newStore;
  };

  const updateMerchantStore = (merchantId: string, updates: Partial<MerchantStore>) => {
    setMerchants(prev =>
      prev.map(m => (m.id === merchantId ? { ...m, ...updates } : m))
    );
    if (updates.storeName) {
      const newName = updates.storeName;
      setProducts(prev =>
        prev.map(p => (p.merchantId === merchantId ? { ...p, storeName: newName } : p))
      );
    }
  };

  const setMerchantStatus = (merchantId: string, status: MerchantStatus, reason?: string) => {
    setMerchants(prev =>
      prev.map(m =>
        m.id === merchantId
          ? { ...m, status, rejectionReason: reason }
          : m
      )
    );
  };

  // Category actions
  const addCategory = (name: string, description?: string) => {
    const slug = name.trim().replace(/\s+/g, '-');
    const newCat: Category = {
      id: `cat_${Date.now()}`,
      name: name.trim(),
      slug,
      description,
      displayOrder: categories.length + 1,
    };
    setCategories(prev => [...prev, newCat]);
  };

  const updateCategory = (id: string, name: string, description?: string) => {
    setCategories(prev =>
      prev.map(c => (c.id === id ? { ...c, name: name.trim(), description } : c))
    );
  };

  const deleteCategory = (id: string) => {
    setCategories(prev => prev.filter(c => c.id !== id));
  };

  // Reviews & Verification Logic
  const getProductReviews = (productId: string) => {
    return reviews.filter(r => r.productId === productId && r.status === 'published');
  };

  const canUserReviewProduct = (
    userId: string,
    productId: string
  ): { canReview: boolean; orderId?: string; reason?: string } => {
    // 1. Must have a delivered order containing this product
    const deliveredOrdersWithProduct = orders.filter(
      o =>
        o.customerId === userId &&
        o.status === 'delivered' &&
        o.items.some(item => item.productId === productId)
    );

    if (deliveredOrdersWithProduct.length === 0) {
      return {
        canReview: false,
        reason: 'لا يمكنك تقييم المنتج إلا بعد إتمام عملية الشراء وتأكيد استلام الطلب ("تم التوصيل").',
      };
    }

    // 2. Find any delivered order that has not been reviewed yet
    const unreviewedOrder = deliveredOrdersWithProduct.find(
      o => !reviews.some(r => r.userId === userId && r.productId === productId && r.orderId === o.id)
    );

    if (!unreviewedOrder) {
      return {
        canReview: false,
        reason: 'لقد قمت بتقييم هذا المنتج مسبقاً لجميع طلباتك المكتملة.',
      };
    }

    return {
      canReview: true,
      orderId: unreviewedOrder.id,
    };
  };

  const submitReview = (
    userId: string,
    userName: string,
    userPhone: string,
    productId: string,
    orderId: string,
    rating: number,
    comment?: string
  ) => {
    const order = orders.find(
      o => o.id === orderId && o.customerId === userId && o.status === 'delivered'
    );
    if (!order || !order.items.some(item => item.productId === productId)) {
      return {
        success: false,
        message: 'لا يمكنك تقييم المنتج إلا بعد إتمام عملية الشراء وتأكيد استلام الطلب ("تم التوصيل").',
      };
    }

    const alreadyReviewed = reviews.some(
      r => r.userId === userId && r.productId === productId && r.orderId === orderId
    );
    if (alreadyReviewed) {
      return {
        success: false,
        message: 'لقد قمت بتقييم هذا المنتج مسبقاً لهذا الطلب.',
      };
    }

    const targetProduct = products.find(p => p.id === productId);

    const newReview: Review = {
      id: `rev_${Date.now()}`,
      userId,
      userName,
      userPhone,
      orderId,
      productId,
      productName: targetProduct ? targetProduct.name : 'منتج دكانة',
      rating: Math.min(5, Math.max(1, rating)),
      comment: comment?.trim() || undefined,
      createdAt: new Date().toISOString(),
      status: 'published',
      isVerifiedPurchase: true,
    };

    setReviews(prev => [newReview, ...prev]);
    return { success: true, message: 'تم نشر تقييمك الموثق بنجاح. شكراً لمشاركتك رأيك!' };
  };

  const reportReview = (
    reviewId: string,
    reporterUserId: string,
    reporterPhone: string,
    reason: ReviewReport['reason'],
    details: string
  ) => {
    const newReport: ReviewReport = {
      id: `rep_${Date.now()}`,
      reviewId,
      reporterUserId,
      reporterPhone,
      reason,
      details: details.trim(),
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    setReports(prev => [newReport, ...prev]);
    return {
      success: true,
      message: 'تم استلام بلاغك وإرساله إلى إدارة دكانة للمراجعة والتدقيق.',
    };
  };

  const setReviewStatus = (reviewId: string, status: Review['status']) => {
    setReviews(prev =>
      prev.map(r => (r.id === reviewId ? { ...r, status } : r))
    );
  };

  const resolveReport = (reportId: string, action: 'dismissed' | 'action_taken') => {
    setReports(prev =>
      prev.map(rep => (rep.id === reportId ? { ...rep, status: action } : rep))
    );
  };

  const submitSupportInquiry = (
    senderName: string,
    senderPhone: string,
    subject: string,
    message: string,
    category: SupportInquiry['category']
  ) => {
    const newInquiry: SupportInquiry = {
      id: `inq_${Date.now()}`,
      senderName: senderName.trim(),
      senderPhone: senderPhone.trim(),
      subject: subject.trim(),
      message: message.trim(),
      category,
      status: 'new',
      createdAt: new Date().toISOString(),
    };
    setInquiries(prev => [newInquiry, ...prev]);
    return {
      success: true,
      message: 'تم إرسال رسالتك إلى فريق الدعم الفني لدكانة بنجاح، وستتم مراجعتها والرد عليها.',
    };
  };

  const replySupportInquiry = (inquiryId: string, replyText: string) => {
    setInquiries(prev =>
      prev.map(inq =>
        inq.id === inquiryId
          ? {
              ...inq,
              reply: replyText.trim(),
              repliedAt: new Date().toISOString(),
              status: 'resolved',
            }
          : inq
      )
    );
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  return (
    <MarketContext.Provider
      value={{
        products,
        categories,
        merchants,
        orders,
        reviews,
        reports,
        inquiries,
        submitSupportInquiry,
        replySupportInquiry,
        settings,
        cart,
        selectedCategorySlug,
        searchQuery,
        selectedDiscount,
        selectedGovernorate,
        setSearchQuery,
        setSelectedCategorySlug,
        setSelectedDiscount,
        setSelectedGovernorate,
        getFilteredProductsForCustomer,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        getCartGroupsByMerchant,
        getCartTotalCount,
        executeSplitCheckout,
        updateOrderStatus,
        getCustomerOrders,
        getMerchantOrders,
        addProduct,
        updateProduct,
        deleteProduct,
        setProductApproval,
        registerMerchantStore,
        updateMerchantStore,
        setMerchantStatus,
        addCategory,
        updateCategory,
        deleteCategory,
        getProductReviews,
        canUserReviewProduct,
        submitReview,
        reportReview,
        setReviewStatus,
        resolveReport,
        updateSettings,
      }}
    >
      {children}
    </MarketContext.Provider>
  );
};

export const useMarket = () => {
  const context = useContext(MarketContext);
  if (!context) {
    throw new Error('useMarket must be used within a MarketProvider');
  }
  return context;
};
