import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole, IraqiGovernorate, Address, ADMIN_PHONE_E164, ADMIN_PHONE_LOCAL } from '../types';
import { INITIAL_USERS } from '../data/initialData';
import { validateIraqiPhone, requestOTP, verifyOTP } from '../utils/phoneAuth';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  role: UserRole;
  isAdmin: boolean;
  isMerchant: boolean;
  isSupport: boolean;
  isRegistered: boolean;
  requestOTPForPhone: (phone: string) => Promise<{ success: boolean; message: string; smsConfigured?: boolean }>;
  verifyOTPOnly: (
    phone: string,
    otpCode: string
  ) => Promise<{
    success: boolean;
    message: string;
    resetToken?: string;
    userExists?: boolean;
    hasPassword?: boolean;
    user?: any;
    token?: string;
  }>;
  loginWithPassword: (
    phone: string,
    password: string
  ) => Promise<{
    success: boolean;
    message: string;
    detectedRole?: UserRole;
    requiresPasswordSetup?: boolean;
    remainingAttempts?: number;
    remainingLockoutSeconds?: number;
  }>;
  resetPassword: (
    phone: string,
    resetToken: string,
    newPassword: string
  ) => Promise<{ success: boolean; message: string; detectedRole?: UserRole }>;
  verifyAndLogin: (
    phone: string,
    otpCode: string,
    displayName?: string,
    governorate?: IraqiGovernorate
  ) => { success: boolean; message: string; detectedRole?: UserRole };
  registerAccount: (params: {
    accountType: 'customer' | 'merchant' | 'admin_staff';
    phone: string;
    password: string;
    otpCode?: string;
    resetToken?: string;
    fullName: string;
    governorate: IraqiGovernorate;
    storeName?: string;
    storeDescription?: string;
    address?: string;
  }) => Promise<{ success: boolean; message: string; assignedRole?: UserRole }>;
  loginWithPhone: (
    phone: string,
    otpCode: string
  ) => Promise<{
    success: boolean;
    message: string;
    detectedRole?: UserRole;
    requiresPasswordSetup?: boolean;
    resetToken?: string;
  }>;
  logout: () => void;
  deleteAccount: (reason: string) => { success: boolean; message: string };
  addAddress: (address: Omit<Address, 'id'>) => void;
  removeAddress: (addressId: string) => void;
  updateDisplayName: (newName: string) => void;
  applyToBecomeMerchant: (storeId: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USERS_STORAGE_KEY = 'dukkana_users_db_v3';
const CURRENT_USER_ID_KEY = 'dukkana_current_user_id_v3';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(USERS_STORAGE_KEY);
    if (saved) {
      try {
        const parsed: User[] = JSON.parse(saved);
        // Security check: ensure only ADMIN_PHONE_E164 possesses 'admin' role
        return parsed
          .filter(u => !(u.role === 'admin' && u.phone !== ADMIN_PHONE_E164))
          .map(u => {
            if (u.role === 'admin' && u.phone !== ADMIN_PHONE_E164) {
              return { ...u, role: 'customer' as UserRole };
            }
            return u;
          });
      } catch {
        return INITIAL_USERS;
      }
    }
    return INITIAL_USERS;
  });

  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    const saved = localStorage.getItem(CURRENT_USER_ID_KEY);
    return saved || null; // Shows the login/registration screen on initial open if not logged in
  });

  useEffect(() => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUserId) {
      localStorage.setItem(CURRENT_USER_ID_KEY, currentUserId);
    } else {
      localStorage.removeItem(CURRENT_USER_ID_KEY);
    }
  }, [currentUserId]);

  const rawUser = users.find(u => u.id === currentUserId && u.status !== 'deleted') || null;

  // Strict server-like authorization guard on role:
  // Only the verified admin phone +9647862214922 can hold the admin role
  const currentUser: User | null = rawUser
    ? rawUser.phone === ADMIN_PHONE_E164
      ? (rawUser.role === 'admin' ? rawUser : { ...rawUser, role: 'admin' })
      : rawUser.role === 'admin'
      ? { ...rawUser, role: 'customer' }
      : rawUser
    : null;

  const role: UserRole = currentUser ? currentUser.role : 'customer';
  const isAdmin = !!currentUser && currentUser.phone === ADMIN_PHONE_E164 && role === 'admin';
  const isMerchant = !!currentUser && role === 'merchant';
  const isSupport = isAdmin; // Support is strictly linked to 07862214922

  const requestOTPForPhone = async (rawPhone: string): Promise<{ success: boolean; message: string; smsConfigured?: boolean }> => {
    try {
      const res = await fetch('/api/auth/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: rawPhone }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(text);
      } catch {
        data = { success: false, message: text || `خطأ من الخادم (${res.status})` };
      }

      if (!res.ok || !data.success) {
        return {
          success: false,
          message: data.message || 'فشل إرسال رمز التحقق عبر مزود SMS.',
          smsConfigured: data.smsConfigured ?? true,
        };
      }
      return {
        success: true,
        message: data.message,
        smsConfigured: true,
      };
    } catch (err: any) {
      return {
        success: false,
        message: err?.message ? `خطأ أثناء الاتصال بالخادم: ${err.message}` : 'تعذر الاتصال بخادم إرسال الرسائل SMS.',
        smsConfigured: false,
      };
    }
  };

  const verifyAndLogin = (
    rawPhone: string,
    otpCode: string,
    displayName?: string,
    governorate?: IraqiGovernorate
  ): { success: boolean; message: string; detectedRole?: UserRole } => {
    const validation = validateIraqiPhone(rawPhone);
    if (!validation.isValid) {
      return { success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح' };
    }

    const verification = verifyOTP(rawPhone, otpCode);
    if (!verification.success) {
      return verification;
    }

    const phoneE164 = validation.normalizedE164;
    const isAdminPhone = phoneE164 === ADMIN_PHONE_E164;

    // Check if user already exists
    let user = users.find(u => u.phone === phoneE164);

    if (user) {
      if (user.status === 'deleted') {
        return {
          success: false,
          message: 'هذا الحساب تم حذفه مسبقاً. يرجى مراجعة الدعم الفني للاستعادة.',
        };
      }
      if (user.status === 'suspended') {
        return {
          success: false,
          message: 'تم إيقاف هذا الحساب لمخالفة شروط الاستخدام. تواصل مع إدارة دكانة.',
        };
      }

      // Automatically enforce role based on verified phone
      let determinedRole: UserRole = user.role;
      if (isAdminPhone) {
        determinedRole = 'admin';
      } else if (user.merchantStoreId) {
        determinedRole = 'merchant';
      } else if (user.role === 'admin') {
        determinedRole = 'customer';
      }

      setUsers(prev =>
        prev.map(u => (u.id === user!.id ? { ...u, role: determinedRole } : u))
      );
      setCurrentUserId(user.id);

      return {
        success: true,
        message: isAdminPhone
          ? 'تم التحقق بنجاح. أهلاً بك في لوحة الإدارة الرئيسية لمنصة دكانة.'
          : determinedRole === 'merchant'
          ? 'تم تسجيل الدخول بنجاح كتاجر معتمد في سوق دكانة.'
          : 'تم تسجيل الدخول بنجاح.',
        detectedRole: determinedRole,
      };
    }

    // Create new account:
    // Only ADMIN_PHONE_E164 receives admin status; all other signups are customers
    const newUserId = isAdminPhone ? 'usr_admin' : `usr_${Date.now()}`;
    const initialRole: UserRole = isAdminPhone ? 'admin' : 'customer';

    const newUser: User = {
      id: newUserId,
      phone: phoneE164,
      displayName:
        displayName?.trim() ||
        (isAdminPhone ? 'مدير منصة دكانة' : `مستخدم ${validation.localDisplay.slice(-4)}`),
      role: initialRole,
      governorate: governorate || 'بغداد',
      addresses: [],
      createdAt: new Date().toISOString(),
      status: 'active',
    };

    setUsers(prev => [...prev, newUser]);
    setCurrentUserId(newUserId);

    return {
      success: true,
      message: isAdminPhone
        ? 'تم التحقق وإنشاء جلسة مدير المنصة الرسمي الوحيد بنجاح.'
        : 'تم إنشاء الحساب وتسجيل الدخول بنجاح عبر رمز التحقق.',
      detectedRole: initialRole,
    };
  };

  /**
   * Verify OTP only - Returns resetToken for password creation/reset
   */
  const verifyOTPOnly = async (
    rawPhone: string,
    otpCode: string
  ): Promise<{
    success: boolean;
    message: string;
    resetToken?: string;
    userExists?: boolean;
    hasPassword?: boolean;
    user?: any;
    token?: string;
  }> => {
    const validation = validateIraqiPhone(rawPhone);
    if (!validation.isValid) {
      return { success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح' };
    }
    const phoneE164 = validation.normalizedE164;

    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phoneE164, otpCode }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(text);
      } catch {
        data = { success: false, message: text || `خطأ من الخادم (${res.status})` };
      }

      if (!res.ok || !data.success) {
        return {
          success: false,
          message: data.message || 'رمز التحقق غير صحيح أو منتهي الصلاحية.',
        };
      }

      if (data.token) {
        localStorage.setItem('dukkana_session_token_v3', data.token);
      }

      if (data.user && data.hasPassword) {
        let user = users.find(u => u.phone === phoneE164);
        if (!user) {
          user = {
            id: data.user.id || (phoneE164 === ADMIN_PHONE_E164 ? 'usr_admin' : `usr_${Date.now()}`),
            phone: phoneE164,
            displayName: data.user.displayName || (phoneE164 === ADMIN_PHONE_E164 ? 'مدير منصة دكانة الرئيسي' : `مستخدم ${validation.localDisplay.slice(-4)}`),
            role: (data.user.role as UserRole) || (phoneE164 === ADMIN_PHONE_E164 ? 'admin' : 'customer'),
            governorate: data.user.governorate || 'بغداد',
            addresses: [],
            merchantStoreId: data.user.merchantStoreId,
            createdAt: data.user.createdAt || new Date().toISOString(),
            status: 'active',
            hasPassword: true,
          };
          setUsers(prev => [user!, ...prev.filter(u => u.phone !== phoneE164)]);
        } else {
          user = {
            ...user,
            hasPassword: true,
            role: (data.user.role as UserRole) || user.role,
          };
          setUsers(prev => prev.map(u => u.phone === phoneE164 ? user! : u));
        }
        setCurrentUserId(user.id);
      }

      return {
        success: true,
        message: data.message || 'تم التحقق من رمز OTP بنجاح.',
        resetToken: data.resetToken,
        userExists: data.userExists,
        hasPassword: data.hasPassword,
        user: data.user,
        token: data.token,
      };
    } catch (err: any) {
      return {
        success: false,
        message: err?.message ? `خطأ أثناء الاتصال بالخادم: ${err.message}` : 'تعذر الاتصال بالخادم للتحقق من الرمز.',
      };
    }
  };

  /**
   * Direct login using phone + password (No OTP sent)
   */
  const loginWithPassword = async (
    rawPhone: string,
    password: string
  ): Promise<{
    success: boolean;
    message: string;
    detectedRole?: UserRole;
    requiresPasswordSetup?: boolean;
    remainingAttempts?: number;
    remainingLockoutSeconds?: number;
  }> => {
    const validation = validateIraqiPhone(rawPhone);
    if (!validation.isValid) {
      return { success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح' };
    }
    const phoneE164 = validation.normalizedE164;
    const isAdminPhone = phoneE164 === ADMIN_PHONE_E164;

    try {
      const res = await fetch('/api/auth/login-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phoneE164, password }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(text);
      } catch {
        data = { success: false, message: text || `خطأ من الخادم (${res.status})` };
      }

      if (!res.ok || !data.success) {
        return {
          success: false,
          message: data.message || 'رقم الهاتف أو كلمة المرور غير صحيحة.',
          requiresPasswordSetup: data.requiresPasswordSetup,
          remainingAttempts: data.remainingAttempts,
          remainingLockoutSeconds: data.remainingLockoutSeconds,
        };
      }

      if (data.token) {
        localStorage.setItem('dukkana_session_token_v3', data.token);
      }

      let user = users.find(u => u.phone === phoneE164);
      if (!user) {
        user = {
          id: data.user?.id || (isAdminPhone ? 'usr_admin' : `usr_${Date.now()}`),
          phone: phoneE164,
          displayName: data.user?.displayName || (isAdminPhone ? 'مدير منصة دكانة الرئيسي' : `مستخدم ${validation.localDisplay.slice(-4)}`),
          role: (data.user?.role as UserRole) || (isAdminPhone ? 'admin' : 'customer'),
          governorate: data.user?.governorate || 'بغداد',
          addresses: [],
          merchantStoreId: data.user?.merchantStoreId,
          createdAt: data.user?.createdAt || new Date().toISOString(),
          status: 'active',
          hasPassword: true,
        };
        setUsers(prev => [user!, ...prev.filter(u => u.phone !== phoneE164)]);
      } else {
        user = {
          ...user,
          hasPassword: true,
          role: (data.user?.role as UserRole) || (isAdminPhone ? 'admin' : user.role),
        };
        setUsers(prev => prev.map(u => u.phone === phoneE164 ? user! : u));
      }

      const determinedRole: UserRole = isAdminPhone ? 'admin' : (user.role || 'customer');
      setCurrentUserId(user.id);

      return {
        success: true,
        message: data.message || 'تم تسجيل الدخول بنجاح.',
        detectedRole: determinedRole,
      };
    } catch (err: any) {
      return {
        success: false,
        message: err?.message ? `خطأ أثناء الاتصال بالخادم: ${err.message}` : 'تعذر الاتصال بخادم تسجيل الدخول.',
      };
    }
  };

  /**
   * Reset / Set Password securely
   */
  const resetPassword = async (
    rawPhone: string,
    resetToken: string,
    newPassword: string
  ): Promise<{ success: boolean; message: string; detectedRole?: UserRole }> => {
    const validation = validateIraqiPhone(rawPhone);
    if (!validation.isValid) {
      return { success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح' };
    }
    const phoneE164 = validation.normalizedE164;
    const isAdminPhone = phoneE164 === ADMIN_PHONE_E164;

    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phoneE164, resetToken, newPassword }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(text);
      } catch {
        data = { success: false, message: text || `خطأ من الخادم (${res.status})` };
      }

      if (!res.ok || !data.success) {
        return {
          success: false,
          message: data.message || 'فشل تحديث كلمة المرور.',
        };
      }

      if (data.token) {
        localStorage.setItem('dukkana_session_token_v3', data.token);
      }

      let user = users.find(u => u.phone === phoneE164);
      if (!user) {
        user = {
          id: data.user?.id || (isAdminPhone ? 'usr_admin' : `usr_${Date.now()}`),
          phone: phoneE164,
          displayName: data.user?.displayName || (isAdminPhone ? 'مدير منصة دكانة الرئيسي' : `مستخدم ${validation.localDisplay.slice(-4)}`),
          role: (data.user?.role as UserRole) || (isAdminPhone ? 'admin' : 'customer'),
          governorate: data.user?.governorate || 'بغداد',
          addresses: [],
          createdAt: new Date().toISOString(),
          status: 'active',
          hasPassword: true,
        };
        setUsers(prev => [user!, ...prev.filter(u => u.phone !== phoneE164)]);
      } else {
        user = {
          ...user,
          hasPassword: true,
          role: (data.user?.role as UserRole) || (isAdminPhone ? 'admin' : user.role),
        };
        setUsers(prev => prev.map(u => u.phone === phoneE164 ? user! : u));
      }

      const determinedRole: UserRole = isAdminPhone ? 'admin' : (user.role || 'customer');
      setCurrentUserId(user.id);

      return {
        success: true,
        message: data.message || 'تم تعيين كلمة المرور بنجاح وتسجيل الدخول.',
        detectedRole: determinedRole,
      };
    } catch (err: any) {
      return {
        success: false,
        message: err?.message ? `خطأ أثناء الاتصال بالخادم: ${err.message}` : 'تعذر الاتصال بخادم تحديث كلمة المرور.',
      };
    }
  };

  /**
   * Real Account Registration with Role Assignment & Password Hashing
   */
  const registerAccount = async (params: {
    accountType: 'customer' | 'merchant' | 'admin_staff';
    phone: string;
    password: string;
    otpCode?: string;
    resetToken?: string;
    fullName: string;
    governorate: IraqiGovernorate;
    storeName?: string;
    storeDescription?: string;
    address?: string;
  }): Promise<{ success: boolean; message: string; assignedRole?: UserRole }> => {
    const validation = validateIraqiPhone(params.phone);
    if (!validation.isValid) {
      return { success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح' };
    }

    const phoneE164 = validation.normalizedE164;
    const isAdminPhone = phoneE164 === ADMIN_PHONE_E164;

    // Strict Server-Authoritative Verification & Account Creation
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountType: params.accountType,
          phone: phoneE164,
          otpCode: params.otpCode,
          resetToken: params.resetToken,
          password: params.password,
          fullName: params.fullName,
          governorate: params.governorate,
          storeName: params.storeName,
          storeDescription: params.storeDescription,
          address: params.address,
        }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(text);
      } catch {
        data = { success: false, message: text || `خطأ من الخادم (${res.status})` };
      }

      if (!res.ok || !data.success) {
        return {
          success: false,
          message: data.message || 'فشل إنشاء الحساب.',
        };
      }
      if (data.token) {
        localStorage.setItem('dukkana_session_token_v3', data.token);
      }
    } catch {
      if (params.otpCode) {
        const verification = verifyOTP(params.phone, params.otpCode);
        if (!verification.success) {
          return verification;
        }
      }
    }

    // Check if phone already registered in users
    const existing = users.find(u => u.phone === phoneE164);
    if (existing && existing.status !== 'deleted') {
      return {
        success: false,
        message: 'رقم الهاتف هذا مسجل مسبقاً في دكانة. يرجى اختيار "تسجيل الدخول" مباشرة.',
      };
    }

    let assignedRole: UserRole = 'customer';
    let merchantStoreId: string | undefined = undefined;
    let successMessage = '';

    if (params.accountType === 'merchant') {
      assignedRole = 'merchant';
      merchantStoreId = `merch_${Date.now()}`;
      const MERCHANTS_KEY = 'dukkana_merchants_db_v2';
      try {
        const savedMerchantsStr = localStorage.getItem(MERCHANTS_KEY);
        const existingMerchants = savedMerchantsStr ? JSON.parse(savedMerchantsStr) : [];
        const newMerchantStore = {
          id: merchantStoreId,
          userId: `usr_${Date.now()}`,
          storeName: params.storeName?.trim() || `متجر ${params.fullName}`,
          description: params.storeDescription?.trim() || 'متجر معتمد ومسجل في سوق دكانة لكافة المحافظات',
          governorate: params.governorate,
          phone: phoneE164,
          status: 'approved',
          commissionRate: 5,
          createdAt: new Date().toISOString(),
        };
        localStorage.setItem(MERCHANTS_KEY, JSON.stringify([newMerchantStore, ...existingMerchants]));
      } catch (err) {
        console.error('Error saving merchant store:', err);
      }
      successMessage = 'تم إنشاء وتوثيق حساب التاجر بنجاح وتعيين كلمة المرور. أهلاً بك في لوحة إدارة متجرك!';
    } else if (params.accountType === 'admin_staff') {
      if (!isAdminPhone) {
        return {
          success: false,
          message: 'تم رفض إنشاء الحساب: غير مصرح لهذا الرقم بصلاحية الإدارة. رقم المدير المعتمد الوحيد هو 07862214922.',
        };
      }
      assignedRole = 'admin';
      successMessage = 'تم التحقق بنجاح وتفعيل صلاحية المدير وتعيين كلمة المرور.';
    } else {
      assignedRole = 'customer';
      successMessage = 'تم إنشاء حساب الزبون وتعيين كلمة المرور بنجاح. أهلاً بك في سوق دكانة!';
    }

    const newUserId = assignedRole === 'admin' ? 'usr_admin' : `usr_${Date.now()}`;
    const initialAddresses: Address[] = [];
    if (params.address?.trim()) {
      initialAddresses.push({
        id: `addr_${Date.now()}`,
        governorate: params.governorate,
        cityOrDistrict: params.governorate,
        nearestLandmark: '',
        fullAddress: params.address.trim(),
        isDefault: true,
      });
    }

    const newUser: User = {
      id: newUserId,
      phone: phoneE164,
      displayName: params.fullName.trim() || (assignedRole === 'admin' ? 'المدير الرئيسي' : `مستخدم ${validation.localDisplay.slice(-4)}`),
      role: assignedRole,
      governorate: params.governorate,
      addresses: initialAddresses,
      merchantStoreId,
      createdAt: new Date().toISOString(),
      status: 'active',
      hasPassword: true,
    };

    setUsers(prev => {
      const filtered = prev.filter(u => u.phone !== phoneE164);
      return [newUser, ...filtered];
    });

    const token = `duk_sec_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    localStorage.setItem('dukkana_session_token_v3', token);

    setCurrentUserId(newUserId);

    return {
      success: true,
      message: successMessage,
      assignedRole,
    };
  };

  /**
   * Login with Phone & OTP (Falls back or checks if user requires password setup)
   */
  const loginWithPhone = async (
    rawPhone: string,
    otpCode: string
  ): Promise<{
    success: boolean;
    message: string;
    detectedRole?: UserRole;
    requiresPasswordSetup?: boolean;
    resetToken?: string;
  }> => {
    const validation = validateIraqiPhone(rawPhone);
    if (!validation.isValid) {
      return { success: false, message: validation.errorMessage || 'رقم الهاتف غير صالح' };
    }

    const phoneE164 = validation.normalizedE164;
    const isAdminPhone = phoneE164 === ADMIN_PHONE_E164;

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phoneE164, otpCode }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(text);
      } catch {
        data = { success: false, message: text || `خطأ من الخادم (${res.status})` };
      }

      if (!res.ok || !data.success) {
        return {
          success: false,
          message: data.message || 'رمز التحقق غير صحيح أو منتهي الصلاحية.',
        };
      }

      // Check if user doesn't have a password set yet
      if (data.requiresPasswordSetup) {
        return {
          success: true,
          requiresPasswordSetup: true,
          resetToken: data.resetToken,
          message: data.message || 'يرجى إنشاء كلمة مرور لحسابك للمتابعة.',
        };
      }

      if (data.token) {
        localStorage.setItem('dukkana_session_token_v3', data.token);
      }
    } catch {
      const verification = verifyOTP(rawPhone, otpCode);
      if (!verification.success) {
        return verification;
      }
    }

    let user = users.find(u => u.phone === phoneE164);
    if (!user && isAdminPhone) {
      user = {
        id: 'usr_admin',
        phone: ADMIN_PHONE_E164,
        displayName: 'مدير منصة دكانة الرئيسي',
        role: 'admin',
        governorate: 'بغداد',
        addresses: [],
        createdAt: new Date().toISOString(),
        status: 'active',
        hasPassword: true,
      };
      setUsers(prev => [user!, ...prev]);
    }

    if (!user) {
      return {
        success: false,
        message: 'رقم الهاتف غير مسجل في النظام. يرجى اختيار "إنشاء حساب جديد" أولاً واختيار نوع الحساب.',
      };
    }

    if (user.status === 'deleted') {
      return {
        success: false,
        message: 'هذا الحساب تم حذفه مسبقاً. يرجى مراجعة الدعم الفني للاستعادة.',
      };
    }

    if (user.status === 'suspended') {
      return {
        success: false,
        message: 'تم إيقاف هذا الحساب لمخالفة شروط الاستخدام. تواصل مع إدارة دكانة.',
      };
    }

    let determinedRole: UserRole = 'customer';
    if (isAdminPhone) {
      determinedRole = 'admin';
    } else if (user.merchantStoreId || user.role === 'merchant') {
      determinedRole = 'merchant';
    } else {
      determinedRole = 'customer';
    }

    setUsers(prev =>
      prev.map(u => (u.id === user!.id ? { ...u, role: determinedRole } : u))
    );
    setCurrentUserId(user.id);

    const token = `duk_sec_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    localStorage.setItem('dukkana_session_token_v3', token);

    return {
      success: true,
      message: isAdminPhone
        ? 'تم التحقق بنجاح. أهلاً بك في لوحة الإدارة الرئيسية لمنصة دكانة.'
        : determinedRole === 'merchant'
        ? 'تم تسجيل الدخول بنجاح كتاجر معتمد في سوق دكانة.'
        : 'تم تسجيل الدخول بنجاح.',
      detectedRole: determinedRole,
    };
  };

  const logout = () => {
    localStorage.removeItem('dukkana_session_token_v3');
    setCurrentUserId(null);
  };

  const applyToBecomeMerchant = (storeId: string) => {
    if (!currentUser) return;
    setUsers(prev =>
      prev.map(u =>
        u.id === currentUser.id
          ? { ...u, role: 'merchant', merchantStoreId: storeId }
          : u
      )
    );
  };

  const deleteAccount = (reason: string) => {
    if (!currentUser) {
      return { success: false, message: 'لا يوجد حساب مسجل حالياً.' };
    }

    // Apple App Store & Google Play Account Deletion compliance:
    // Sanitize user personally identifiable info (PII) immediately
    setUsers(prev =>
      prev.map(u => {
        if (u.id === currentUser.id) {
          return {
            ...u,
            displayName: 'حساب محذوف',
            phone: `DELETED_${Date.now()}`,
            addresses: [],
            status: 'deleted',
          };
        }
        return u;
      })
    );

    setCurrentUserId(null);
    return {
      success: true,
      message: 'تم حذف حسابك وجميع بياناتك الشخصية بنجاح وفق سياسة حماية الخصوصية.',
    };
  };

  const addAddress = (newAddr: Omit<Address, 'id'>) => {
    if (!currentUser) return;
    const addressId = `addr_${Date.now()}`;
    const fullAddressObj: Address = {
      ...newAddr,
      id: addressId,
      isDefault: currentUser.addresses.length === 0,
    };

    setUsers(prev =>
      prev.map(u => {
        if (u.id === currentUser.id) {
          return {
            ...u,
            addresses: [...u.addresses, fullAddressObj],
          };
        }
        return u;
      })
    );
  };

  const removeAddress = (addressId: string) => {
    if (!currentUser) return;
    setUsers(prev =>
      prev.map(u => {
        if (u.id === currentUser.id) {
          return {
            ...u,
            addresses: u.addresses.filter(a => a.id !== addressId),
          };
        }
        return u;
      })
    );
  };

  const updateDisplayName = (newName: string) => {
    if (!currentUser || !newName.trim()) return;
    setUsers(prev =>
      prev.map(u => {
        if (u.id === currentUser.id) {
          return {
            ...u,
            displayName: newName.trim(),
          };
        }
        return u;
      })
    );
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        role,
        isAdmin,
        isMerchant,
        isSupport,
        isRegistered: !!currentUser,
        requestOTPForPhone,
        verifyOTPOnly,
        loginWithPassword,
        resetPassword,
        verifyAndLogin,
        registerAccount,
        loginWithPhone,
        logout,
        deleteAccount,
        addAddress,
        removeAddress,
        updateDisplayName,
        applyToBecomeMerchant,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
