import React, { useState } from 'react';
import {
  Store,
  Plus,
  Package,
  TrendingUp,
  ShoppingBag,
  Clock,
  CheckCircle2,
  XCircle,
  Edit,
  Trash2,
  Upload,
  Image as ImageIcon,
  DollarSign,
  AlertCircle,
  Star,
  ShieldCheck,
  Eye,
} from 'lucide-react';
import { useMarket } from '../context/MarketContext';
import { useAuth } from '../context/AuthContext';
import { Product, IraqiGovernorate, OrderStatus } from '../types';
import { IRAQI_GOVERNORATES } from '../data/governorates';
import { formatIQDTabular } from '../utils/currency';

export const MerchantDashboard: React.FC = () => {
  const {
    products,
    merchants,
    orders,
    categories,
    reviews,
    addProduct,
    updateProduct,
    deleteProduct,
    updateOrderStatus,
    registerMerchantStore,
    updateMerchantStore,
  } = useMarket();

  const { currentUser, isMerchant } = useAuth();

  // Find merchant's store with safe fallback
  const store =
    merchants.find(m => m.userId === currentUser?.id || m.id === currentUser?.merchantStoreId) ||
    merchants[0] || {
      id: 'merch_default',
      userId: currentUser?.id || 'usr_default',
      storeName: 'متجر جديد',
      description: 'متجر عراقي جديد',
      governorate: 'بغداد' as IraqiGovernorate,
      phone: currentUser?.phone || '07700000000',
      status: 'pending' as const,
      commissionRate: 5,
      createdAt: new Date().toISOString(),
    };

  // State for Add / Edit Product Modal
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // State for Edit Store Info Modal
  const [isStoreModalOpen, setIsStoreModalOpen] = useState(false);
  const [storeNameInput, setStoreNameInput] = useState(store?.storeName || '');
  const [storeDescInput, setStoreDescInput] = useState(store?.description || '');
  const [storeGovInput, setStoreGovInput] = useState<IraqiGovernorate>(store?.governorate || 'بغداد');
  const [storePhoneInput, setStorePhoneInput] = useState(store?.phone || '');
  const [storeModalSuccess, setStoreModalSuccess] = useState('');

  // Form fields
  const [prodName, setProdName] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodPrice, setProdPrice] = useState('');
  const [prodOriginalPrice, setProdOriginalPrice] = useState('');
  const [prodCategoryId, setProdCategoryId] = useState(categories[1]?.id || 'cat_food');
  const [prodImagePreview, setProdImagePreview] = useState<string>('');
  const [prodInStock, setProdInStock] = useState(true);
  const [formError, setFormError] = useState('');

  if (!isMerchant) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200">
          <Store className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-black text-zinc-900">لوحة التاجر محمية</h2>
        <p className="text-xs text-zinc-600 leading-relaxed">
          هذه الصفحة مخصصة حصرياً للتجار المعتمدين في سوق دكانة لإدارة منتجاتهم ومبيعاتهم.
        </p>
      </div>
    );
  }

  const handleSaveStore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeNameInput.trim()) return;
    updateMerchantStore(store.id, {
      storeName: storeNameInput.trim(),
      description: storeDescInput.trim(),
      governorate: storeGovInput,
      phone: storePhoneInput.trim(),
    });
    setStoreModalSuccess('تم تحديث معلومات المتجر بنجاح.');
    setTimeout(() => {
      setStoreModalSuccess('');
      setIsStoreModalOpen(false);
    }, 1200);
  };
  const storeProducts = products.filter(p => p.merchantId === store?.id);

  // Filter orders for this merchant only (strict multi-tenant boundary)
  const storeOrders = orders.filter(o => o.merchantId === store?.id);

  // Financial Metrics
  const deliveredOrders = storeOrders.filter(o => o.status === 'delivered');
  const cancelledOrders = storeOrders.filter(o => o.status === 'cancelled');

  const totalGrossSales = deliveredOrders.reduce((sum, o) => sum + o.subtotal, 0);
  const platformCommissionsDeducted = deliveredOrders.reduce((sum, o) => sum + o.commissionAmount, 0);
  const netEarnings = totalGrossSales - platformCommissionsDeducted;

  // Store reviews
  const storeProductIds = new Set(storeProducts.map(p => p.id));
  const storeReviews = reviews.filter(r => storeProductIds.has(r.productId));

  const openAddModal = () => {
    setEditingProduct(null);
    setProdName('');
    setProdDesc('');
    setProdPrice('');
    setProdOriginalPrice('');
    setProdCategoryId(categories[1]?.id || 'cat_food');
    setProdImagePreview('/src/assets/images/product_iraqi_dates_1791352458875.jpg');
    setProdInStock(true);
    setFormError('');
    setIsProductModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setProdName(p.name);
    setProdDesc(p.description);
    setProdPrice(p.price.toString());
    setProdOriginalPrice(p.originalPrice ? p.originalPrice.toString() : '');
    setProdCategoryId(p.categoryId);
    setProdImagePreview(p.imageUrl);
    setProdInStock(p.inStock);
    setFormError('');
    setIsProductModalOpen(true);
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate image type & size (max 5MB)
    if (!file.type.startsWith('image/')) {
      setFormError('يرجى اختيار ملف صورة صالح (JPEG, PNG, WEBP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setFormError('حجم الصورة كبير جداً. الحد الأقصى 5 ميغابايت.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setProdImagePreview(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!prodName.trim()) {
      setFormError('يرجى كتابة اسم المنتج.');
      return;
    }

    const priceNum = Number(prodPrice);
    if (isNaN(priceNum) || priceNum <= 0) {
      setFormError('يرجى إدخال سعر صحيح بالدينار العراقي.');
      return;
    }

    const origPriceNum = prodOriginalPrice ? Number(prodOriginalPrice) : undefined;
    let discountPercent: number | undefined = undefined;
    if (origPriceNum && origPriceNum > priceNum) {
      discountPercent = Math.round(((origPriceNum - priceNum) / origPriceNum) * 100);
    }

    const cat = categories.find(c => c.id === prodCategoryId);
    const categoryName = cat ? cat.name : 'منتجات عامة';

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: prodName.trim(),
        description: prodDesc.trim(),
        price: priceNum,
        originalPrice: origPriceNum,
        discountPercent,
        finalPrice: priceNum,
        categoryId: prodCategoryId,
        categoryName,
        imageUrl: prodImagePreview || editingProduct.imageUrl,
        inStock: prodInStock,
      });
    } else {
      addProduct({
        merchantId: store.id,
        storeName: store.storeName,
        name: prodName.trim(),
        description: prodDesc.trim(),
        price: priceNum,
        originalPrice: origPriceNum,
        discountPercent,
        finalPrice: priceNum,
        categoryId: prodCategoryId,
        categoryName,
        imageUrl: prodImagePreview || '/src/assets/images/product_iraqi_dates_1791352458875.jpg',
        inStock: prodInStock,
      });
    }

    setIsProductModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Merchant Header & Status Banner */}
      <div className="bg-white rounded-3xl border border-zinc-200/90 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
            <Store className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-zinc-900">
                {store?.storeName || 'متجر التاجر'}
              </h1>
              <span
                className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                  store?.status === 'approved'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200'
                }`}
              >
                {store?.status === 'approved' ? 'متجر معتمد ونشط' : 'قيد مراجعة الإدارة'}
              </span>
            </div>
            <p className="text-xs text-zinc-500 mt-1 max-w-xl">
              {store?.description || 'إدارة منتجات ومبيعات متجرك في سوق دكانة العراقي'}
            </p>
            <div className="text-[11px] text-zinc-400 mt-1">
              المحافظة: {store?.governorate} · هاتف المتجر: {store?.phone} · نسبة عمولة المنصة: {store?.commissionRate}%
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
          <button
            onClick={() => {
              setStoreNameInput(store.storeName);
              setStoreDescInput(store.description);
              setStoreGovInput(store.governorate);
              setStorePhoneInput(store.phone);
              setIsStoreModalOpen(true);
            }}
            className="px-4 py-3 rounded-xl border border-zinc-200 hover:bg-zinc-50 text-zinc-700 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Edit className="w-3.5 h-3.5" />
            <span>بيانات المتجر</span>
          </button>
          <button
            onClick={openAddModal}
            className="px-5 py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-purple-700/20 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة منتج جديد</span>
          </button>
        </div>
      </div>

      {/* Financial Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Total Delivered Orders */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-zinc-200">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-bold text-zinc-600">الطلبات المكتملة</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-zinc-900 tabular-nums">
            {deliveredOrders.length}
          </div>
          <span className="text-[11px] text-zinc-400 mt-1 block">
            تم تسليمها للمشتري بنجاح
          </span>
        </div>

        {/* Metric 2: Gross Sales */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-zinc-200">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-bold text-zinc-600">إجمالي المبيعات</span>
            <ShoppingBag className="w-4 h-4 text-purple-700" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-purple-950 tabular-nums">
            {formatIQDTabular(totalGrossSales)}
          </div>
          <span className="text-[11px] text-zinc-400 mt-1 block">
            قيمة المنتجات المسلمة
          </span>
        </div>

        {/* Metric 3: Platform Commission (5%) */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-zinc-200">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-bold text-zinc-600">عمولة دكانة ({store?.commissionRate}%)</span>
            <DollarSign className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-900 tabular-nums">
            {formatIQDTabular(platformCommissionsDeducted)}
          </div>
          <span className="text-[11px] text-zinc-400 mt-1 block">
            تُستقطع فقط عند تم التوصيل
          </span>
        </div>

        {/* Metric 4: Net Earnings */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-zinc-200 bg-linear-to-br from-white to-purple-50/50">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-bold text-purple-900">صافي الأرباح</span>
            <TrendingUp className="w-4 h-4 text-purple-700" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 tabular-nums">
            {formatIQDTabular(netEarnings)}
          </div>
          <span className="text-[11px] text-zinc-400 mt-1 block">
            مستحقات التاجر الصافية
          </span>
        </div>
      </div>

      {/* Store Products Management */}
      <div className="bg-white rounded-3xl border border-zinc-200/90 overflow-hidden shadow-xs">
        <div className="p-5 border-b border-zinc-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-purple-700" />
            <h2 className="text-base font-black text-zinc-900">
              منتجات المتجر ({storeProducts.length})
            </h2>
          </div>
          <span className="text-xs text-zinc-500">
            تخضع المنتجات الجديدة لمراجعة المدير لضمان السلامة والامتثال.
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-zinc-50 text-zinc-600 font-bold border-b border-zinc-200">
              <tr>
                <th className="p-3.5">المنتج</th>
                <th className="p-3.5">القسم</th>
                <th className="p-3.5">السعر</th>
                <th className="p-3.5">الخصم</th>
                <th className="p-3.5">التوفر</th>
                <th className="p-3.5">حالة الموافقة</th>
                <th className="p-3.5 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200/60">
              {storeProducts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-zinc-400">
                    لم تقم بإضافة أي منتجات بعد. اضغط على زر "إضافة منتج جديد" للبدء.
                  </td>
                </tr>
              ) : (
                storeProducts.map(p => (
                  <tr key={p.id} className="hover:bg-zinc-50/50">
                    <td className="p-3.5">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={p.imageUrl}
                          alt={p.name}
                          className="w-10 h-10 rounded-lg object-cover bg-zinc-100 shrink-0"
                        />
                        <span className="font-bold text-zinc-900 line-clamp-1">{p.name}</span>
                      </div>
                    </td>
                    <td className="p-3.5 text-zinc-600">{p.categoryName}</td>
                    <td className="p-3.5 font-black text-purple-950 tabular-nums">
                      {formatIQDTabular(p.finalPrice)}
                    </td>
                    <td className="p-3.5">
                      {p.discountPercent ? (
                        <span className="font-bold text-rose-600">{p.discountPercent}%</span>
                      ) : (
                        <span className="text-zinc-400">—</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                          p.inStock
                            ? 'bg-emerald-50 text-emerald-800'
                            : 'bg-zinc-100 text-zinc-500'
                        }`}
                      >
                        {p.inStock ? 'متوفر' : 'غير متوفر'}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] border ${
                          p.approvalStatus === 'approved'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : p.approvalStatus === 'rejected'
                            ? 'bg-rose-50 text-rose-800 border-rose-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                      >
                        {p.approvalStatus === 'approved'
                          ? 'مقبول (معروض)'
                          : p.approvalStatus === 'rejected'
                          ? 'مرفوض'
                          : 'قيد المراجعة'}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => openEditModal(p)}
                          className="p-1 text-zinc-600 hover:text-purple-700 cursor-pointer"
                          title="تعديل المنتج"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm('هل أنت متأكد من حذف هذا المنتج نهائياً؟')) {
                              deleteProduct(p.id);
                            }
                          }}
                          className="p-1 text-zinc-400 hover:text-rose-600 cursor-pointer"
                          title="حذف المنتج"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Store Orders Management */}
      <div className="bg-white rounded-3xl border border-zinc-200/90 overflow-hidden shadow-xs">
        <div className="p-5 border-b border-zinc-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-purple-700" />
            <h2 className="text-base font-black text-zinc-900">
              طلبات المتجر ({storeOrders.length})
            </h2>
          </div>
          <span className="text-xs text-zinc-500">
            أنت مسؤول كتاجر عن تجهيز وتوصيل طلبات متجرك وتحصيل المبالغ نقداً عند الاستلام.
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-zinc-50 text-zinc-600 font-bold border-b border-zinc-200">
              <tr>
                <th className="p-3.5">رقم الطلب</th>
                <th className="p-3.5">المستلم والمحافظة</th>
                <th className="p-3.5">محتويات الطلب</th>
                <th className="p-3.5">المبلغ المطلوب</th>
                <th className="p-3.5">عمولة المنصة</th>
                <th className="p-3.5">حالة الطلب</th>
                <th className="p-3.5 text-center">تحديث الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200/60">
              {storeOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-zinc-400">
                    لا توجد طلبات واردة لمتجرك حتى الآن.
                  </td>
                </tr>
              ) : (
                storeOrders.map(ord => (
                  <tr key={ord.id} className="hover:bg-zinc-50/50">
                    <td className="p-3.5 font-mono font-bold text-purple-950">{ord.id}</td>
                    <td className="p-3.5 text-zinc-700">
                      <div className="font-bold">{ord.recipientName}</div>
                      <div className="text-[11px] text-zinc-400">{ord.governorate} · {ord.recipientPhone}</div>
                    </td>
                    <td className="p-3.5 text-zinc-600">
                      {ord.items.map(i => `${i.productName} (${i.quantity})`).join(' ، ')}
                    </td>
                    <td className="p-3.5 font-black text-purple-950 tabular-nums">
                      {formatIQDTabular(ord.finalTotal)}
                    </td>
                    <td className="p-3.5 font-bold text-emerald-800 tabular-nums">
                      {ord.status === 'delivered' ? formatIQDTabular(ord.commissionAmount) : '—'}
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] border ${
                          ord.status === 'delivered'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : ord.status === 'cancelled'
                            ? 'bg-rose-50 text-rose-800 border-rose-200'
                            : 'bg-blue-50 text-blue-800 border-blue-200'
                        }`}
                      >
                        {ord.status === 'delivered'
                          ? 'تم التوصيل'
                          : ord.status === 'cancelled'
                          ? 'ملغي'
                          : ord.status === 'out_for_delivery'
                          ? 'خرج للتوصيل'
                          : ord.status === 'preparing'
                          ? 'قيد التجهيز'
                          : ord.status === 'confirmed'
                          ? 'تم التأكيد'
                          : 'طلب جديد'}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <select
                        value={ord.status}
                        onChange={e => updateOrderStatus(ord.id, e.target.value as OrderStatus)}
                        className="px-2 py-1 rounded-lg border border-purple-200 bg-white text-[11px] font-bold cursor-pointer"
                      >
                        <option value="new">طلب جديد</option>
                        <option value="confirmed">تم تأكيد الطلب</option>
                        <option value="preparing">قيد التجهيز</option>
                        <option value="out_for_delivery">خرج للتوصيل</option>
                        <option value="delivered">تم التوصيل</option>
                        <option value="cancelled">إلغاء الطلب</option>
                      </select>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Store Reviews View */}
      <div className="bg-white rounded-3xl border border-zinc-200/90 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
            <h2 className="text-base font-black text-zinc-900">
              تقييمات الزبائن لمنتجات المتجر ({storeReviews.length})
            </h2>
          </div>
          <span className="text-xs text-zinc-400">
            وفق سياسة النزاهة: لا يستطيع التاجر حذف أو تعديل تقييمات المشترين.
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {storeReviews.length === 0 ? (
            <div className="col-span-2 text-center py-6 text-zinc-400 text-xs">
              لا توجد تقييمات مسجلة لمنتجات هذا المتجر حتى الآن.
            </div>
          ) : (
            storeReviews.map(r => (
              <div key={r.id} className="p-3.5 bg-zinc-50 rounded-2xl border border-zinc-200 space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-900">{r.productName}</span>
                  <div className="flex items-center">
                    {[1, 2, 3, 4, 5].map(st => (
                      <Star
                        key={st}
                        className={`w-3 h-3 ${st <= r.rating ? 'fill-amber-400 text-amber-400' : 'text-zinc-200'}`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-zinc-600 text-[11px] leading-relaxed">{r.comment || 'بدون تعليق'}</p>
                <div className="text-[10px] text-zinc-400 pt-1 border-t border-zinc-200/60 flex justify-between">
                  <span>بواسطة: {r.userName}</span>
                  <span>{new Date(r.createdAt).toLocaleDateString('ar-IQ')}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl p-6 border border-zinc-200">
            <h3 className="text-lg font-black text-zinc-900 mb-4 flex items-center gap-2">
              <Package className="w-5 h-5 text-purple-700" />
              <span>{editingProduct ? 'تعديل بيانات المنتج' : 'إضافة منتج جديد للمتجر'}</span>
            </h3>

            {formError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl mb-4 font-bold">
                {formError}
              </div>
            )}

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-zinc-700 mb-1">اسم المنتج *</label>
                <input
                  type="text"
                  required
                  value={prodName}
                  onChange={e => setProdName(e.target.value)}
                  placeholder="مثال: تمور برحي فاخرة معبأة"
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-zinc-700 mb-1">السعر (د.ع) *</label>
                  <input
                    type="number"
                    required
                    value={prodPrice}
                    onChange={e => setProdPrice(e.target.value)}
                    placeholder="25000"
                    className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600"
                  />
                </div>

                <div>
                  <label className="block font-bold text-zinc-700 mb-1">
                    السعر السابق (لإظهار الخصم)
                  </label>
                  <input
                    type="number"
                    value={prodOriginalPrice}
                    onChange={e => setProdOriginalPrice(e.target.value)}
                    placeholder="30000"
                    className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">القسم *</label>
                <select
                  value={prodCategoryId}
                  onChange={e => setProdCategoryId(e.target.value)}
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl bg-white focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 cursor-pointer"
                >
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">صورة المنتج *</label>
                <div className="flex items-center gap-3">
                  {prodImagePreview && (
                    <img
                      src={prodImagePreview}
                      alt="معاينة"
                      className="w-16 h-16 rounded-xl object-cover border border-zinc-200"
                    />
                  )}
                  <label className="flex-1 border-2 border-dashed border-zinc-200 hover:border-purple-500 rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer transition">
                    <Upload className="w-5 h-5 text-zinc-400 mb-1" />
                    <span className="font-bold text-zinc-700">اختر صورة أو اسحبها هنا</span>
                    <span className="text-[10px] text-zinc-400">الحد الأقصى 5 ميغابايت (JPG, PNG)</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageFileChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">وصف المنتج ومواصفاته</label>
                <textarea
                  rows={3}
                  value={prodDesc}
                  onChange={e => setProdDesc(e.target.value)}
                  placeholder="اكتب وصفاً دقيقاً للمنتج ومحتوياته..."
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="stockCheck"
                  checked={prodInStock}
                  onChange={e => setProdInStock(e.target.checked)}
                  className="rounded text-purple-700 focus:ring-purple-600 cursor-pointer"
                />
                <label htmlFor="stockCheck" className="font-bold text-zinc-800 cursor-pointer">
                  المنتج متوفر حالياً في المخزن وجاهز للشحن
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-zinc-100">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-zinc-600 hover:bg-zinc-100 font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold cursor-pointer shadow-xs"
                >
                  حفظ المنتج
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Edit Store Info Modal */}
      {isStoreModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl p-6 border border-zinc-200">
            <h3 className="text-lg font-black text-zinc-900 mb-4 flex items-center gap-2">
              <Store className="w-5 h-5 text-purple-700" />
              <span>إدارة وتعديل بيانات المتجر</span>
            </h3>

            {storeModalSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl mb-4 font-bold">
                {storeModalSuccess}
              </div>
            )}

            <form onSubmit={handleSaveStore} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-zinc-700 mb-1">اسم المتجر *</label>
                <input
                  type="text"
                  required
                  value={storeNameInput}
                  onChange={e => setStoreNameInput(e.target.value)}
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">المحافظة التابع لها المتجر *</label>
                <select
                  value={storeGovInput}
                  onChange={e => setStoreGovInput(e.target.value as IraqiGovernorate)}
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl bg-white focus:ring-2 focus:ring-purple-600/30"
                >
                  {IRAQI_GOVERNORATES.map(gov => (
                    <option key={gov.id} value={gov.id}>
                      {gov.nameAr}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">هاتف التواصل للمتجر *</label>
                <input
                  type="tel"
                  required
                  value={storePhoneInput}
                  onChange={e => setStorePhoneInput(e.target.value)}
                  dir="ltr"
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">نبذة ووصف المتجر</label>
                <textarea
                  rows={3}
                  value={storeDescInput}
                  onChange={e => setStoreDescInput(e.target.value)}
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-zinc-100">
                <button
                  type="button"
                  onClick={() => setIsStoreModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-zinc-600 hover:bg-zinc-100 font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold cursor-pointer shadow-xs"
                >
                  حفظ التعديلات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
