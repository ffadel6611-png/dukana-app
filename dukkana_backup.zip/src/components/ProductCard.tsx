import React, { useState } from 'react';
import { ShoppingBag, Star, Store, Check, AlertCircle } from 'lucide-react';
import { Product } from '../types';
import { formatIQDTabular } from '../utils/currency';
import { useMarket } from '../context/MarketContext';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const { addToCart, getProductReviews } = useMarket();
  const [isAddedRecently, setIsAddedRecently] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);

  const reviews = getProductReviews(product.id);
  const avgRating =
    reviews.length > 0
      ? (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)
      : null;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.inStock) return;
    addToCart(product, 1);
    setIsAddedRecently(true);
    setTimeout(() => setIsAddedRecently(false), 1500);
  };

  return (
    <div
      onClick={() => onSelect(product)}
      className="group bg-white rounded-2xl border border-zinc-200/90 overflow-hidden shadow-xs hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 flex flex-col cursor-pointer"
    >
      {/* Product Image Slot */}
      <div className="relative aspect-[4/3] bg-zinc-100 overflow-hidden">
        {!imageFailed && product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            referrerPolicy="no-referrer"
            onError={() => setImageFailed(true)}
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-br from-purple-100/50 to-zinc-100 text-purple-900">
            <Store className="w-8 h-8 opacity-40 mb-1" />
            <span className="text-xs font-bold text-center line-clamp-1">{product.name}</span>
          </div>
        )}

        {/* Discount Badge */}
        {product.discountPercent && product.discountPercent > 0 && (
          <div className="absolute top-2.5 right-2.5 bg-rose-600 text-white text-[11px] font-black px-2 py-0.5 rounded-md shadow-xs">
            خصم {product.discountPercent}%
          </div>
        )}

        {/* Stock Status Indicator */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center">
            <span className="bg-zinc-800 text-white text-xs font-bold px-3 py-1 rounded-md">
              نفدت الكمية حالياً
            </span>
          </div>
        )}
      </div>

      {/* Product Information */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between">
        <div>
          {/* Metadata: Category & Store */}
          <div className="flex items-center gap-1.5 text-[11px] text-zinc-500 mb-1.5">
            <span className="truncate">{product.categoryName}</span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1 text-purple-800 font-semibold truncate">
              <Store className="w-3 h-3 shrink-0" />
              {product.storeName}
            </span>
          </div>

          {/* Product Title */}
          <h3 className="text-sm sm:text-base font-bold text-zinc-900 line-clamp-2 leading-snug group-hover:text-purple-900 transition-colors">
            {product.name}
          </h3>

          {/* Rating Summary (if exists) */}
          {avgRating && (
            <div className="flex items-center gap-1 mt-1 text-xs text-amber-600 font-bold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="tabular-nums">{avgRating}</span>
              <span className="text-zinc-400 font-normal text-[11px]">({reviews.length} تقييم)</span>
            </div>
          )}
        </div>

        {/* Price & Action */}
        <div className="mt-3 pt-3 border-t border-zinc-100 flex items-center justify-between gap-2">
          <div>
            <div className="text-base sm:text-lg font-black text-purple-950 tabular-nums">
              {formatIQDTabular(product.finalPrice)}
            </div>
            {product.originalPrice && product.originalPrice > product.finalPrice && (
              <div className="text-xs text-zinc-400 line-through tabular-nums -mt-1">
                {formatIQDTabular(product.originalPrice)}
              </div>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={!product.inStock}
            className={`min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              !product.inStock
                ? 'bg-zinc-100 text-zinc-400 cursor-not-allowed'
                : isAddedRecently
                ? 'bg-emerald-600 text-white'
                : 'bg-purple-700 hover:bg-purple-800 text-white shadow-xs hover:shadow-sm'
            }`}
          >
            {isAddedRecently ? (
              <>
                <Check className="w-4 h-4" />
                <span>أُضيف للسلة</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>أضف</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
