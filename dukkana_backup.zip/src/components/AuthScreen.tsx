import React, { useState, useEffect } from 'react';
import {
  User as UserIcon,
  Store,
  ShieldCheck,
  Phone,
  Send,
  KeyRound,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  X,
  ArrowRight,
  ShoppingBag,
  Sparkles,
  HelpCircle,
  MapPin,
  Lock,
  Eye,
  EyeOff,
  Check,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { DukkanaLogo } from './DukkanaLogo';
import { validateIraqiPhone, normalizeArabicDigits } from '../utils/phoneAuth';
import { IRAQI_GOVERNORATES } from '../data/governorates';
import { IraqiGovernorate, UserRole, ADMIN_PHONE_LOCAL, ADMIN_PHONE_E164 } from '../types';

interface AuthScreenProps {
  onSuccess?: (role: UserRole) => void;
  onCancel?: () => void;
  onGuestBrowse?: () => void;
  isModal?: boolean;
}

type AuthMode =
  | 'welcome'
  | 'register_choose_role'
  | 'register_form'
  | 'login_form'
  | 'otp_verify'
  | 'create_password'
  | 'forgot_password';

type AccountChoice = 'customer' | 'merchant' | 'admin_staff';

export const AuthScreen: React.FC<AuthScreenProps> = ({
  onSuccess,
  onCancel,
  onGuestBrowse,
  isModal = false,
}) => {
  const {
    requestOTPForPhone,
    verifyOTPOnly,
    loginWithPassword,
    resetPassword,
    registerAccount,
    loginWithPhone,
  } = useAuth();

  // Navigation State
  const [mode, setMode] = useState<AuthMode>('welcome');
  const [accountType, setAccountType] = useState<AccountChoice>('customer');

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [governorate, setGovernorate] = useState<IraqiGovernorate>('بغداد');
  const [storeName, setStoreName] = useState('');
  const [storeDescription, setStoreDescription] = useState('');
  const [detailedAddress, setDetailedAddress] = useState('');

  // Password fields
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Login form states
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginWithOTPMode, setLoginWithOTPMode] = useState(false);

  // OTP & Flow State
  const [otpCode, setOtpCode] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [isResetFlow, setIsResetFlow] = useState(false);
  const [cooldownSeconds, setCooldownSeconds] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Status Feedback
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Countdown timer for OTP resend
  useEffect(() => {
    let timer: any = null;
    if (cooldownSeconds > 0) {
      timer = setInterval(() => {
        setCooldownSeconds(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [cooldownSeconds]);

  // Clean error/success on mode changes
  const changeMode = (newMode: AuthMode) => {
    setErrorMsg('');
    setSuccessMsg('');
    setMode(newMode);
  };

  // ==========================================
  // Flow 1: Direct Password Login (No OTP Sent)
  // ==========================================
  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const validation = validateIraqiPhone(phone);
    if (!validation.isValid) {
      setErrorMsg(validation.errorMessage || 'يرجى إدخال رقم هاتف عراقي صحيح.');
      return;
    }

    if (!loginPassword || loginPassword.length < 6) {
      setErrorMsg('يرجى إدخال كلمة مرور صحيحة (6 خانات على الأقل).');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await loginWithPassword(phone, loginPassword);
      if (res.success) {
        setSuccessMsg(res.message);
        setTimeout(() => {
          if (onSuccess && res.detectedRole) {
            onSuccess(res.detectedRole);
          }
        }, 1000);
      } else if (res.requiresPasswordSetup) {
        // User exists but has no password yet: send OTP and force password setup
        setErrorMsg('لم يتم إنشاء كلمة مرور لهذا الحساب بعد. جاري إرسال رمز OTP لتأكيد الحساب وتعيين كلمة المرور...');
        const otpRes = await requestOTPForPhone(phone);
        if (otpRes.success) {
          setIsResetFlow(true);
          setCooldownSeconds(60);
          setSuccessMsg(otpRes.message);
          setMode('otp_verify');
        } else {
          setErrorMsg(otpRes.message);
        }
      } else {
        setErrorMsg(res.message);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // ==========================================
  // Flow 2: Send OTP (For Registration, Forgot Password, or OTP Login)
  // ==========================================
  const handleInitiateOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const validation = validateIraqiPhone(phone);
    if (!validation.isValid) {
      setErrorMsg(validation.errorMessage || 'يرجى إدخال رقم هاتف عراقي صحيح.');
      return;
    }

    if (mode === 'register_form') {
      if (!fullName.trim()) {
        setErrorMsg('يرجى إدخال الاسم بالكامل.');
        return;
      }
      if (accountType === 'merchant' && !storeName.trim()) {
        setErrorMsg('يرجى إدخال اسم المتجر التجاري.');
        return;
      }
      if (accountType === 'admin_staff' && validation.normalizedE164 !== ADMIN_PHONE_E164) {
        setErrorMsg(
          `تم رفض الطلب: رقم الهاتف (${phone}) غير مصرح له كمدير للمنصة. صلاحية المدير محصورة حصرياً بالرقم الرسمي المعتمد ${ADMIN_PHONE_LOCAL}.`
        );
        return;
      }
    }

    setIsSubmitting(true);
    try {
      const res = await requestOTPForPhone(phone);
      if (res.success) {
        setMode('otp_verify');
        setCooldownSeconds(60);
        setSuccessMsg(res.message);
      } else {
        setErrorMsg(res.message);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // ==========================================
  // Flow 3: Verify OTP
  // ==========================================
  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanCode = normalizeArabicDigits(otpCode.trim()).replace(/\D/g, '');
    if (!cleanCode || cleanCode.length !== 6) {
      setErrorMsg('يرجى إدخال رمز التحقق المكوّن من 6 أرقام.');
      return;
    }

    setIsSubmitting(true);
    try {
      const verifyRes = await verifyOTPOnly(phone, cleanCode);
      if (!verifyRes.success) {
        setErrorMsg(verifyRes.message);
        return;
      }

      setResetToken(verifyRes.resetToken || '');

      // 1. New Registration -> Transition to Create Password
      if (mode === 'otp_verify' && fullName && !isResetFlow) {
        setSuccessMsg('تم التحقق من الرمز بنجاح! يرجى الآن إنشاء كلمة مرور لحسابك الجديد.');
        setMode('create_password');
        return;
      }

      // 2. Forgot Password flow -> Transition to Set New Password
      if (isResetFlow) {
        setSuccessMsg('تم التحقق من الرمز بنجاح! أدخل كلمة المرور الجديدة لحسابك.');
        setMode('create_password');
        return;
      }

      // 3. User logged in via OTP directly: check if user has password
      if (!verifyRes.hasPassword) {
        setSuccessMsg('تم التحقق بنجاح! لم يتم تعيين كلمة مرور لهذا الحساب مسبقاً. يرجى إنشاء كلمة مرور للمتابعة.');
        setIsResetFlow(true);
        setMode('create_password');
        return;
      }

      // 4. User logged in via OTP and already has password (already logged in via verifyOTPOnly)
      setSuccessMsg(verifyRes.message || 'تم تسجيل الدخول بنجاح.');
      setTimeout(() => {
        if (onSuccess) {
          const detectedRole = (verifyRes.user?.role as UserRole) || (phone === ADMIN_PHONE_LOCAL ? 'admin' : 'customer');
          onSuccess(detectedRole);
        }
      }, 1000);
    } finally {
      setIsSubmitting(false);
    }
  };

  // ==========================================
  // Flow 4: Create or Reset Password Submit
  // ==========================================
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!password || password.length < 6) {
      setErrorMsg('يجب ألا تقل كلمة المرور عن 6 خانات (أحرف أو أرقام).');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('كلمتا المرور غير متطابقتين. يرجى التأكد وإعادة الإدخال.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (isResetFlow) {
        // Forgot password or setting password for existing user
        const res = await resetPassword(phone, resetToken, password);
        if (res.success) {
          setSuccessMsg(res.message);
          setTimeout(() => {
            if (onSuccess && res.detectedRole) {
              onSuccess(res.detectedRole);
            }
          }, 1200);
        } else {
          setErrorMsg(res.message);
        }
      } else {
        // New user registration
        const regRes = await registerAccount({
          accountType,
          phone,
          password,
          resetToken,
          fullName,
          governorate,
          storeName: accountType === 'merchant' ? storeName : undefined,
          storeDescription: accountType === 'merchant' ? storeDescription : undefined,
          address: detailedAddress,
        });

        if (regRes.success) {
          setSuccessMsg(regRes.message);
          setTimeout(() => {
            if (onSuccess && regRes.assignedRole) {
              onSuccess(regRes.assignedRole);
            }
          }, 1200);
        } else {
          setErrorMsg(regRes.message);
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // Resend OTP
  const handleResend = async () => {
    if (cooldownSeconds > 0) return;
    setErrorMsg('');
    setIsSubmitting(true);
    try {
      const res = await requestOTPForPhone(phone);
      if (res.success) {
        setCooldownSeconds(60);
        setSuccessMsg(res.message);
      } else {
        setErrorMsg(res.message);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={`w-full ${isModal ? '' : 'min-h-[85vh] flex items-center justify-center py-8 px-4'}`}>
      <div className="relative w-full max-w-xl mx-auto bg-white rounded-3xl shadow-xl border border-zinc-200 overflow-hidden">
        {/* Modal Close Button */}
        {onCancel && isModal && (
          <button
            onClick={onCancel}
            className="absolute top-4 left-4 p-2 rounded-xl text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 transition z-10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-purple-950 via-purple-900 to-indigo-950 text-white p-6 sm:p-7 relative border-b border-purple-800/40">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <DukkanaLogo
              size="lg"
              theme="white"
              variant="full"
              sublineText="بوابة الحسابات المعتمدة لكافة محافظات العراق الـ 18"
            />
            <span className="text-[11px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold px-3 py-1 rounded-full shadow-xs">
              نظام التوثيق الرسمي
            </span>
          </div>
        </div>

        {/* Status Alerts */}
        <div className="p-6 pb-2 space-y-3">
          {errorMsg && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold rounded-2xl flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}
        </div>

        {/* STEP 1: WELCOME SCREEN (Two Clear Primary Options) */}
        {mode === 'welcome' && (
          <div className="p-6 sm:p-8 pt-4 space-y-6">
            <div className="text-center space-y-2">
              <h2 className="text-xl sm:text-2xl font-black text-zinc-900">
                مرحباً بك في دكانة
              </h2>
              <p className="text-xs text-zinc-500 max-w-md mx-auto">
                اختر ما إذا كنت ترغب في إنشاء حساب جديد واختيار نوع حسابك (زبون، تاجر، موظف/مدير)، أو تسجيل الدخول لحسابك الحالي.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {/* Option 1: Create New Account */}
              <button
                onClick={() => {
                  setIsResetFlow(false);
                  changeMode('register_choose_role');
                }}
                className="p-6 bg-purple-700 hover:bg-purple-800 text-white rounded-3xl transition shadow-lg shadow-purple-900/20 text-right space-y-3 group cursor-pointer border border-purple-600 flex flex-col justify-between"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-white">
                  <UserIcon className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-purple-200 block">
                    مستخدم جديد لأول مرة
                  </span>
                  <h3 className="text-lg font-black mt-0.5 group-hover:translate-x-[-2px] transition-transform">
                    1. إنشاء حساب جديد
                  </h3>
                  <p className="text-xs text-purple-100/90 mt-1.5 leading-relaxed">
                    حدد نوع حسابك (زبون، تاجر، موظف/مدير) وتحقق برقم الهاتف وأنشئ كلمة مرورك.
                  </p>
                </div>
              </button>

              {/* Option 2: Sign In */}
              <button
                onClick={() => {
                  setFullName('');
                  setIsResetFlow(false);
                  setLoginWithOTPMode(false);
                  changeMode('login_form');
                }}
                className="p-6 bg-zinc-50 hover:bg-zinc-100 text-zinc-900 rounded-3xl transition border border-zinc-200 text-right space-y-3 group cursor-pointer flex flex-col justify-between"
              >
                <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-800 flex items-center justify-center">
                  <KeyRound className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-zinc-500 block">
                    لديك حساب مسجل مسبقاً
                  </span>
                  <h3 className="text-lg font-black mt-0.5 group-hover:translate-x-[-2px] transition-transform">
                    2. تسجيل الدخول
                  </h3>
                  <p className="text-xs text-zinc-600 mt-1.5 leading-relaxed">
                    تسجيل الدخول المباشر برقم الهاتف وكلمة المرور بدون الحاجة لانتظار رمز OTP.
                  </p>
                </div>
              </button>
            </div>

            {/* Guest browsing option */}
            {onGuestBrowse && (
              <div className="pt-2 text-center border-t border-zinc-100">
                <button
                  onClick={onGuestBrowse}
                  className="text-xs text-zinc-500 hover:text-purple-700 font-bold transition inline-flex items-center gap-1.5 cursor-pointer py-1"
                >
                  <span>تصفح سوق دكانة كزائر أولاً</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: CHOOSE ACCOUNT ROLE (Customer / Merchant / Staff & Admin) */}
        {mode === 'register_choose_role' && (
          <div className="p-6 sm:p-8 pt-4 space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div>
                <h2 className="text-lg font-black text-zinc-900">
                  اختر نوع الحساب المراد إنشاؤه
                </h2>
                <p className="text-xs text-zinc-500 mt-0.5">
                  النظام يقوم بتوثيق الصلاحية وتخصيص واجهتك وفق اختيارك والتحقق الأمني.
                </p>
              </div>
              <button
                onClick={() => changeMode('welcome')}
                className="text-xs text-zinc-500 hover:text-purple-700 font-bold cursor-pointer"
              >
                العودة
              </button>
            </div>

            <div className="space-y-3">
              {/* Role 1: Customer */}
              <button
                onClick={() => {
                  setAccountType('customer');
                  changeMode('register_form');
                }}
                className="w-full p-4 rounded-2xl border-2 border-zinc-200 hover:border-purple-600 hover:bg-purple-50/40 text-right transition flex items-start gap-4 group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 group-hover:bg-purple-700 group-hover:text-white transition">
                  <ShoppingBag className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-black text-sm text-zinc-900">
                      1. حساب زبون (مشتري)
                    </h3>
                    <span className="text-[11px] font-bold text-purple-700 bg-purple-100 px-2.5 py-0.5 rounded-full">
                      تسوّق ودفع نقدي
                    </span>
                  </div>
                  <p className="text-xs text-zinc-600 mt-1 leading-relaxed">
                    تصفح آلاف المنتجات العراقية، طلب البضائع بالدينار العراقي، والدفع عند الاستلام (COD) مع متابعة حالة الشحنة.
                  </p>
                </div>
              </button>

              {/* Role 2: Merchant */}
              <button
                onClick={() => {
                  setAccountType('merchant');
                  changeMode('register_form');
                }}
                className="w-full p-4 rounded-2xl border-2 border-zinc-200 hover:border-purple-600 hover:bg-purple-50/40 text-right transition flex items-start gap-4 group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 group-hover:bg-amber-600 group-hover:text-white transition">
                  <Store className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-black text-sm text-zinc-900">
                      2. حساب تاجر (صاحب متجر)
                    </h3>
                    <span className="text-[11px] font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full">
                      لوحة المتجر والمبيعات
                    </span>
                  </div>
                  <p className="text-xs text-zinc-600 mt-1 leading-relaxed">
                    إنشاء متجرك التجاري، إضافة وتعديل المنتجات والأسعار، واستقبال طلبات الزبائن وإدارة الأرباح في محافظتك.
                  </p>
                </div>
              </button>

              {/* Role 3: Staff / Admin */}
              <button
                onClick={() => {
                  setAccountType('admin_staff');
                  changeMode('register_form');
                }}
                className="w-full p-4 rounded-2xl border-2 border-zinc-200 hover:border-purple-600 hover:bg-purple-50/40 text-right transition flex items-start gap-4 group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 group-hover:bg-indigo-700 group-hover:text-white transition">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-black text-sm text-zinc-900">
                      3. حساب موظف / مدير
                    </h3>
                    <span className="text-[11px] font-bold text-indigo-800 bg-indigo-100 px-2.5 py-0.5 rounded-full">
                      إدارة ودعم فني
                    </span>
                  </div>
                  <p className="text-xs text-zinc-600 mt-1 leading-relaxed">
                    إدارة المنصة وفريق خدمة العملاء. (ملاحظة: صلاحية المدير الكاملة مشروطة بالرقم المعتمد {ADMIN_PHONE_LOCAL} فقط).
                  </p>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: REGISTRATION FORM */}
        {mode === 'register_form' && (
          <form onSubmit={handleInitiateOTP} className="p-6 sm:p-8 pt-4 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div>
                <h2 className="text-base sm:text-lg font-black text-zinc-900">
                  {accountType === 'customer'
                    ? 'تسجيل حساب زبون جديد'
                    : accountType === 'merchant'
                    ? 'تسجيل حساب تاجر ومتجر جديد'
                    : 'تسجيل حساب موظف / مدير'}
                </h2>
                <p className="text-[11px] text-zinc-500">
                  الخطوة 1 من 2: التحقق برقم الهاتف العراقي عبر رمز OTP
                </p>
              </div>
              <button
                type="button"
                onClick={() => changeMode('register_choose_role')}
                className="text-xs text-zinc-500 hover:text-purple-700 font-bold cursor-pointer"
              >
                تغيير النوع
              </button>
            </div>

            {/* Special Notice for Admin / Staff */}
            {accountType === 'admin_staff' && (
              <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 rounded-2xl text-[11px] space-y-1">
                <div className="font-black flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-amber-700" />
                  <span>تنبيه أمني لصلاحيات المدير:</span>
                </div>
                <p className="leading-relaxed">
                  الرقم الوحيد المسموح له بالحصول على صلاحية المدير الرئيسي (Admin) هو: <strong>{ADMIN_PHONE_LOCAL}</strong>.
                  أي رقم آخر يسجل كـ «موظف/مدير» سيُسجل كموظف دعم فني فقط ولن يحصل على صلاحيات Admin كاملة.
                </p>
              </div>
            )}

            {/* Full Name */}
            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                {accountType === 'merchant' ? 'اسم صاحب المتجر / المسؤول *' : 'الاسم الكامل *'}
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={e => setFullName(e.target.value)}
                placeholder="مثال: أحمد عبد الله الكرخي"
                className="w-full px-3.5 py-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 text-xs font-semibold"
              />
            </div>

            {/* Merchant Specific: Store Name & Activity */}
            {accountType === 'merchant' && (
              <>
                <div>
                  <label className="block font-bold text-zinc-700 mb-1">
                    اسم المتجر التجاري *
                  </label>
                  <input
                    type="text"
                    required
                    value={storeName}
                    onChange={e => setStoreName(e.target.value)}
                    placeholder="مثال: تمور الفيحاء الملكية / أزياء بابل"
                    className="w-full px-3.5 py-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-zinc-700 mb-1">
                    وصف المتجر ونوع المنتجات
                  </label>
                  <input
                    type="text"
                    value={storeDescription}
                    onChange={e => setStoreDescription(e.target.value)}
                    placeholder="مثال: بيع الألبسة والجلابيات، تمور، مواد منزلية..."
                    className="w-full px-3.5 py-2.5 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 text-xs"
                  />
                </div>
              </>
            )}

            {/* Phone Number */}
            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                رقم الهاتف العراقي (لإرسال رمز OTP) *
              </label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="07701234567 أو +9647801234567"
                  dir="ltr"
                  className="w-full px-3.5 py-2.5 text-left border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 font-mono tracking-wide text-xs"
                />
                <span className="absolute right-3 top-2.5 text-xs text-purple-700 font-bold pointer-events-none">
                  العراق 🇮🇶
                </span>
              </div>
            </div>

            {/* Governorate */}
            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                {accountType === 'merchant' ? 'المحافظة (مقر المتجر) *' : 'المحافظة *'}
              </label>
              <select
                value={governorate}
                onChange={e => setGovernorate(e.target.value as IraqiGovernorate)}
                className="w-full px-3.5 py-2.5 border border-zinc-200 rounded-xl bg-white text-xs font-semibold"
              >
                {IRAQI_GOVERNORATES.map(gov => (
                  <option key={gov.id} value={gov.id}>
                    {gov.nameAr}
                  </option>
                ))}
              </select>
            </div>

            {/* Address (For Customer) */}
            {accountType === 'customer' && (
              <div>
                <label className="block font-bold text-zinc-700 mb-1">
                  العنوان التفصيلي للتوصيل (اختياري)
                </label>
                <input
                  type="text"
                  value={detailedAddress}
                  onChange={e => setDetailedAddress(e.target.value)}
                  placeholder="مثال: الكرادة خارج، محلة 903، زقاق 12"
                  className="w-full px-3.5 py-2.5 border border-zinc-200 rounded-xl text-xs"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-purple-700 hover:bg-purple-800 text-white font-black rounded-xl transition cursor-pointer shadow-md shadow-purple-700/20 flex items-center justify-center gap-2 mt-2 disabled:opacity-60"
            >
              <span>{isSubmitting ? 'جاري الإرسال...' : 'إرسال رمز التحقق OTP للرقم'}</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* STEP 4: LOGIN FORM (Phone + Password Direct Login, or OTP switch) */}
        {mode === 'login_form' && (
          <form
            onSubmit={loginWithOTPMode ? handleInitiateOTP : handlePasswordLogin}
            className="p-6 sm:p-8 pt-4 space-y-4 text-xs"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div>
                <h2 className="text-base sm:text-lg font-black text-zinc-900">
                  {loginWithOTPMode ? 'تسجيل الدخول عبر رمز التحقق OTP' : 'تسجيل الدخول إلى حسابك'}
                </h2>
                <p className="text-[11px] text-zinc-500">
                  {loginWithOTPMode
                    ? 'أدخل رقم هاتفك لتلقي رمز التحقق OTP للدخول'
                    : 'أدخل رقم هاتفك وكلمة المرور للدخول المباشر إلى حسابك'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => changeMode('welcome')}
                className="text-xs text-zinc-500 hover:text-purple-700 font-bold cursor-pointer"
              >
                العودة
              </button>
            </div>

            {/* Phone Number Input */}
            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                رقم الهاتف العراقي المسجل *
              </label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="07701234567 أو 07862214922"
                  dir="ltr"
                  className="w-full px-3.5 py-3 text-left border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 font-mono tracking-wide text-sm font-bold"
                />
                <span className="absolute right-3 top-3 text-xs text-purple-700 font-bold pointer-events-none">
                  العراق 🇮🇶
                </span>
              </div>
              <span className="text-[11px] text-zinc-400 mt-1 block">
                يقبل كافة الشبكات العراقية: زين، آسياسيل، وكورك.
              </span>
            </div>

            {/* Password Input (Direct Login mode) */}
            {!loginWithOTPMode && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-zinc-700">
                    كلمة المرور *
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsResetFlow(true);
                      changeMode('forgot_password');
                    }}
                    className="text-[11px] text-purple-700 hover:text-purple-900 font-bold cursor-pointer hover:underline"
                  >
                    نسيت كلمة المرور؟
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={e => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    dir="ltr"
                    className="w-full px-3.5 py-3 pl-10 text-left border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 font-mono text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute left-3 top-3 text-zinc-400 hover:text-zinc-700 cursor-pointer"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-purple-700 hover:bg-purple-800 text-white font-black rounded-xl transition cursor-pointer shadow-md shadow-purple-700/20 flex items-center justify-center gap-2 mt-2 disabled:opacity-60"
            >
              {loginWithOTPMode ? (
                <>
                  <span>{isSubmitting ? 'جاري الإرسال...' : 'إرسال رمز التحقق OTP للدخول'}</span>
                  <Send className="w-4 h-4" />
                </>
              ) : (
                <>
                  <span>{isSubmitting ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}</span>
                  <KeyRound className="w-4 h-4" />
                </>
              )}
            </button>

            {/* Switch between Password and OTP Login */}
            <div className="pt-2 text-center flex flex-col items-center gap-2 border-t border-zinc-100">
              <button
                type="button"
                onClick={() => {
                  setErrorMsg('');
                  setLoginWithOTPMode(!loginWithOTPMode);
                }}
                className="text-xs text-zinc-600 hover:text-purple-700 font-semibold cursor-pointer underline"
              >
                {loginWithOTPMode
                  ? 'تسجيل الدخول بكلمة المرور بدلاً من رمز OTP'
                  : 'تسجيل الدخول عبر رمز التحقق OTP'}
              </button>

              <div className="text-zinc-500">
                ليس لديك حساب بعد؟{' '}
                <button
                  type="button"
                  onClick={() => changeMode('register_choose_role')}
                  className="text-purple-700 font-bold hover:underline cursor-pointer"
                >
                  إنشاء حساب جديد
                </button>
              </div>
            </div>
          </form>
        )}

        {/* STEP 5: FORGOT PASSWORD */}
        {mode === 'forgot_password' && (
          <form onSubmit={handleInitiateOTP} className="p-6 sm:p-8 pt-4 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div>
                <h2 className="text-base sm:text-lg font-black text-zinc-900">
                  استعادة كلمة المرور
                </h2>
                <p className="text-[11px] text-zinc-500">
                  أدخل رقم هاتفك المسجل وسنرسل لك رمز OTP عبر SMS لتعيين كلمة مرور جديدة
                </p>
              </div>
              <button
                type="button"
                onClick={() => changeMode('login_form')}
                className="text-xs text-zinc-500 hover:text-purple-700 font-bold cursor-pointer"
              >
                العودة
              </button>
            </div>

            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                رقم الهاتف العراقي المسجل *
              </label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="07701234567 أو 07862214922"
                  dir="ltr"
                  className="w-full px-3.5 py-3 text-left border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 font-mono tracking-wide text-sm font-bold"
                />
                <span className="absolute right-3 top-3 text-xs text-purple-700 font-bold pointer-events-none">
                  العراق 🇮🇶
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-purple-700 hover:bg-purple-800 text-white font-black rounded-xl transition cursor-pointer shadow-md shadow-purple-700/20 flex items-center justify-center gap-2 mt-2 disabled:opacity-60"
            >
              <span>{isSubmitting ? 'جاري الإرسال...' : 'إرسال رمز التحقق OTP'}</span>
              <Send className="w-4 h-4" />
            </button>

            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => changeMode('login_form')}
                className="text-purple-700 font-bold hover:underline cursor-pointer"
              >
                تذكرت كلمة المرور؟ تسجيل الدخول الآن
              </button>
            </div>
          </form>
        )}

        {/* STEP 6: OTP VERIFICATION */}
        {mode === 'otp_verify' && (
          <form onSubmit={handleVerifyOTP} className="p-6 sm:p-8 pt-4 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div>
                <h2 className="text-base sm:text-lg font-black text-zinc-900">
                  التحقق من رمز OTP
                </h2>
                <p className="text-[11px] text-zinc-500">
                  تم إرسال رمز التحقق إلى الرقم <span className="font-mono font-bold text-zinc-800" dir="ltr">{phone}</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => changeMode(fullName ? 'register_form' : 'login_form')}
                className="text-xs text-zinc-500 hover:text-purple-700 font-bold cursor-pointer"
              >
                تغيير الرقم
              </button>
            </div>

            <div>
              <label className="block font-bold text-zinc-700 mb-1 text-center">
                أدخل رمز التحقق (6 أرقام) *
              </label>
              <input
                type="text"
                required
                maxLength={6}
                value={otpCode}
                onChange={e => setOtpCode(e.target.value)}
                placeholder="• • • • • •"
                dir="ltr"
                className="w-full px-4 py-3 text-center text-xl tracking-[0.5em] font-mono font-black border border-purple-300 rounded-2xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600"
              />
              <span className="text-[11px] text-zinc-400 mt-1 block text-center">
                صلاحية الرمز 5 دقائق · الحد الأقصى 3 محاولات إدخال
              </span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-purple-700 hover:bg-purple-800 text-white font-black rounded-xl transition cursor-pointer shadow-md shadow-purple-700/20 text-sm disabled:opacity-60"
            >
              {isSubmitting ? 'جاري التحقق...' : 'تأكيد الرمز والمتابعة'}
            </button>

            {/* Resend & Cooldown */}
            <div className="flex items-center justify-between pt-2 border-t border-zinc-100">
              <span className="text-zinc-500">لم يصلك الرمز؟</span>
              <button
                type="button"
                disabled={cooldownSeconds > 0 || isSubmitting}
                onClick={handleResend}
                className="text-purple-700 disabled:text-zinc-400 font-bold flex items-center gap-1 cursor-pointer disabled:cursor-not-allowed"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>
                  {cooldownSeconds > 0
                    ? `إعادة الإرسال بعد ${cooldownSeconds} ثانية`
                    : 'إعادة إرسال الرمز الآن'}
                </span>
              </button>
            </div>
          </form>
        )}

        {/* STEP 7: CREATE OR RESET PASSWORD */}
        {mode === 'create_password' && (
          <form onSubmit={handlePasswordSubmit} className="p-6 sm:p-8 pt-4 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div>
                <h2 className="text-base sm:text-lg font-black text-zinc-900">
                  {isResetFlow ? 'تعيين كلمة مرور جديدة' : 'إنشاء كلمة مرور لحسابك'}
                </h2>
                <p className="text-[11px] text-zinc-500">
                  {isResetFlow
                    ? 'أدخل كلمة المرور الجديدة وأكدها لتحديث حسابك والدخول به'
                    : 'أنشئ كلمة مرور قوية للدخول بها مستقبلاً مباشرة بدون انتظار رمز OTP'}
                </p>
              </div>
            </div>

            {/* New Password */}
            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                {isResetFlow ? 'كلمة المرور الجديدة *' : 'كلمة المرور *'}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  dir="ltr"
                  className="w-full px-3.5 py-3 pl-10 text-left border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 font-mono text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-3 text-zinc-400 hover:text-zinc-700 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                تأكيد كلمة المرور *
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  dir="ltr"
                  className="w-full px-3.5 py-3 pl-10 text-left border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 font-mono text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute left-3 top-3 text-zinc-400 hover:text-zinc-700 cursor-pointer"
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Password Validation Checklist */}
            <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-2xl space-y-1.5 text-[11px]">
              <div className="flex items-center gap-1.5">
                <Check
                  className={`w-3.5 h-3.5 ${
                    password.length >= 6 ? 'text-emerald-600' : 'text-zinc-300'
                  }`}
                />
                <span className={password.length >= 6 ? 'text-zinc-800 font-semibold' : 'text-zinc-500'}>
                  6 خانات على الأقل
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <Check
                  className={`w-3.5 h-3.5 ${
                    password && password === confirmPassword ? 'text-emerald-600' : 'text-zinc-300'
                  }`}
                />
                <span className={password && password === confirmPassword ? 'text-zinc-800 font-semibold' : 'text-zinc-500'}>
                  تطابق كلمتي المرور
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || password.length < 6 || password !== confirmPassword}
              className="w-full py-3 bg-purple-700 hover:bg-purple-800 text-white font-black rounded-xl transition cursor-pointer shadow-md shadow-purple-700/20 text-sm disabled:opacity-50"
            >
              {isSubmitting
                ? 'جاري الحفظ...'
                : isResetFlow
                ? 'حفظ كلمة المرور والدخول للحساب'
                : 'إنشاء كلمة المرور وإتمام التسجيل'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
