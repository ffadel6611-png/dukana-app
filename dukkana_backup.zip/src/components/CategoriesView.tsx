import React from 'react';
import {
  LayoutGrid,
  ShoppingBag,
  Home,
  UtensilsCrossed,
  Tag,
  Percent,
  Check,
} from 'lucide-react';
import { useMarket } from '../context/MarketContext';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface CategoriesViewProps {
  onSelectProduct: (product: Product) => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({ onSelectProduct }) => {
  const {
    categories,
    selectedCategorySlug,
    setSelectedCategorySlug,
    selectedDiscount,
    setSelectedDiscount,
    getFilteredProductsForCustomer,
  } = useMarket();

  const filteredProducts = getFilteredProductsForCustomer();

  const getCategoryIcon = (slug: string) => {
    switch (slug) {
      case 'home-goods':
        return <Home className="w-5 h-5" />;
      case 'food-products':
        return <ShoppingBag className="w-5 h-5" />;
      case 'restaurants':
        return <UtensilsCrossed className="w-5 h-5" />;
      default:
        return <LayoutGrid className="w-5 h-5" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Categories & Discounts Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-zinc-900 flex items-center gap-2">
          <LayoutGrid className="w-6 h-6 text-purple-700" />
          <span>أقسام سوق دكانة والخصومات</span>
        </h1>
        <p className="text-xs text-zinc-500 mt-1">
          تصفح المنتجات العراقية الأصلية حسب الصنف ونسبة الخصم
        </p>
      </div>

      {/* Discount Tiers (10%, 30%, 50%) */}
      <div className="bg-white rounded-3xl border border-zinc-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-zinc-800">
          <Percent className="w-4 h-4 text-purple-700" />
          <span>عروض التخفيضات الخاصة:</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setSelectedDiscount(null)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              selectedDiscount === null
                ? 'bg-purple-700 text-white shadow-xs'
                : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
            }`}
          >
            كافة الأسعار
          </button>
          <button
            onClick={() => setSelectedDiscount(10)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              selectedDiscount === 10
                ? 'bg-purple-700 text-white shadow-xs'
                : 'bg-purple-50 text-purple-900 border border-purple-200 hover:bg-purple-100'
            }`}
          >
            <span>خصومات 10% فأكثر</span>
            {selectedDiscount === 10 && <Check className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => setSelectedDiscount(30)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              selectedDiscount === 30
                ? 'bg-purple-700 text-white shadow-xs'
                : 'bg-purple-50 text-purple-900 border border-purple-200 hover:bg-purple-100'
            }`}
          >
            <span>خصومات 30% فأكثر</span>
            {selectedDiscount === 30 && <Check className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => setSelectedDiscount(50)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              selectedDiscount === 50
                ? 'bg-purple-700 text-white shadow-xs'
                : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
            }`}
          >
            <span>خصومات كبرى 50% فأكثر</span>
            {selectedDiscount === 50 && <Check className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Category Cards Selector */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {categories.map(cat => {
          const isSelected = selectedCategorySlug === cat.slug;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategorySlug(cat.slug)}
              className={`p-4 rounded-2xl border text-right transition cursor-pointer flex flex-col justify-between h-28 ${
                isSelected
                  ? 'bg-purple-700 text-white border-purple-700 shadow-md shadow-purple-700/20'
                  : 'bg-white text-zinc-900 border-zinc-200 hover:border-purple-300 hover:bg-purple-50/30'
              }`}
            >
              <div className="flex items-center justify-between">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-purple-100 text-purple-700'
                  }`}
                >
                  {getCategoryIcon(cat.slug)}
                </div>
                {isSelected && <span className="text-[10px] font-bold">نشط</span>}
              </div>

              <div>
                <span className="font-bold text-sm block line-clamp-1">{cat.name}</span>
                <span
                  className={`text-[10px] block line-clamp-1 ${
                    isSelected ? 'text-purple-200' : 'text-zinc-400'
                  }`}
                >
                  {cat.description || 'تصفح منتجات القسم'}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Filtered Products Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-black text-zinc-900">
            المنتجات المعروضة ({filteredProducts.length})
          </h2>
          {(selectedCategorySlug !== 'all' || selectedDiscount !== null) && (
            <button
              onClick={() => {
                setSelectedCategorySlug('all');
                setSelectedDiscount(null);
              }}
              className="text-xs text-purple-700 font-bold hover:underline cursor-pointer"
            >
              إعادة ضبط الفلاتر
            </button>
          )}
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-zinc-200 p-8">
            <Tag className="w-12 h-12 text-zinc-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-zinc-800">لا توجد منتجات تطابق هذا الفلتر حالياً</h3>
            <p className="text-xs text-zinc-400 mt-1">
              جرب تغيير القسم أو تخفيض نسبة الخصم لمشاهدة بقية المنتجات.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filteredProducts.map(p => (
              <ProductCard key={p.id} product={p} onSelect={onSelectProduct} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
