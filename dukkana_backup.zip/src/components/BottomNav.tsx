import React from 'react';
import {
  Home,
  LayoutGrid,
  ShoppingBag,
  PackageCheck,
  User as UserIcon,
  Store,
  ShieldCheck,
  HelpCircle,
} from 'lucide-react';
import { useMarket } from '../context/MarketContext';
import { useAuth } from '../context/AuthContext';

interface BottomNavProps {
  activeView: 'home' | 'categories' | 'orders' | 'profile' | 'merchant' | 'admin' | 'support';
  setActiveView: (view: 'home' | 'categories' | 'orders' | 'profile' | 'merchant' | 'admin' | 'support') => void;
  onOpenCart: () => void;
  onOpenAuth?: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeView,
  setActiveView,
  onOpenCart,
  onOpenAuth,
}) => {
  const { getCartTotalCount } = useMarket();
  const { role, isSupport, isAdmin, isMerchant, isAuthenticated } = useAuth();
  const cartCount = getCartTotalCount();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-zinc-200 pb-safe">
      <div className="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-1">
        {/* Tab 1: Home */}
        <button
          onClick={() => setActiveView('home')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] cursor-pointer transition-colors ${
            activeView === 'home' ? 'text-purple-700 font-bold' : 'text-zinc-500 hover:text-zinc-800'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[11px] mt-1 tracking-tight">الرئيسية</span>
        </button>

        {/* Tab 2: Categories */}
        <button
          onClick={() => setActiveView('categories')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] cursor-pointer transition-colors ${
            activeView === 'categories' ? 'text-purple-700 font-bold' : 'text-zinc-500 hover:text-zinc-800'
          }`}
        >
          <LayoutGrid className="w-5 h-5" />
          <span className="text-[11px] mt-1 tracking-tight">الأقسام</span>
        </button>

        {/* Tab 3: Cart */}
        <button
          onClick={onOpenCart}
          className="relative flex flex-col items-center justify-center h-full min-h-[44px] cursor-pointer text-zinc-500 hover:text-zinc-800 transition-colors"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-2.5 min-w-[18px] h-[18px] rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center px-0.5">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[11px] mt-1 tracking-tight">السلة</span>
        </button>

        {/* Tab 4: Orders */}
        <button
          onClick={() => setActiveView('orders')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] cursor-pointer transition-colors ${
            activeView === 'orders' ? 'text-purple-700 font-bold' : 'text-zinc-500 hover:text-zinc-800'
          }`}
        >
          <PackageCheck className="w-5 h-5" />
          <span className="text-[11px] mt-1 tracking-tight">طلباتي</span>
        </button>

        {/* Tab 5: Dynamic Role Tab (Merchant / Admin / Support / Profile / Auth) */}
        <button
          onClick={() => {
            if (!isAuthenticated) {
              if (onOpenAuth) onOpenAuth();
              return;
            }
            if (isAdmin) setActiveView('admin');
            else if (isMerchant) setActiveView('merchant');
            else setActiveView('profile');
          }}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] cursor-pointer transition-colors ${
            activeView === 'profile' || activeView === 'merchant' || activeView === 'admin' || activeView === 'support'
              ? 'text-purple-700 font-bold'
              : 'text-zinc-500 hover:text-zinc-800'
          }`}
        >
          {!isAuthenticated ? (
            <UserIcon className="w-5 h-5 text-purple-700" />
          ) : isAdmin ? (
            <ShieldCheck className="w-5 h-5" />
          ) : isMerchant ? (
            <Store className="w-5 h-5" />
          ) : (
            <UserIcon className="w-5 h-5" />
          )}
          <span className="text-[11px] mt-1 tracking-tight">
            {!isAuthenticated ? 'دخول / تسجيل' : isAdmin ? 'الإدارة' : isMerchant ? 'المتجر' : 'حسابي'}
          </span>
        </button>
      </div>
    </nav>
  );
};
