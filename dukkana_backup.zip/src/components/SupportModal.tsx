import React from 'react';
import {
  X,
  HelpCircle,
  MessageCircle,
  Phone,
  ShieldCheck,
  Truck,
  RotateCcw,
  ChevronDown,
} from 'lucide-react';
import { useMarket } from '../context/MarketContext';

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupportModal: React.FC<SupportModalProps> = ({ isOpen, onClose }) => {
  const { settings } = useMarket();

  if (!isOpen) return null;

  // Clean WhatsApp phone for direct link
  const cleanWhatsAppNumber = settings.supportWhatsApp.replace(/\D/g, '');

  const faqs = [
    {
      q: 'كيف يعمل الدفع في سوق دكانة؟',
      a: 'طريقة الدفع الرسمية والمعتمدة في دكانة هي الدفع عند الاستلام (COD) نقداً بالدينار العراقي للمندوب بعد معاينة طلبيتك والتحقق من سلامتها.',
    },
    {
      q: 'هل يشمل التوصيل جميع محافظات العراق؟',
      a: 'نعم، يدعم دكانة التوصيل إلى المحافظات العراقية الثماني عشرة (بغداد، البصرة، نينوى، أربيل، كركوك، النجف، كربلاء، بابل، واسط، الأنبار، صلاح الدين، ديالى، ذي قار، ميسان، المثنى، القادسية، دهوك، السليمانية).',
    },
    {
      q: 'لماذا قُسمت سلتي إلى طلبات منفصلة؟',
      a: 'إذا قمت بإضافة منتجات من تجار مختلفين، يقوم النظام بتقسيم الطلب تلقائياً لكل متجر، لأن كل تاجر يتولى تجهيز وتوصيل بضاعته بنفسه.',
    },
    {
      q: 'كيف أضمن أن تقييمات المنتجات حقيقية؟',
      a: 'يمنع دكانة التقييمات الوهمية تماماً. لا يُسمح بإضافة أي تقييم إلا للزبون الذي أتم عملية الشراء واستلم طلبه بنجاح، ويظهر بجانب تقييمه شارة "عملية شراء موثقة".',
    },
    {
      q: 'كيف يمكنني حذف حسابي نهائياً؟',
      a: 'يمكنك حذف حسابك في أي وقت من خلال نافذة "السياسات والتوافق" -> "حذف الحساب" وسيتم محو بياناتك الشخصية فورياً وفق سياسة الخصوصية.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden my-6 border border-zinc-200">
        {/* Header */}
        <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-purple-700 text-white flex items-center justify-center">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-zinc-900">
                الدعم والمساعدة
              </h2>
              <p className="text-xs text-zinc-500">
                فريق خدمة عملاء دكانة في خدمتك في جميع محافظات العراق
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 text-xs">
          {/* Direct WhatsApp Call to Action */}
          <div className="bg-emerald-500 text-white p-5 rounded-2xl shadow-md shadow-emerald-500/20 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-right">
              <span className="text-[11px] font-bold text-emerald-100 block mb-0.5">
                تواصل مباشر وسريع:
              </span>
              <h3 className="text-base font-black">واتساب خدمة عملاء دكانة</h3>
              <p className="text-xs text-emerald-100 mt-1" dir="ltr">
                {settings.supportWhatsApp}
              </p>
            </div>

            <a
              href={`https://wa.me/${cleanWhatsAppNumber}?text=${encodeURIComponent('مرحباً فريق دكانة، أحتاج مساعدة بخصوص طلبي في السوق.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 rounded-xl bg-white text-emerald-700 font-black text-xs hover:bg-emerald-50 transition shadow-sm flex items-center gap-2 cursor-pointer shrink-0"
            >
              <MessageCircle className="w-4 h-4" />
              <span>مراسلة عبر واتساب</span>
            </a>
          </div>

          {/* Quick FAQ Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-black text-zinc-900 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-purple-700" />
              <span>الأسئلة الشائعة (FAQ)</span>
            </h3>

            <div className="space-y-2">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="bg-zinc-50 p-3.5 rounded-2xl border border-zinc-200/80 space-y-1"
                >
                  <h4 className="font-bold text-zinc-900 text-xs flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-700"></span>
                    <span>{faq.q}</span>
                  </h4>
                  <p className="text-[11px] text-zinc-600 leading-relaxed pr-3">
                    {faq.a}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
