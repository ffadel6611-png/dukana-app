import React, { useState } from 'react';
import {
  ShieldCheck,
  Users,
  Store,
  Package,
  FolderTree,
  DollarSign,
  Star,
  Flag,
  Settings,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Plus,
  Trash2,
  Edit,
  Eye,
  Check,
  TrendingUp,
  ShieldAlert,
} from 'lucide-react';
import { useMarket } from '../context/MarketContext';
import { useAuth } from '../context/AuthContext';
import { ProductApprovalStatus, MerchantStatus, OrderStatus, ADMIN_PHONE_E164 } from '../types';
import { formatIQDTabular } from '../utils/currency';

export const AdminDashboard: React.FC = () => {
  const { currentUser, isAdmin } = useAuth();
  const [serverVerified, setServerVerified] = useState<boolean | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    products,
    merchants,
    orders,
    categories,
    reviews,
    reports,
    settings,
    setProductApproval,
    setMerchantStatus,
    addCategory,
    updateCategory,
    deleteCategory,
    setReviewStatus,
    resolveReport,
    updateSettings,
    updateOrderStatus,
  } = useMarket();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'merchants' | 'products' | 'categories' | 'orders' | 'reviews' | 'settings'
  >('overview');

  // Category addition state
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  // Settings update state
  const [supportWhatsApp, setSupportWhatsApp] = useState(settings?.supportWhatsApp || '');
  const [commissionRate, setCommissionRate] = useState(settings?.defaultCommissionRate?.toString() || '5');
  const [settingsSuccessMsg, setSettingsSuccessMsg] = useState('');

  // Server-Side Verification: Verify with backend API that caller is strictly the authorized master admin
  React.useEffect(() => {
    let isMounted = true;
    async function verifyWithBackend() {
      try {
        const token = localStorage.getItem('dukkana_session_token_v3') || '';
        const res = await fetch('/api/admin/verify-access', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone: currentUser?.phone,
            token,
          }),
        });
        const data = await res.json();
        if (isMounted) {
          if (res.ok && data.authorized === true) {
            setServerVerified(true);
          } else {
            setServerVerified(false);
            setServerError(data.error || 'رفض الوصول من جهة الخادم: غير مصرح بالدخول إلى لوحة المدير.');
          }
        }
      } catch {
        // Fallback: If network offline, verify against strict canonical phone rule
        if (isMounted) {
          if (currentUser?.phone === ADMIN_PHONE_E164 && isAdmin) {
            setServerVerified(true);
          } else {
            setServerVerified(false);
            setServerError('رفض أمني: رقم الهاتف غير مصرح له كمدير.');
          }
        }
      }
    }
    verifyWithBackend();
    return () => {
      isMounted = false;
    };
  }, [currentUser?.phone, isAdmin]);

  // Keep settings state in sync if settings update
  React.useEffect(() => {
    if (settings) {
      setSupportWhatsApp(settings.supportWhatsApp || '');
      setCommissionRate(settings.defaultCommissionRate?.toString() || '5');
    }
  }, [settings]);

  // Internal Security Guard: Only the canonical admin phone 07862214922 may view this dashboard
  if (!isAdmin || currentUser?.phone !== ADMIN_PHONE_E164 || serverVerified === false) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-200">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-black text-zinc-900">غير مصرح بالدخول إلى لوحة المدير</h2>
        <p className="text-xs text-zinc-600 leading-relaxed">
          {serverError ||
            'لوحة الإدارة محمية برمجياً ومن جهة الخادم ومخصصة حصرياً للمدير الرئيسي المعتمد لمنصة دكانة برقم 07862214922 بعد تسجيل الدخول والتحقق برمز OTP.'}
        </p>
      </div>
    );
  }

  // Loading state while verifying with backend
  if (serverVerified === null) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center space-y-3">
        <div className="w-10 h-10 mx-auto rounded-full border-3 border-purple-700 border-t-transparent animate-spin"></div>
        <p className="text-xs text-zinc-500 font-bold">جاري التحقق الأمني من صلاحيات الإدارة مع الخادم...</p>
      </div>
    );
  }

  // Stats calculation
  const totalDeliveredOrders = orders.filter(o => o.status === 'delivered');
  const totalPlatformCommissions = totalDeliveredOrders.reduce((sum, o) => sum + o.commissionAmount, 0);
  const totalGrossVolume = totalDeliveredOrders.reduce((sum, o) => sum + o.finalTotal, 0);
  const pendingProductsCount = products.filter(p => p.approvalStatus === 'pending').length;
  const pendingMerchantsCount = merchants.filter(m => m.status === 'pending').length;
  const pendingReportsCount = reports.filter(r => r.status === 'pending').length;

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      supportWhatsApp: supportWhatsApp.trim(),
      defaultCommissionRate: Number(commissionRate) || 5,
    });
    setSettingsSuccessMsg('تم حفظ وتحديث إعدادات المنصة ورقم واتساب الدعم بنجاح.');
    setTimeout(() => setSettingsSuccessMsg(''), 3000);
  };

  const handleAddCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    addCategory(newCatName.trim(), newCatDesc.trim() || undefined);
    setNewCatName('');
    setNewCatDesc('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Admin Header */}
      <div className="bg-purple-950 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xl shadow-purple-950/20">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs font-bold text-purple-300">لوحة الإدارة والرقابة الرسمية (Admin)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black">إدارة منصة وسوق دكانة</h1>
          <p className="text-xs text-purple-200 mt-1 max-w-xl">
            التحكم الشامل بالتجار، المنتجات، العمولات، الأقسام، مراجعة التقييمات والبلاغات، وإعدادات المتجر.
          </p>
        </div>

        {/* Pending Action Badges */}
        <div className="flex flex-wrap gap-2 text-xs">
          {pendingProductsCount > 0 && (
            <div className="bg-amber-500/20 text-amber-200 border border-amber-500/30 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>{pendingProductsCount} منتجات بانتظار الموافقة</span>
            </div>
          )}
          {pendingReportsCount > 0 && (
            <div className="bg-rose-500/20 text-rose-200 border border-rose-500/30 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5">
              <Flag className="w-4 h-4 text-rose-400" />
              <span>{pendingReportsCount} بلاغات تقييم قيد الفحص</span>
            </div>
          )}
        </div>
      </div>

      {/* Admin Tab Navigation */}
      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar p-1.5 bg-zinc-200/70 rounded-2xl text-xs font-bold">
        {[
          { id: 'overview', label: 'نظرة عامة وإحصائيات', icon: <TrendingUp className="w-4 h-4" /> },
          { id: 'merchants', label: `التجار والمتاجر (${merchants.length})`, icon: <Store className="w-4 h-4" /> },
          { id: 'products', label: `المنتجات والموافقات (${products.length})`, icon: <Package className="w-4 h-4" /> },
          { id: 'orders', label: `الطلبات والعمولات (${orders.length})`, icon: <DollarSign className="w-4 h-4" /> },
          { id: 'categories', label: `الأقسام (${categories.length})`, icon: <FolderTree className="w-4 h-4" /> },
          { id: 'reviews', label: `التقييمات والبلاغات (${reports.length})`, icon: <Star className="w-4 h-4" /> },
          { id: 'settings', label: 'إعدادات المنصة وواتساب', icon: <Settings className="w-4 h-4" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl whitespace-nowrap transition cursor-pointer ${
              activeTab === tab.id
                ? 'bg-white text-purple-950 shadow-sm font-black'
                : 'text-zinc-600 hover:text-zinc-950'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-3xl border border-zinc-200">
              <span className="text-xs text-zinc-500 font-bold block mb-1">إجمالي عمولات دكانة</span>
              <div className="text-2xl font-black text-purple-950 tabular-nums">
                {formatIQDTabular(totalPlatformCommissions)}
              </div>
              <span className="text-[11px] text-zinc-400 mt-1 block">
                محتسبة فقط على الطلبات المسلمة
              </span>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-zinc-200">
              <span className="text-xs text-zinc-500 font-bold block mb-1">حجم التداول المالي (GMV)</span>
              <div className="text-2xl font-black text-zinc-900 tabular-nums">
                {formatIQDTabular(totalGrossVolume)}
              </div>
              <span className="text-[11px] text-zinc-400 mt-1 block">
                مبيعات نقدية عند الاستلام
              </span>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-zinc-200">
              <span className="text-xs text-zinc-500 font-bold block mb-1">المتاجر المسجلة</span>
              <div className="text-2xl font-black text-zinc-900 tabular-nums">
                {merchants.length}
              </div>
              <span className="text-[11px] text-emerald-600 font-bold mt-1 block">
                {merchants.filter(m => m.status === 'approved').length} متاجر معتمدة
              </span>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-zinc-200">
              <span className="text-xs text-zinc-500 font-bold block mb-1">إجمالي المنتجات المعتمدة</span>
              <div className="text-2xl font-black text-zinc-900 tabular-nums">
                {products.filter(p => p.approvalStatus === 'approved').length}
              </div>
              <span className="text-[11px] text-zinc-400 mt-1 block">
                معروضة للزبائن في السوق
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Merchants Management */}
      {activeTab === 'merchants' && (
        <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden shadow-xs">
          <div className="p-5 border-b border-zinc-200 flex items-center justify-between">
            <h2 className="font-black text-base text-zinc-900">إدارة التجار والمتاجر العراقية</h2>
            <span className="text-xs text-zinc-500">موافقة المدير شرط أساسي لظهور متجر التاجر للعامة</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-zinc-50 text-zinc-600 font-bold border-b border-zinc-200">
                <tr>
                  <th className="p-3.5">اسم المتجر</th>
                  <th className="p-3.5">المحافظة</th>
                  <th className="p-3.5">رقم الهاتف</th>
                  <th className="p-3.5">نسبة العمولة</th>
                  <th className="p-3.5">الحالة</th>
                  <th className="p-3.5 text-center">إجراءات الموافقة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {merchants.map(m => (
                  <tr key={m.id} className="hover:bg-zinc-50">
                    <td className="p-3.5 font-bold text-zinc-900">{m.storeName}</td>
                    <td className="p-3.5 text-zinc-600">{m.governorate}</td>
                    <td className="p-3.5 text-zinc-600 font-mono" dir="ltr">{m.phone}</td>
                    <td className="p-3.5 font-bold text-purple-900">{m.commissionRate}%</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] border ${
                          m.status === 'approved'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : m.status === 'rejected'
                            ? 'bg-rose-50 text-rose-800 border-rose-200'
                            : m.status === 'suspended'
                            ? 'bg-zinc-100 text-zinc-700 border-zinc-300'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                      >
                        {m.status === 'approved'
                          ? 'مقبول'
                          : m.status === 'rejected'
                          ? 'مرفوض'
                          : m.status === 'suspended'
                          ? 'موقوف'
                          : 'قيد المراجعة'}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setMerchantStatus(m.id, 'approved')}
                          disabled={m.status === 'approved'}
                          className="px-2 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] disabled:opacity-40 hover:bg-emerald-700 cursor-pointer"
                        >
                          قبول
                        </button>
                        <button
                          onClick={() => setMerchantStatus(m.id, 'rejected')}
                          disabled={m.status === 'rejected'}
                          className="px-2 py-1 rounded-lg bg-rose-600 text-white font-bold text-[11px] disabled:opacity-40 hover:bg-rose-700 cursor-pointer"
                        >
                          رفض
                        </button>
                        <button
                          onClick={() => setMerchantStatus(m.id, 'suspended')}
                          disabled={m.status === 'suspended'}
                          className="px-2 py-1 rounded-lg bg-zinc-600 text-white font-bold text-[11px] disabled:opacity-40 hover:bg-zinc-700 cursor-pointer"
                        >
                          إيقاف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Products Management */}
      {activeTab === 'products' && (
        <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden shadow-xs">
          <div className="p-5 border-b border-zinc-200 flex items-center justify-between">
            <h2 className="font-black text-base text-zinc-900">مراجعة واعتماد المنتجات</h2>
            <span className="text-xs text-zinc-500">المنتج لا يظهر للزبائن إلا بعد اعتماده من قبل المدير</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-zinc-50 text-zinc-600 font-bold border-b border-zinc-200">
                <tr>
                  <th className="p-3.5">المنتج</th>
                  <th className="p-3.5">المتجر</th>
                  <th className="p-3.5">السعر</th>
                  <th className="p-3.5">حالة الاعتماد</th>
                  <th className="p-3.5 text-center">الإجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {products.map(p => (
                  <tr key={p.id} className="hover:bg-zinc-50">
                    <td className="p-3.5">
                      <div className="flex items-center gap-2.5">
                        <img src={p.imageUrl} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                        <div>
                          <span className="font-bold text-zinc-900 block">{p.name}</span>
                          <span className="text-[11px] text-zinc-400">{p.categoryName}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5 text-purple-900 font-semibold">{p.storeName}</td>
                    <td className="p-3.5 font-bold tabular-nums">{formatIQDTabular(p.finalPrice)}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] border ${
                          p.approvalStatus === 'approved'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : p.approvalStatus === 'rejected'
                            ? 'bg-rose-50 text-rose-800 border-rose-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                      >
                        {p.approvalStatus === 'approved'
                          ? 'مقبول (معروض للزبائن)'
                          : p.approvalStatus === 'rejected'
                          ? 'مرفوض'
                          : 'قيد المراجعة'}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setProductApproval(p.id, 'approved')}
                          disabled={p.approvalStatus === 'approved'}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] disabled:opacity-40 hover:bg-emerald-700 cursor-pointer"
                        >
                          موافقة ونشر
                        </button>
                        <button
                          onClick={() => setProductApproval(p.id, 'rejected')}
                          disabled={p.approvalStatus === 'rejected'}
                          className="px-2.5 py-1 rounded-lg bg-rose-600 text-white font-bold text-[11px] disabled:opacity-40 hover:bg-rose-700 cursor-pointer"
                        >
                          رفض
                        </button>
                        <button
                          onClick={() => setProductApproval(p.id, 'suspended')}
                          disabled={p.approvalStatus === 'suspended'}
                          className="px-2.5 py-1 rounded-lg bg-zinc-600 text-white font-bold text-[11px] disabled:opacity-40 hover:bg-zinc-700 cursor-pointer"
                        >
                          إيقاف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Orders & Commissions Ledger */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden shadow-xs">
          <div className="p-5 border-b border-zinc-200 flex items-center justify-between">
            <h2 className="font-black text-base text-zinc-900">سجل الطلبات والعمولات</h2>
            <span className="text-xs text-zinc-500">
              قاعدة النظام: العمولة تُحتسب فقط عند "تم التوصيل"، والطلب الملغي صفر عمولة.
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-zinc-50 text-zinc-600 font-bold border-b border-zinc-200">
                <tr>
                  <th className="p-3.5">رقم الطلب</th>
                  <th className="p-3.5">المتجر</th>
                  <th className="p-3.5">المستلم والمحافظة</th>
                  <th className="p-3.5">القيمة الإجمالية</th>
                  <th className="p-3.5">الحالة</th>
                  <th className="p-3.5">عمولة دكانة</th>
                  <th className="p-3.5 text-center">تحديث الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {orders.map(o => (
                  <tr key={o.id} className="hover:bg-zinc-50">
                    <td className="p-3.5 font-mono font-bold text-purple-950">{o.id}</td>
                    <td className="p-3.5 text-zinc-800 font-semibold">{o.storeName}</td>
                    <td className="p-3.5 text-zinc-600">
                      {o.recipientName} ({o.governorate})
                    </td>
                    <td className="p-3.5 font-bold tabular-nums">{formatIQDTabular(o.finalTotal)}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          o.status === 'delivered'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : o.status === 'cancelled'
                            ? 'bg-rose-50 text-rose-800 border border-rose-200'
                            : 'bg-blue-50 text-blue-800 border border-blue-200'
                        }`}
                      >
                        {o.status === 'delivered'
                          ? 'تم التوصيل'
                          : o.status === 'cancelled'
                          ? 'ملغي'
                          : o.status === 'out_for_delivery'
                          ? 'خرج للتوصيل'
                          : 'قيد المعالجة'}
                      </span>
                    </td>
                    <td className="p-3.5 font-black text-emerald-800 tabular-nums">
                      {o.status === 'delivered' ? formatIQDTabular(o.commissionAmount) : '0 د.ع (غير مسلم)'}
                    </td>
                    <td className="p-3.5 text-center">
                      <select
                        value={o.status}
                        onChange={e => updateOrderStatus(o.id, e.target.value as OrderStatus)}
                        className="px-2 py-1 rounded-lg border border-zinc-200 bg-white text-[11px] font-bold cursor-pointer"
                      >
                        <option value="new">طلب جديد</option>
                        <option value="confirmed">تم تأكيد الطلب</option>
                        <option value="preparing">قيد التجهيز</option>
                        <option value="out_for_delivery">خرج للتوصيل</option>
                        <option value="delivered">تم التوصيل (احتساب العمولة)</option>
                        <option value="cancelled">ملغي (بدون عمولة)</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 5: Categories Management */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-3xl border border-zinc-200">
            <h3 className="font-black text-sm text-zinc-900 mb-3 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-purple-700" />
              <span>إضافة قسم جديد للمتجر</span>
            </h3>
            <form onSubmit={handleAddCategorySubmit} className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                required
                value={newCatName}
                onChange={e => setNewCatName(e.target.value)}
                placeholder="اسم القسم (مثال: عطور وبخور عراقية)"
                className="flex-1 px-3 py-2 text-xs border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30"
              />
              <input
                type="text"
                value={newCatDesc}
                onChange={e => setNewCatDesc(e.target.value)}
                placeholder="وصف مختصر للقسم"
                className="flex-1 px-3 py-2 text-xs border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
              >
                إضافة القسم
              </button>
            </form>
          </div>

          <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden">
            <div className="p-4 bg-zinc-50 border-b border-zinc-200 font-bold text-xs text-zinc-700">
              الأقسام الحالية ({categories.length})
            </div>
            <div className="divide-y divide-zinc-200">
              {categories.map(c => (
                <div key={c.id} className="p-4 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-zinc-900 text-sm block">{c.name}</span>
                    <span className="text-zinc-500 text-[11px]">{c.description || 'بدون وصف'}</span>
                  </div>
                  {c.id !== 'cat_all' && (
                    <button
                      onClick={() => {
                        if (window.confirm(`هل أنت متأكد من حذف قسم "${c.name}"؟`)) {
                          deleteCategory(c.id);
                        }
                      }}
                      className="text-zinc-400 hover:text-rose-600 p-1 cursor-pointer"
                      title="حذف القسم"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: Reviews Moderation & Reports */}
      {activeTab === 'reviews' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-zinc-200 p-5">
            <h3 className="font-black text-sm text-zinc-900 mb-2 flex items-center gap-2">
              <Flag className="w-4 h-4 text-rose-600" />
              <span>بلاغات التقييمات والمحتوى المخالف ({reports.length})</span>
            </h3>
            <p className="text-xs text-zinc-500 mb-4">
              مراجعة البلاغات الواردة من المستخدمين حول التقييمات غير اللائقة أو المخالفة لسياسات Apple وGoogle.
            </p>

            {reports.length === 0 ? (
              <div className="text-center py-8 text-zinc-400 text-xs">
                لا توجد بلاغات معلقة حالياً. سجل التقييمات نظيف وملتزم.
              </div>
            ) : (
              <div className="space-y-3">
                {reports.map(rep => (
                  <div key={rep.id} className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-zinc-900">
                        سبب البلاغ: {rep.reason === 'inappropriate' ? 'محتوى غير لائق' : rep.reason}
                      </span>
                      <span className="text-zinc-400 text-[11px]">
                        {new Date(rep.createdAt).toLocaleDateString('ar-IQ')}
                      </span>
                    </div>
                    <p className="text-zinc-700 bg-white p-2.5 rounded-xl border border-zinc-200">
                      تفاصيل البلاغ: {rep.details}
                    </p>
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-200/60">
                      <button
                        onClick={() => {
                          setReviewStatus(rep.reviewId, 'hidden');
                          resolveReport(rep.id, 'action_taken');
                        }}
                        className="px-3 py-1 bg-rose-600 text-white rounded-lg font-bold text-[11px] cursor-pointer"
                      >
                        إخفاء التقييم واتخاذ إجراء
                      </button>
                      <button
                        onClick={() => resolveReport(rep.id, 'dismissed')}
                        className="px-3 py-1 bg-zinc-200 text-zinc-700 rounded-lg font-bold text-[11px] cursor-pointer"
                      >
                        تجاهل البلاغ (سليم)
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* All Reviews Management */}
          <div className="bg-white rounded-3xl border border-zinc-200 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-sm text-zinc-900 flex items-center gap-2">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>كافة تقييمات المنصة الموثقة ({reviews.length})</span>
              </h3>
              <span className="text-xs text-zinc-500">
                المدير يستطيع إخفاء أو حذف أي تقييم مخالف للآداب أو لسياسات Apple وGoogle
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-zinc-50 text-zinc-600 font-bold border-b border-zinc-200">
                  <tr>
                    <th className="p-3">المنتج والطلب</th>
                    <th className="p-3">صاحب التقييم</th>
                    <th className="p-3">النجوم</th>
                    <th className="p-3">التعليق</th>
                    <th className="p-3">الحالة</th>
                    <th className="p-3 text-center">إجراءات الرقابة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200">
                  {reviews.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-zinc-400">
                        لا توجد تقييمات منشورة حتى الآن.
                      </td>
                    </tr>
                  ) : (
                    reviews.map(rev => (
                      <tr key={rev.id} className="hover:bg-zinc-50">
                        <td className="p-3 font-bold text-zinc-900">
                          <div>{rev.productName}</div>
                          <span className="text-[10px] text-zinc-400 font-mono">طلب #{rev.orderId}</span>
                        </td>
                        <td className="p-3 text-zinc-700">
                          <div>{rev.userName}</div>
                          <span className="text-[10px] text-zinc-400 font-mono" dir="ltr">{rev.userPhone}</span>
                        </td>
                        <td className="p-3">
                          <span className="font-black text-amber-600">★ {rev.rating}</span>
                        </td>
                        <td className="p-3 text-zinc-600 max-w-xs truncate">
                          {rev.comment || 'بدون تعليق'}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              rev.status === 'published'
                                ? 'bg-emerald-50 text-emerald-800'
                                : 'bg-rose-50 text-rose-800'
                            }`}
                          >
                            {rev.status === 'published' ? 'منشور للعامة' : 'مخفي للمخالفة'}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {rev.status === 'published' ? (
                              <button
                                onClick={() => setReviewStatus(rev.id, 'hidden')}
                                className="px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-[10px] font-bold cursor-pointer"
                              >
                                إخفاء
                              </button>
                            ) : (
                              <button
                                onClick={() => setReviewStatus(rev.id, 'published')}
                                className="px-2 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-lg text-[10px] font-bold cursor-pointer"
                              >
                                إظهار
                              </button>
                            )}
                            <button
                              onClick={() => {
                                if (window.confirm('هل أنت متأكد من حذف هذا التقييم نهائياً؟')) {
                                  setReviewStatus(rev.id, 'deleted');
                                }
                              }}
                              className="px-2 py-1 bg-rose-100 hover:bg-rose-200 text-rose-900 rounded-lg text-[10px] font-bold cursor-pointer"
                            >
                              حذف
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 7: App Settings & WhatsApp */}
      {activeTab === 'settings' && (
        <div className="bg-white rounded-3xl border border-zinc-200 p-6 max-w-xl">
          <h2 className="font-black text-base text-zinc-900 mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-purple-700" />
            <span>إعدادات النظام والتواصل</span>
          </h2>

          {settingsSuccessMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl mb-4">
              {settingsSuccessMsg}
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                رقم واتساب الدعم الفني والمساعدة الرسمي *
              </label>
              <input
                type="text"
                required
                value={supportWhatsApp}
                onChange={e => setSupportWhatsApp(e.target.value)}
                placeholder="+9647701234567"
                dir="ltr"
                className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30 font-mono"
              />
              <span className="text-[11px] text-zinc-400 mt-1 block">
                هذا الرقم يظهر في شاشة "الدعم والمساعدة" لجميع زبائن وتجار دكانة.
              </span>
            </div>

            <div>
              <label className="block font-bold text-zinc-700 mb-1">
                نسبة عمولة منصة دكانة الافتراضية (%) *
              </label>
              <input
                type="number"
                required
                min="0"
                max="50"
                value={commissionRate}
                onChange={e => setCommissionRate(e.target.value)}
                placeholder="5"
                className="w-full px-3 py-2 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-purple-600/30"
              />
              <span className="text-[11px] text-zinc-400 mt-1 block">
                تُستقطع العمولة تلقائياً عند تحول حالة الطلب إلى "تم التوصيل" فقط.
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl cursor-pointer shadow-xs transition"
            >
              حفظ الإعدادات
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
