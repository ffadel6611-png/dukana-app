import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  FileText,
  Lock,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Store,
  HelpCircle,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface ComplianceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ComplianceModal: React.FC<ComplianceModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { currentUser, deleteAccount, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'privacy' | 'terms' | 'merchant_terms' | 'prohibited' | 'delete_account' | 'store_readiness'
  >('privacy');

  // Account deletion state
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deleteReason, setDeleteReason] = useState('لم أعد بحاجة لاستخدام التطبيق');
  const [deletionStatus, setDeletionStatus] = useState<{ success?: boolean; msg?: string }>({});

  if (!isOpen) return null;

  const handleDeleteAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (deleteConfirmText.trim() !== 'حذف حسابي') {
      setDeletionStatus({
        success: false,
        msg: 'يرجى كتابة جملة "حذف حسابي" للتأكيد النهائي.',
      });
      return;
    }

    const res = deleteAccount(deleteReason);
    setDeletionStatus({ success: res.success, msg: res.message });
    if (res.success) {
      setTimeout(() => {
        onClose();
      }, 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden my-6 border border-zinc-200 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-purple-700 text-white flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-zinc-900">
                السياسات والتوافق مع متطلبات المتاجر (Apple & Google)
              </h2>
              <p className="text-xs text-zinc-500">
                إفصاحات حماية البيانات، الشروط، المنتجات المحظورة، وحذف الحساب
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigator */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar p-2 bg-zinc-100 border-b border-zinc-200 text-xs font-bold shrink-0">
          {[
            { id: 'privacy', label: 'سياسة الخصوصية' },
            { id: 'terms', label: 'شروط الاستخدام' },
            { id: 'merchant_terms', label: 'شروط التجار' },
            { id: 'prohibited', label: 'المنتجات المحظورة' },
            { id: 'delete_account', label: 'حذف الحساب (App Store)' },
            { id: 'store_readiness', label: 'جاهزية Apple & Google' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-2 rounded-xl whitespace-nowrap cursor-pointer transition ${
                activeTab === tab.id
                  ? 'bg-white text-purple-900 shadow-xs font-black'
                  : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs leading-relaxed text-zinc-700 flex-1">
          {/* Note: Legal notice as required by user prompt */}
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-[11px] font-medium">
            تنويه نظامي: هذه النصوص القانونية والسياسات تم إعدادها وفق متطلبات ومعايير Apple App Store وGoogle Play الرسمية للسوق العراقي، وهي نصوص أولية قابلة للتعديل والتدقيق الإضافي قبل النشر النهائي للمتاجر، ولا يُدعى بأنها تمت مراجعتها من قِبل محامٍ.
          </div>

          {/* Tab 1: Privacy Policy */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-zinc-900">
                سياسة الخصوصية وحماية بيانات المستخدمين (تطبيق دكانة)
              </h3>
              <p>
                تلتزم منصة **دكانة** باحترام خصوصية المستخدمين وحماية بياناتهم الشخصية في العراق. توضح هذه السياسة ماهية البيانات التي نجمعها، وأسباب جمعها، وكيفية حمايتها.
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">1. البيانات التي يتم جمعها:</h4>
              <ul className="list-disc list-inside space-y-1 pr-2">
                <li>
                  <strong>رقم الهاتف العراقي:</strong> المعرّف الأساسي للحساب، يُستخدم للتحقق عبر رمز OTP، وتأكيد الطلبات والتواصل مع المندوب.
                </li>
                <li>
                  <strong>بيانات التوصيل:</strong> الاسم، المحافظة (إحدى المحافظات الـ 18)، والعنوان التفصيلي لتسليم المشتريات.
                </li>
                <li>
                  <strong>سجل الطلبات والمشتريات:</strong> لتتبع الطلبات، وتوثيق التقييمات الحقيقية ومنع التقييمات الوهمية.
                </li>
              </ul>

              <h4 className="font-bold text-zinc-900 text-sm">2. طريقة الدفع والأمان:</h4>
              <p>
                لا يقوم تطبيق دكانة بجمع أو حفظ أي بيانات بطاقات ائتمانية أو مصرفية. جميع المعاملات تتم حصرياً بنظام **الدفع نقداً عند الاستلام (COD)** بعد معاينة المشتري للمنتج.
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">3. مشاركة البيانات:</h4>
              <p>
                تتم مشاركة بيانات المستلم (الاسم، الهاتف، العنوان) فقط مع التاجر المسؤول عن تجهيز وتوصيل الطلب المحدد، ولا يتم بيع أو تأجير بيانات المستخدمين لأي أطراف ثالثة إطلاقاً.
              </p>
            </div>
          )}

          {/* Tab 2: Terms of Service */}
          {activeTab === 'terms' && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-zinc-900">شروط وأحكام استخدام سوق دكانة</h3>
              <p>
                باستخدامك لتطبيق دكانة، فإنك توافق على الالتزام بكافة الشروط المنصوص عليها أدناه:
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">1. أهلية الاستخدام والحسابات:</h4>
              <p>
                يُشترط استخدام رقم هاتف عراقي حقيقي صالح وقابل للتحقق عبر رمز التحقق OTP. يمنع إنشاء حسابات وهمية أو متعددة بقصد التلاعب بالأسعار أو التقييمات.
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">2. التزامات الشراء والدفع عند الاستلام:</h4>
              <p>
                الزبون مسؤول عن صحة رقم الهاتف والعنوان المدخلين. الطلب المؤكد يُلزم الزبون باستلام الطلب ودفع قيمته نقداً للمندوب، ما لم يتبين وجود عيب مصنعي أو مخالفة للمواصفات المعروضة.
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">3. قواعد التقييم والمحتوى:</h4>
              <p>
                يُسمح بتقييم المنتجات فقط بعد إتمام عملية الشراء وتوصيل الطلب فعلياً ("عملية شراء موثقة"). يُحظر كتابة تعليقات خادشة للحياء، أو كيدية، أو ترويجية.
              </p>
            </div>
          )}

          {/* Tab 3: Merchant Terms */}
          {activeTab === 'merchant_terms' && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-zinc-900">ميثاق وشروط التجار في دكانة</h3>
              <p>
                يخضع تسجيل أي تاجر لموافقة إدارة دكانة الصريحة بعد مراجعة بيانات المتجر وهويته التجارية.
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">1. مسؤولية التجهيز والتوصيل:</h4>
              <p>
                التاجر مسؤول مسؤولية كاملة عن جودة المنتجات، مطابقتها للأوصاف والصور المرفوعة، وتغليفها وتوصيلها للزبون في الوقت المحدد، وتحصيل مبالغ الدفع عند الاستلام.
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">2. عمولة المنصة:</h4>
              <p>
                تُحدد عمولة المنصة بنسبة مئوية (الافتراضي 5%). تُستقطع العمولة **فقط على الطلبات المكتملة المسلمة (تم التوصيل)**، بينما لا تُفرض أي عمولة على الطلبات الملغاة.
              </p>

              <h4 className="font-bold text-zinc-900 text-sm">3. حظر حذف التقييمات:</h4>
              <p>
                لا يملك التاجر أي صلاحية لحذف أو تعديل تقييمات الزبائن، لضمان أعلى معايير الشفافية والنزاهة للمتسوق العراقي.
              </p>
            </div>
          )}

          {/* Tab 4: Prohibited Products */}
          {activeTab === 'prohibited' && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-rose-900">
                سياسة المنتجات والمحتوى المحظور (Apple & Google Guidelines)
              </h3>
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 font-bold">
                يُحظر تماماً وبشكل قاطع عرض أو بيع أو ترويج أي من الأصناف التالية داخل سوق دكانة:
              </div>

              <ul className="space-y-2 pr-2">
                <li className="flex items-start gap-2">
                  <span className="text-rose-600 font-bold">✕</span>
                  <span><strong>المخدرات والمؤثرات العقلية:</strong> وكافة المستحضرات الصيدلانية المحظورة أو الموصوفة بدون تراخيص رسمية.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-600 font-bold">✕</span>
                  <span><strong>الأسلحة والذخائر والمتفجرات:</strong> ومستلزمات الصيد غير القانونية وأجهزة الصعق.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-600 font-bold">✕</span>
                  <span><strong>المحتوى الجنسي والإباحي:</strong> وأي منتجات تخدش الحياء العام أو الآداب الإسلامية والمجتمعية العراقية.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-600 font-bold">✕</span>
                  <span><strong>القمار واليانصيب:</strong> وأي أنشطة مراهنات أو ألعاب حظ.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-600 font-bold">✕</span>
                  <span><strong>التقييمات والمراجعات الوهمية أو المدفوعة:</strong> ويعتبر ذلك تزويراً يُعرّض المتجر للإيقاف الفوري.</span>
                </li>
              </ul>
            </div>
          )}

          {/* Tab 5: Account Deletion (Apple Guideline 5.1.1(v) & Google Play) */}
          {activeTab === 'delete_account' && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-rose-900 flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-rose-600" />
                <span>حذف الحساب ومحو البيانات الشخصية</span>
              </h3>

              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-rose-950 space-y-2">
                <div className="font-bold flex items-center gap-1.5 text-xs">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>متطلب إلزامي لمتجري Apple App Store وGoogle Play:</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  تمنحك دكانة الحق الكامل في حذف حسابك وبياناتك الشخصية من داخل التطبيق في أي وقت دون الحاجة لتقديم طلب عبر البريد أو الانتظار.
                  عند تأكيد الحذف، سيتم محو رقم هاتفك، اسمك، وعناوينك المسجلة نهائياً وفورياً من خوادمنا.
                </p>
              </div>

              {!isAuthenticated || !currentUser ? (
                <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 text-center text-zinc-500">
                  أنت لست مسجل الدخول حالياً بحساب زبون نشط.
                </div>
              ) : (
                <form onSubmit={handleDeleteAccountSubmit} className="space-y-4 pt-2">
                  {deletionStatus.msg && (
                    <div
                      className={`p-3 rounded-xl border text-xs font-bold ${
                        deletionStatus.success
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-rose-50 text-rose-800 border-rose-200'
                      }`}
                    >
                      {deletionStatus.msg}
                    </div>
                  )}

                  <div>
                    <label className="block font-bold text-zinc-700 mb-1">
                      الحساب الحالي المراد حذفه:
                    </label>
                    <div className="p-2.5 bg-zinc-50 rounded-xl border border-zinc-200 text-zinc-900 font-bold">
                      {currentUser.displayName} ({currentUser.phone})
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-zinc-700 mb-1">سبب طلب الحذف:</label>
                    <select
                      value={deleteReason}
                      onChange={e => setDeleteReason(e.target.value)}
                      className="w-full px-3 py-2 border border-zinc-200 rounded-xl bg-white"
                    >
                      <option value="لم أعد بحاجة لاستخدام التطبيق">لم أعد بحاجة لاستخدام التطبيق</option>
                      <option value="الرغبة في محو البيانات الشخصية">الرغبة في محو البيانات الشخصية</option>
                      <option value="تغيير رقم الهاتف العراقي">تغيير رقم الهاتف العراقي</option>
                      <option value="أسباب أخرى">أسباب أخرى</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-zinc-700 mb-1">
                      لتأكيد الحذف النهائي، اكتب العبارة: <span className="text-rose-600 font-black">حذف حسابي</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={deleteConfirmText}
                      onChange={e => setDeleteConfirmText(e.target.value)}
                      placeholder="حذف حسابي"
                      className="w-full px-3 py-2 border border-rose-300 rounded-xl focus:ring-2 focus:ring-rose-500/30"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl transition cursor-pointer shadow-md shadow-rose-600/20"
                  >
                    تأكيد حذف الحساب ومحو البيانات نهائياً
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Tab 6: Store Readiness Checklist */}
          {activeTab === 'store_readiness' && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-zinc-900">
                قائمة فحص الجاهزية والامتثال لمتطلبات Apple & Google
              </h3>
              <p>
                تم تصميم وبناء تطبيق دكانة ليتطابق مع القواعد الصارمة لمتجري التطبيقات:
              </p>

              <div className="space-y-2.5">
                {[
                  {
                    title: 'حذف الحساب داخل التطبيق (Apple 5.1.1(v) & Google Play)',
                    desc: 'زر واضح للحذف مع محو البيانات الشخصية الفوري وبدون تعقيد.',
                    status: 'مكتمل ومطبق بنجاح',
                  },
                  {
                    title: 'نظام إدارة المحتوى الذي ينشئه المستخدمون (UGC Compliance)',
                    desc: 'إمكانية الإبلاغ عن التقييمات، فلترة المخالفات، ولوحة رقابة للمدير لحجب المحتوى المسيء.',
                    status: 'مكتمل ومطبق بنجاح',
                  },
                  {
                    title: 'مصادقة هاتفية حقيقية ورمز OTP مؤقت',
                    desc: 'دعم الأرقام العراقية الـ 11 رقماً، حدود المحاولات، حماية ضد الإساءة، وجاهزية ربط بوابات SMS.',
                    status: 'مكتمل ومطبق بنجاح',
                  },
                  {
                    title: 'منع التقييمات الوهمية (Anti-Fraud Review Policy)',
                    desc: 'ربط التقييم حصرياً بعمليات شراء حقيقية مسلمة بنجاح مع شارة "عملية شراء موثقة".',
                    status: 'مكتمل ومطبق بنجاح',
                  },
                  {
                    title: 'الدفع عند الاستلام فقط (COD) بدون معاملات وهمية',
                    desc: 'عدم وجود بوابات دفع بنكية وهمية أو غير مرخصة، والاعتماد على التسليم اليدوي العراقي.',
                    status: 'مكتمل ومطبق بنجاح',
                  },
                  {
                    title: 'سياسة حظر المنتجات غير القانونية',
                    desc: 'منع الأسلحة والمخدرات والمحتوى غير اللائق والمقامرة بشكل صريح.',
                    status: 'مكتمل ومطبق بنجاح',
                  },
                ].map((item, i) => (
                  <div key={i} className="p-3 bg-zinc-50 rounded-2xl border border-zinc-200 flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold text-zinc-900">{item.title}</div>
                      <div className="text-[11px] text-zinc-500 mt-0.5">{item.desc}</div>
                      <span className="inline-block mt-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        {item.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
