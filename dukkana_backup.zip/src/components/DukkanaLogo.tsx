import React from 'react';

export interface DukkanaLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'compact' | 'icon' | 'badge';
  theme?: 'dark' | 'light' | 'white';
  showSubline?: boolean;
  className?: string;
  sublineText?: string;
}

export const DukkanaLogo: React.FC<DukkanaLogoProps> = ({
  size = 'md',
  variant = 'full',
  theme = 'dark',
  showSubline = true,
  className = '',
  sublineText = 'سوقك العراقي الموثوق',
}) => {
  // Sizing matrix
  const dimensions = {
    xs: { icon: 'w-7 h-7', text: 'text-lg', subtext: 'text-[9px]', gap: 'gap-2' },
    sm: { icon: 'w-8 h-8', text: 'text-xl', subtext: 'text-[10px]', gap: 'gap-2.5' },
    md: { icon: 'w-10 h-10', text: 'text-2xl', subtext: 'text-[11px]', gap: 'gap-2.5' },
    lg: { icon: 'w-13 h-13', text: 'text-3xl', subtext: 'text-xs', gap: 'gap-3' },
    xl: { icon: 'w-16 h-16', text: 'text-4xl', subtext: 'text-sm', gap: 'gap-3.5' },
  }[size];

  // Theme text colors
  const titleColor =
    theme === 'white'
      ? 'text-white'
      : theme === 'light'
      ? 'text-purple-100'
      : 'text-purple-950';

  const sublineColor =
    theme === 'white'
      ? 'text-purple-200'
      : theme === 'light'
      ? 'text-purple-200/90'
      : 'text-zinc-500';

  // SVG Icon Symbol (Shopping Bag merged with Arabic "د" Dal & Gold Sparkle)
  const IconSymbol = (
    <div
      className={`relative ${dimensions.icon} rounded-2xl bg-gradient-to-br from-purple-800 via-purple-700 to-indigo-900 p-0.5 shadow-md shadow-purple-900/20 shrink-0 select-none overflow-hidden group-hover:scale-105 transition-transform duration-300`}
    >
      {/* Subtle Ambient Glow */}
      <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-amber-300/20 pointer-events-none" />

      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="bagWhiteGrad" x1="0" y1="0" x2="0" y2="100">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#F3E8FF" />
          </linearGradient>
          <linearGradient id="goldSpark" x1="0" y1="0" x2="100" y2="100">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="50%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
        </defs>

        {/* Bag Handle */}
        <path
          d="M38 34 C38 23 62 23 62 34"
          stroke="url(#bagWhiteGrad)"
          strokeWidth="5.5"
          strokeLinecap="round"
        />

        {/* Modern Bag Body */}
        <path
          d="M29 37 L71 37 C73.8 37 76 39.4 75.5 42.2 L70.5 76 C70 80 66.5 83 62.5 83 L37.5 83 C33.5 83 30 80 29.5 76 L24.5 42.2 C24 39.4 26.2 37 29 37 Z"
          fill="url(#bagWhiteGrad)"
        />

        {/* Elegant Arabic "د" Letter Embodied inside Bag */}
        <path
          d="M62 48 C62 48 57 47 52 48 C44 50 39 56 39 63 C39 70 44 73 51 73 C58 73 63 71 65 70"
          stroke="#6D28D9"
          strokeWidth="6.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Golden Diamond Commerce Sparkle */}
        <path
          d="M61 43 C61 43 62 39 65 38 C62 37 61 33 61 33 C61 33 60 37 57 38 C60 39 61 43 61 43 Z"
          fill="url(#goldSpark)"
        />
        <circle cx="63" cy="59" r="2.2" fill="url(#goldSpark)" />
      </svg>
    </div>
  );

  if (variant === 'icon') {
    return (
      <div className={`inline-flex items-center justify-center ${className}`}>
        {IconSymbol}
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center ${dimensions.gap} text-right select-none ${className}`}>
      {IconSymbol}

      <div className="flex flex-col justify-center leading-none">
        <div className="flex items-center gap-1.5">
          <span
            className={`font-black font-sans tracking-tight ${dimensions.text} ${titleColor} transition-colors`}
          >
            دكانة
          </span>
          {variant === 'badge' && (
            <span className="text-[10px] bg-emerald-500/15 text-emerald-600 border border-emerald-500/20 font-bold px-1.5 py-0.5 rounded-md">
              العراق
            </span>
          )}
        </div>

        {(variant === 'full' || showSubline) && (
          <span
            className={`font-medium tracking-normal mt-0.5 block ${dimensions.subtext} ${sublineColor} transition-colors`}
          >
            {sublineText}
          </span>
        )}
      </div>
    </div>
  );
};
