import React from 'react';
import {
  Sparkles,
  Percent,
  Clock,
  ShieldCheck,
  Truck,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Flame,
  BadgeCheck,
} from 'lucide-react';
import { useMarket } from '../context/MarketContext';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface HomeViewProps {
  onSelectProduct: (product: Product) => void;
  onNavigateCategories: (slug?: string, discount?: number) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectProduct,
  onNavigateCategories,
}) => {
  const {
    products,
    categories,
    selectedCategorySlug,
    setSelectedCategorySlug,
    searchQuery,
    getFilteredProductsForCustomer,
  } = useMarket();

  const customerProducts = getFilteredProductsForCustomer();

  // Highlight Collections:
  const featuredProducts = customerProducts.slice(0, 4);
  const discountedProducts = customerProducts.filter(p => (p.discountPercent || 0) > 0);
  const discount50 = customerProducts.filter(p => (p.discountPercent || 0) >= 50);
  const discount30 = customerProducts.filter(p => (p.discountPercent || 0) >= 30);
  const discount10 = customerProducts.filter(p => (p.discountPercent || 0) >= 10);

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Showcase Banner */}
      {!searchQuery && (
        <section className="relative overflow-hidden bg-gradient-to-br from-purple-950 via-purple-900 to-purple-800 text-white rounded-3xl mx-4 sm:mx-6 lg:mx-auto max-w-7xl shadow-xl shadow-purple-950/15">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
            {/* Text & CTAs */}
            <div className="p-6 sm:p-10 lg:p-12 lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold text-purple-200">
                <Sparkles className="w-3.5 h-3.5 text-purple-300" />
                <span>السوق العراقي الأصيل · موثوق ومضمون</span>
              </div>

              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight text-white">
                تسوق كل ما تحتاجه في العراق، والدفع <span className="text-amber-400">نقداً عند الاستلام</span>
              </h1>

              <p className="text-xs sm:text-sm text-purple-100 max-w-xl leading-relaxed">
                منصة دكانة تجمع نخبة التجار العراقيين في بغداد، البصرة، أربيل، وعموم المحافظات. منتجات منزلية، تمور فاخرة، عسل طبيعي، وأكلات أصيلة مع شحن مباشر إلى باب منزلك.
              </p>

              {/* Fast Features */}
              <div className="pt-2 flex flex-wrap gap-4 text-xs font-semibold text-purple-200">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>تقييمات موثقة بمشتريات حقيقية</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-purple-300" />
                  <span>توصيل لكافة المحافظات الـ 18</span>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="pt-3 flex items-center gap-3">
                <button
                  onClick={() => onNavigateCategories('all')}
                  className="px-6 py-3 rounded-xl bg-white text-purple-950 font-black text-xs hover:bg-purple-50 transition shadow-md cursor-pointer flex items-center gap-2"
                >
                  <span>تصفح جميع المنتجات</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onNavigateCategories('all', 30)}
                  className="px-5 py-3 rounded-xl bg-purple-800/80 hover:bg-purple-800 text-white border border-purple-600 font-bold text-xs transition cursor-pointer"
                >
                  العروض والخصومات
                </button>
              </div>
            </div>

            {/* Hero Image */}
            <div className="lg:col-span-5 h-64 sm:h-80 lg:h-full relative overflow-hidden bg-purple-900/50">
              <img
                src="/src/assets/images/hero_dukkana_market_1791352449347.jpg"
                alt="سوق دكانة"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-purple-950/80 via-transparent to-transparent pointer-events-none"></div>
            </div>
          </div>
        </section>
      )}

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12">
        {/* Categories Bar */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-black text-zinc-900">الأقسام الرئيسية</h2>
            <button
              onClick={() => onNavigateCategories()}
              className="text-xs text-purple-700 font-bold hover:underline cursor-pointer"
            >
              عرض الكل
            </button>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto no-scrollbar pb-2">
            {categories.map(cat => {
              const isSelected = selectedCategorySlug === cat.slug;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategorySlug(cat.slug)}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition cursor-pointer shrink-0 border ${
                    isSelected
                      ? 'bg-purple-700 text-white border-purple-700 shadow-sm'
                      : 'bg-white text-zinc-700 border-zinc-200 hover:border-purple-300 hover:bg-purple-50/50'
                  }`}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>
        </section>

        {/* Section 1: Featured Products (المنتجات المميزة) */}
        {featuredProducts.length > 0 && (
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-500" />
                <h2 className="text-lg font-black text-zinc-900">المنتجات المميزة في دكانة</h2>
              </div>
              <button
                onClick={() => onNavigateCategories('all')}
                className="text-xs text-purple-700 font-bold hover:underline cursor-pointer"
              >
                المزيد
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {featuredProducts.map(p => (
                <ProductCard key={p.id} product={p} onSelect={onSelectProduct} />
              ))}
            </div>
          </section>
        )}

        {/* Quick Discount Tiers Showcase (خصومات 50%, 30%, 10%) */}
        {!searchQuery && (
          <section className="bg-gradient-to-r from-purple-50 via-white to-purple-50/60 rounded-3xl border border-purple-100 p-5 sm:p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-rose-600" />
                <h2 className="text-base sm:text-lg font-black text-zinc-900">
                  تخفيضات السوق العراقي الكبرى
                </h2>
              </div>
              <span className="text-xs text-zinc-500">
                منتجات أصلية بأسعار مخفضة لفترة محدودة
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* 50% Discounts */}
              <div
                onClick={() => onNavigateCategories('all', 50)}
                className="bg-white p-4 rounded-2xl border border-rose-200 hover:border-rose-400 hover:shadow-sm transition cursor-pointer text-right space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                    خصم 50%
                  </span>
                  <Percent className="w-4 h-4 text-rose-500" />
                </div>
                <h3 className="font-bold text-sm text-zinc-900">تخفيضات نصف السعر</h3>
                <p className="text-[11px] text-zinc-500">
                  عسل طبيعي ومواد مختارة بنصف القيمة ({discount50.length} منتجات)
                </p>
              </div>

              {/* 30% Discounts */}
              <div
                onClick={() => onNavigateCategories('all', 30)}
                className="bg-white p-4 rounded-2xl border border-purple-200 hover:border-purple-400 hover:shadow-sm transition cursor-pointer text-right space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                    خصم 30%
                  </span>
                  <Percent className="w-4 h-4 text-purple-600" />
                </div>
                <h3 className="font-bold text-sm text-zinc-900">عروض التمور والمناسبات</h3>
                <p className="text-[11px] text-zinc-500">
                  تمور فاخرة وهدايا عراقية مميزة ({discount30.length} منتجات)
                </p>
              </div>

              {/* 10% Discounts */}
              <div
                onClick={() => onNavigateCategories('all', 10)}
                className="bg-white p-4 rounded-2xl border border-zinc-200 hover:border-zinc-400 hover:shadow-sm transition cursor-pointer text-right space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-zinc-800 bg-zinc-100 px-2 py-0.5 rounded-md border border-zinc-200">
                    خصم 10%
                  </span>
                  <Percent className="w-4 h-4 text-zinc-500" />
                </div>
                <h3 className="font-bold text-sm text-zinc-900">تخفيضات أطقم الضيافة والمطاعم</h3>
                <p className="text-[11px] text-zinc-500">
                  استكانات شاي ومشاوي طازجة ({discount10.length} منتجات)
                </p>
              </div>
            </div>
          </section>
        )}

        {/* Section 2: All Products (جميع المنتجات المعتمدة) */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-zinc-900">
              {searchQuery ? `نتائج البحث عن "${searchQuery}"` : 'جميع المنتجات في دكانة'}
            </h2>
            <span className="text-xs text-zinc-400">
              {customerProducts.length} منتج متاح
            </span>
          </div>

          {customerProducts.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-zinc-200 p-8 space-y-2">
              <h3 className="text-sm font-bold text-zinc-800">لا توجد منتجات مطابقة للبحث</h3>
              <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                تحقق من الكلمات أو ابحث باسم عام مثل "تمور"، "شاي"، "عسل"، أو "مشاوي".
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {customerProducts.map(p => (
                <ProductCard key={p.id} product={p} onSelect={onSelectProduct} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
