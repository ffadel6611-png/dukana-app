import React, { useState } from 'react';
import {
  ShoppingBag,
  User as UserIcon,
  HelpCircle,
  ShieldCheck,
  Store,
  SlidersHorizontal,
  Search,
  X,
  PhoneCall,
  MapPin,
  Menu,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMarket } from '../context/MarketContext';
import { DukkanaLogo } from './DukkanaLogo';
import { IRAQI_GOVERNORATES } from '../data/governorates';
import { IraqiGovernorate, UserRole } from '../types';

interface HeaderProps {
  onOpenCart: () => void;
  onOpenAuth: () => void;
  onOpenSupport: () => void;
  onOpenCompliance: () => void;
  onOpenMerchantDashboard?: () => void;
  onOpenAdminDashboard?: () => void;
  activeView: 'home' | 'categories' | 'orders' | 'profile' | 'merchant' | 'admin' | 'support';
  setActiveView: (view: 'home' | 'categories' | 'orders' | 'profile' | 'merchant' | 'admin' | 'support') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCart,
  onOpenAuth,
  onOpenSupport,
  onOpenCompliance,
  activeView,
  setActiveView,
}) => {
  const { currentUser, role, isAuthenticated, isAdmin, isMerchant, isSupport } = useAuth();
  const {
    getCartTotalCount,
    searchQuery,
    setSearchQuery,
    selectedGovernorate,
    setSelectedGovernorate,
  } = useMarket();

  const cartCount = getCartTotalCount();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-zinc-200">
      {/* Top Notification / Trust Bar */}
      <div className="bg-purple-900 text-white text-xs py-1 px-4 text-center font-medium flex items-center justify-between">
        <div className="flex items-center gap-2 mx-auto">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>سوق دكانة العراقي الرسمي · التوصيل لكافة المحافظات الـ 18 · الدفع نقداً عند الاستلام</span>
        </div>
        <button
          onClick={onOpenCompliance}
          className="text-purple-200 hover:text-white underline text-[11px] hidden md:inline-flex items-center gap-1 cursor-pointer"
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          سياسات وتوافق Apple & Google
        </button>
      </div>

      {/* Main Top Bar Contract: Brand | Navigation / Fast links | Actions */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark (Only "دكانة") */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveView('home')}
            className="flex items-center group text-right cursor-pointer focus:outline-none"
            aria-label="دكانة - الصفحة الرئيسية"
          >
            <DukkanaLogo size="md" variant="full" />
          </button>
        </div>

        {/* Zone 2: Navigation Links (Secured per Role) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-zinc-600">
          <button
            onClick={() => setActiveView('home')}
            className={`cursor-pointer transition-colors ${
              activeView === 'home' ? 'text-purple-700 font-bold border-b-2 border-purple-700 pb-0.5' : 'hover:text-zinc-950'
            }`}
          >
            الرئيسية
          </button>
          <button
            onClick={() => setActiveView('categories')}
            className={`cursor-pointer transition-colors ${
              activeView === 'categories' ? 'text-purple-700 font-bold border-b-2 border-purple-700 pb-0.5' : 'hover:text-zinc-950'
            }`}
          >
            الأقسام والخصومات
          </button>
          <button
            onClick={() => setActiveView('orders')}
            className={`cursor-pointer transition-colors ${
              activeView === 'orders' ? 'text-purple-700 font-bold border-b-2 border-purple-700 pb-0.5' : 'hover:text-zinc-950'
            }`}
          >
            {role === 'merchant' ? 'طلبات المتجر' : 'متابعة الطلبات'}
          </button>

          {/* Merchant Exclusive Portal Tab */}
          {role === 'merchant' && (
            <button
              onClick={() => setActiveView('merchant')}
              className={`cursor-pointer text-purple-700 font-bold flex items-center gap-1.5 ${
                activeView === 'merchant' ? 'border-b-2 border-purple-700 pb-0.5' : ''
              }`}
            >
              <Store className="w-4 h-4" />
              <span>لوحة المتجر</span>
            </button>
          )}

          {/* Admin Exclusive Portal Tab */}
          {isAdmin && (
            <>
              <button
                onClick={() => setActiveView('admin')}
                className={`cursor-pointer text-purple-950 font-black flex items-center gap-1.5 ${
                  activeView === 'admin' ? 'border-b-2 border-purple-900 pb-0.5' : ''
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-purple-700" />
                <span>لوحة المدير</span>
              </button>
              <button
                onClick={() => setActiveView('support')}
                className={`cursor-pointer text-indigo-900 font-bold flex items-center gap-1.5 ${
                  activeView === 'support' ? 'border-b-2 border-indigo-700 pb-0.5' : ''
                }`}
              >
                <HelpCircle className="w-4 h-4 text-indigo-700" />
                <span>فريق الدعم</span>
              </button>
            </>
          )}
        </nav>

        {/* Zone 3: Actions (Verified Role Badge, Support, Cart, User) */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Verified Role Badge (Informational only - No unauthorized role switching) */}
          {isAuthenticated && currentUser && (
            <div
              className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border ${
                isAdmin
                  ? 'bg-purple-950 text-purple-100 border-purple-800'
                  : role === 'merchant'
                  ? 'bg-purple-50 text-purple-900 border-purple-200'
                  : 'bg-zinc-100 text-zinc-700 border-zinc-200'
              }`}
            >
              {isAdmin ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>المدير الرئيسي</span>
                </>
              ) : role === 'merchant' ? (
                <>
                  <Store className="w-3.5 h-3.5 text-purple-700" />
                  <span>تاجر دكانة</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>زبون</span>
                </>
              )}
            </div>
          )}

          {/* Support Modal Button */}
          <button
            onClick={onOpenSupport}
            className="p-2 rounded-lg text-zinc-600 hover:text-purple-700 hover:bg-zinc-100 transition cursor-pointer"
            title="الدعم والمساعدة"
          >
            <HelpCircle className="w-5 h-5" />
          </button>

          {/* Shopping Bag Button with count badge */}
          <button
            onClick={onOpenCart}
            className="relative p-2.5 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 transition cursor-pointer"
            title="سلة المشتريات"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[20px] h-5 rounded-full bg-purple-600 text-white text-[11px] font-bold flex items-center justify-center px-1 shadow-sm">
                {cartCount}
              </span>
            )}
          </button>

          {/* User Auth Button */}
          {isAuthenticated && currentUser ? (
            <button
              onClick={() => setActiveView('profile')}
              className="flex items-center gap-1.5 p-1.5 pr-2.5 rounded-xl border border-zinc-200 hover:border-purple-300 text-xs font-bold text-zinc-800 transition cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-purple-700 text-white flex items-center justify-center text-xs font-bold">
                {currentUser.displayName.charAt(0) || 'م'}
              </div>
              <span className="hidden sm:inline max-w-[90px] truncate">{currentUser.displayName}</span>
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3 py-1.5 rounded-xl bg-purple-700 text-white text-xs font-bold hover:bg-purple-800 transition cursor-pointer flex items-center gap-1 shadow-sm"
            >
              <UserIcon className="w-4 h-4" />
              <span>تسجيل الدخول / إنشاء حساب</span>
            </button>
          )}
        </div>
      </div>

      {/* Sub-bar: Smart Search & Governorate Selection */}
      <div className="bg-zinc-50 border-t border-zinc-200/80 px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center gap-2">
          {/* Smart Search Input */}
          <div className="relative flex-1 w-full">
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-zinc-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="ابحث عن منتج، تمور، استكان شاي، عسل، مشاوي، أو اسم المتجر..."
              className="w-full pr-9 pl-8 py-2 bg-white rounded-xl border border-zinc-200 text-sm text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-zinc-400 hover:text-zinc-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Iraqi Governorate Fast Selector */}
          <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
            <div className="relative flex-1 sm:w-52">
              <div className="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none text-purple-700">
                <MapPin className="w-3.5 h-3.5" />
              </div>
              <select
                value={selectedGovernorate}
                onChange={e => setSelectedGovernorate(e.target.value as IraqiGovernorate | 'all')}
                className="w-full pr-8 pl-3 py-2 bg-white rounded-xl border border-zinc-200 text-xs font-semibold text-zinc-800 focus:outline-none focus:ring-2 focus:ring-purple-600/30 focus:border-purple-600 transition cursor-pointer appearance-none"
              >
                <option value="all">كافة المحافظات العراقية (18)</option>
                {IRAQI_GOVERNORATES.map(gov => (
                  <option key={gov.id} value={gov.id}>
                    {gov.nameAr}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
