import React, { useState } from 'react';
import {
  User as UserIcon,
  Phone,
  MapPin,
  Plus,
  Trash2,
  LogOut,
  ShieldCheck,
  AlertTriangle,
  FileText,
  HelpCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { IRAQI_GOVERNORATES } from '../data/governorates';
import { IraqiGovernorate } from '../types';

interface UserProfileViewProps {
  onOpenCompliance: () => void;
  onOpenSupport: () => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  onOpenCompliance,
  onOpenSupport,
}) => {
  const {
    currentUser,
    logout,
    addAddress,
    removeAddress,
    updateDisplayName,
  } = useAuth();

  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [newGov, setNewGov] = useState<IraqiGovernorate>('بغداد');
  const [newCity, setNewCity] = useState('');
  const [newLandmark, setNewLandmark] = useState('');
  const [newFullAddress, setNewFullAddress] = useState('');

  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(currentUser?.displayName || '');

  if (!currentUser) return null;

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFullAddress.trim()) return;

    addAddress({
      governorate: newGov,
      cityOrDistrict: newCity.trim() || newGov,
      nearestLandmark: newLandmark.trim(),
      fullAddress: newFullAddress.trim(),
    });

    setIsAddingAddress(false);
    setNewCity('');
    setNewLandmark('');
    setNewFullAddress('');
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    updateDisplayName(nameInput);
    setIsEditingName(false);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
      {/* Profile Card */}
      <div className="bg-white rounded-3xl border border-zinc-200 p-6 sm:p-7 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-100 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-purple-700 text-white flex items-center justify-center font-black text-2xl shadow-md shadow-purple-700/20">
              {currentUser.displayName.charAt(0) || 'م'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black text-zinc-900">
                  {currentUser.displayName}
                </h1>
                <span className="text-[11px] font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
                  {currentUser.role === 'admin'
                    ? 'المدير'
                    : currentUser.role === 'merchant'
                    ? 'التاجر'
                    : 'زبون دكانة'}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-mono mt-1" dir="ltr">
                <Phone className="w-3.5 h-3.5 text-purple-700" />
                <span>{currentUser.phone}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsEditingName(!isEditingName)}
              className="px-3.5 py-2 rounded-xl border border-zinc-200 text-zinc-700 hover:bg-zinc-50 font-bold text-xs cursor-pointer transition"
            >
              تعديل الاسم
            </button>
            <button
              onClick={logout}
              className="px-3.5 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition"
            >
              <LogOut className="w-4 h-4" />
              <span>خروج</span>
            </button>
          </div>
        </div>

        {/* Edit Name Inline Form */}
        {isEditingName && (
          <form onSubmit={handleSaveName} className="mt-4 p-4 bg-zinc-50 rounded-2xl border border-zinc-200 flex items-center gap-2">
            <input
              type="text"
              required
              value={nameInput}
              onChange={e => setNameInput(e.target.value)}
              className="flex-1 px-3 py-2 text-xs border border-zinc-200 rounded-xl bg-white"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-purple-700 text-white rounded-xl text-xs font-bold cursor-pointer"
            >
              حفظ
            </button>
          </form>
        )}

        {/* Saved Addresses Section */}
        <div className="mt-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-zinc-900 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-purple-700" />
              <span>عناوين التوصيل المسجلة ({currentUser.addresses.length})</span>
            </h2>
            <button
              onClick={() => setIsAddingAddress(!isAddingAddress)}
              className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة عنوان جديد</span>
            </button>
          </div>

          {/* Add Address Form */}
          {isAddingAddress && (
            <form onSubmit={handleSaveAddress} className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-zinc-700 mb-1">المحافظة *</label>
                  <select
                    value={newGov}
                    onChange={e => setNewGov(e.target.value as IraqiGovernorate)}
                    className="w-full px-3 py-2 border border-zinc-200 rounded-xl bg-white"
                  >
                    {IRAQI_GOVERNORATES.map(g => (
                      <option key={g.id} value={g.id}>
                        {g.nameAr}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-zinc-700 mb-1">الحي أو القضاء</label>
                  <input
                    type="text"
                    value={newCity}
                    onChange={e => setNewCity(e.target.value)}
                    placeholder="مثال: الكرادة / المنصور / المعقل"
                    className="w-full px-3 py-2 border border-zinc-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">أقرب نقطة دالة</label>
                <input
                  type="text"
                  value={newLandmark}
                  onChange={e => setNewLandmark(e.target.value)}
                  placeholder="مثال: قرب ساحة كهرمانة أو جامع النور"
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-700 mb-1">العنوان بالتفصيل *</label>
                <textarea
                  required
                  rows={2}
                  value={newFullAddress}
                  onChange={e => setNewFullAddress(e.target.value)}
                  placeholder="المحلة، الزقاق، الدار..."
                  className="w-full px-3 py-2 border border-zinc-200 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingAddress(false)}
                  className="px-3 py-1.5 text-zinc-500 font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl cursor-pointer"
                >
                  حفظ العنوان
                </button>
              </div>
            </form>
          )}

          {/* Addresses list */}
          <div className="space-y-2">
            {currentUser.addresses.length === 0 ? (
              <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 text-center text-xs text-zinc-400">
                لم تقم بحفظ أي عناوين توصيل مسبقة.
              </div>
            ) : (
              currentUser.addresses.map(addr => (
                <div
                  key={addr.id}
                  className="p-3.5 bg-zinc-50 rounded-2xl border border-zinc-200 flex items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <span className="font-bold text-zinc-900 block">
                      {addr.governorate} - {addr.cityOrDistrict}
                    </span>
                    <span className="text-zinc-600 text-[11px] block mt-0.5">
                      {addr.fullAddress}
                    </span>
                    {addr.nearestLandmark && (
                      <span className="text-zinc-400 text-[10px] block">
                        نقطة دالة: {addr.nearestLandmark}
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => removeAddress(addr.id)}
                    className="p-1.5 text-zinc-400 hover:text-rose-600 transition cursor-pointer"
                    title="حذف العنوان"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Links & Legal Compliance Section */}
        <div className="mt-8 pt-6 border-t border-zinc-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenCompliance}
              className="text-purple-700 hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>الخصوصية وسياسات Apple & Google</span>
            </button>
            <span className="text-zinc-300">·</span>
            <button
              onClick={onOpenSupport}
              className="text-zinc-600 hover:text-purple-700 font-bold flex items-center gap-1 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4" />
              <span>الدعم والمساعدة</span>
            </button>
          </div>

          <button
            onClick={onOpenCompliance}
            className="text-rose-600 hover:text-rose-700 text-xs font-bold cursor-pointer"
          >
            طلب حذف الحساب نهائياً
          </button>
        </div>
      </div>
    </div>
  );
};
