import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MarketProvider, useMarket } from './context/MarketContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { CategoriesView } from './components/CategoriesView';
import { OrdersView } from './components/OrdersView';
import { MerchantDashboard } from './components/MerchantDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { UserProfileView } from './components/UserProfileView';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { AuthModal } from './components/AuthModal';
import { SupportModal } from './components/SupportModal';
import { ComplianceModal } from './components/ComplianceModal';
import { ReviewModal } from './components/ReviewModal';
import { ReportReviewModal } from './components/ReportReviewModal';
import { SupportDashboard } from './components/SupportDashboard';
import { AuthScreen } from './components/AuthScreen';
import { Footer } from './components/Footer';
import { Product, Review, Order, UserRole } from './types';
import { CheckCircle2, PackageCheck, Lock, ShieldAlert } from 'lucide-react';

function DukkanaAppContent() {
  const { role, isAuthenticated, isAdmin, isMerchant, isSupport } = useAuth();
  const { setSelectedCategorySlug, setSelectedDiscount } = useMarket();

  // Guest browse toggle when user is not logged in
  const [guestBrowse, setGuestBrowse] = useState(false);

  // Active Main View
  const [activeView, setActiveView] = useState<
    'home' | 'categories' | 'orders' | 'profile' | 'merchant' | 'admin' | 'support'
  >('home');

  // Modals & Drawers
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isComplianceOpen, setIsComplianceOpen] = useState(false);

  // Selected entities for modals
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [reviewModalData, setReviewModalData] = useState<{ productId: string; orderId: string } | null>(null);
  const [reportModalReview, setReportModalReview] = useState<Review | null>(null);

  // Order Success Toast Banner
  const [orderSuccessNotice, setOrderSuccessNotice] = useState<Order[] | null>(null);

  const handleOrderSuccess = (orders: Order[]) => {
    setOrderSuccessNotice(orders);
    setActiveView('orders');
    setTimeout(() => {
      setOrderSuccessNotice(null);
    }, 8000);
  };

  const handleNavigateCategories = (slug?: string, discount?: number) => {
    if (slug) setSelectedCategorySlug(slug);
    if (discount !== undefined) setSelectedDiscount(discount);
    setActiveView('categories');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAuthSuccess = (newRole: UserRole) => {
    setIsAuthOpen(false);
    if (newRole === 'admin') {
      setActiveView('admin');
    } else if (newRole === 'merchant') {
      setActiveView('merchant');
    } else {
      setActiveView('home');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Reset guest browse state if user logs out
  React.useEffect(() => {
    if (!isAuthenticated) {
      setGuestBrowse(false);
    }
  }, [isAuthenticated]);

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 flex flex-col font-sans selection:bg-purple-200 selection:text-purple-900">
      {/* Header */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        onOpenCompliance={() => setIsComplianceOpen(true)}
      />

      {/* Order Confirmation Toast Notification */}
      {orderSuccessNotice && (
        <div className="max-w-4xl mx-auto px-4 mt-4 w-full animate-in fade-in slide-in-from-top duration-300">
          <div className="p-4 bg-emerald-700 text-white rounded-2xl shadow-lg flex items-start gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-200 shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              <h4 className="font-black text-sm">
                تم استلام طلبك بنجاح والدفع عند الاستلام (نقداً)!
              </h4>
              <p className="mt-1 text-emerald-100">
                أرقام الطلبات الصادرة:{' '}
                <span className="font-mono font-bold text-white">
                  {orderSuccessNotice.map(o => o.id).join(' ، ')}
                </span>
                . سيتواصل معك مندوب كل متجر قبل موعد التوصيل.
              </p>
            </div>
            <button
              onClick={() => setOrderSuccessNotice(null)}
              className="text-emerald-200 hover:text-white font-bold text-sm cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main View Router with Strict Role Enforcement */}
      <main className="flex-1 pb-20 md:pb-0">
        {!isAuthenticated && !guestBrowse ? (
          <AuthScreen
            onGuestBrowse={() => setGuestBrowse(true)}
            onSuccess={handleAuthSuccess}
          />
        ) : (
          <>
            {activeView === 'home' && (
              <HomeView
                onSelectProduct={p => setSelectedProduct(p)}
                onNavigateCategories={handleNavigateCategories}
              />
            )}

            {activeView === 'categories' && (
              <CategoriesView onSelectProduct={p => setSelectedProduct(p)} />
            )}

            {activeView === 'orders' && (
              <OrdersView
                onOpenReviewModal={(productId, orderId) =>
                  setReviewModalData({ productId, orderId })
                }
              />
            )}

            {/* Merchant Dashboard: strictly restricted to verified merchants */}
            {activeView === 'merchant' && (
              isMerchant ? (
                <MerchantDashboard />
              ) : (
                <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200">
                    <Lock className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-black text-zinc-900">لوحة التاجر محمية</h2>
                  <p className="text-xs text-zinc-600 leading-relaxed">
                    هذه اللوحة مخصصة حصرياً للتجار المعتمدين في سوق دكانة لإدارة منتجاتهم والطلبات الواردة.
                  </p>
                  <button
                    onClick={() => setActiveView('home')}
                    className="px-5 py-2.5 bg-purple-700 text-white font-bold rounded-xl text-xs hover:bg-purple-800 transition cursor-pointer"
                  >
                    العودة للتسوق في دكانة
                  </button>
                </div>
              )
            )}

            {/* Admin Dashboard: strictly restricted to canonical Admin phone 07862214922 */}
            {activeView === 'admin' && (
              isAdmin ? (
                <AdminDashboard />
              ) : (
                <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-200">
                    <ShieldAlert className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-black text-zinc-900">غير مصرح بالدخول إلى لوحة المدير</h2>
                  <p className="text-xs text-zinc-600 leading-relaxed">
                    لوحة الإدارة محمية برمجياً ومخصصة حصرياً للمدير الرئيسي الوحيد لمنصة دكانة بعد تسجيل الدخول والتحقق برمز OTP من رقم الهاتف المعتمد (07862214922).
                  </p>
                  <button
                    onClick={() => setActiveView('home')}
                    className="px-5 py-2.5 bg-purple-700 text-white font-bold rounded-xl text-xs hover:bg-purple-800 transition cursor-pointer"
                  >
                    العودة للصفحة الرئيسية
                  </button>
                </div>
              )
            )}

            {/* Support Dashboard: restricted to Admin and Support team */}
            {activeView === 'support' && (
              isSupport ? (
                <SupportDashboard />
              ) : (
                <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-3xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-200">
                    <Lock className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-black text-zinc-900">لوحة فريق الدعم محمية</h2>
                  <p className="text-xs text-zinc-600 leading-relaxed">
                    هذه البوابة مخصصة لفريق خدمة العملاء والدعم الفني المعتمد المرتبط بالرقم 07862214922.
                  </p>
                  <button
                    onClick={() => setActiveView('home')}
                    className="px-5 py-2.5 bg-purple-700 text-white font-bold rounded-xl text-xs hover:bg-purple-800 transition cursor-pointer"
                  >
                    العودة للصفحة الرئيسية
                  </button>
                </div>
              )
            )}

            {activeView === 'profile' && (
              <UserProfileView
                onOpenCompliance={() => setIsComplianceOpen(true)}
                onOpenSupport={() => setIsSupportOpen(true)}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenCompliance={() => setIsComplianceOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        onNavigateHome={() => {
          setActiveView('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateCategories={() => {
          setActiveView('categories');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateOrders={() => {
          setActiveView('orders');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Mobile Fixed Bottom Navigation Bar */}
      <BottomNav
        activeView={activeView}
        setActiveView={setActiveView}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenReviewModal={(prodId, ordId) => {
          setSelectedProduct(null);
          setReviewModalData({ productId: prodId, orderId: ordId });
        }}
        onOpenReportModal={rev => setReportModalReview(rev)}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          if (!isAuthenticated) {
            setIsAuthOpen(true);
          } else {
            setIsCheckoutOpen(true);
          }
        }}
      />

      {/* Checkout Modal (COD with Split Orders) */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Phone & OTP Authentication Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={handleAuthSuccess}
      />

      {/* Support & WhatsApp Help Modal */}
      <SupportModal isOpen={isSupportOpen} onClose={() => setIsSupportOpen(false)} />

      {/* Legal & App Store Compliance Modal (Privacy, Terms, Account Deletion) */}
      <ComplianceModal
        isOpen={isComplianceOpen}
        onClose={() => setIsComplianceOpen(false)}
      />

      {/* Verified Review Submission Modal */}
      {reviewModalData && (
        <ReviewModal
          productId={reviewModalData.productId}
          orderId={reviewModalData.orderId}
          isOpen={true}
          onClose={() => setReviewModalData(null)}
        />
      )}

      {/* UGC Review Reporting Modal */}
      <ReportReviewModal
        review={reportModalReview}
        isOpen={!!reportModalReview}
        onClose={() => setReportModalReview(null)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MarketProvider>
        <DukkanaAppContent />
      </MarketProvider>
    </AuthProvider>
  );
}
