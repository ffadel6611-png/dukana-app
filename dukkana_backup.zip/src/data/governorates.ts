import { IraqiGovernorate } from '../types';

export interface GovernorateDetail {
  id: IraqiGovernorate;
  nameAr: string;
  region: 'الوسط' | 'الجنوب' | 'الشمال' | 'الفرات الأوسط' | 'الغربية' | 'إقليم كردستان';
  deliveryFee: number; // In IQD (e.g. 3,000 to 7,000 IQD)
  avgDeliveryHours: string;
}

export const IRAQI_GOVERNORATES: GovernorateDetail[] = [
  { id: 'بغداد', nameAr: 'بغداد', region: 'الوسط', deliveryFee: 4000, avgDeliveryHours: '24-48 ساعة' },
  { id: 'البصرة', nameAr: 'البصرة', region: 'الجنوب', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'نينوى', nameAr: 'نينوى (الموصل)', region: 'الشمال', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'أربيل', nameAr: 'أربيل', region: 'إقليم كردستان', deliveryFee: 6000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'الأنبار', nameAr: 'الأنبار (الرمادي)', region: 'الغربية', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'كركوك', nameAr: 'كركوك', region: 'الشمال', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'النجف', nameAr: 'النجف الأشرف', region: 'الفرات الأوسط', deliveryFee: 4500, avgDeliveryHours: '48 ساعة' },
  { id: 'كربلاء', nameAr: 'كربلاء المقدسة', region: 'الفرات الأوسط', deliveryFee: 4500, avgDeliveryHours: '48 ساعة' },
  { id: 'بابل', nameAr: 'بابل (الحلة)', region: 'الفرات الأوسط', deliveryFee: 4500, avgDeliveryHours: '48 ساعة' },
  { id: 'واسط', nameAr: 'واسط (الكوت)', region: 'الوسط', deliveryFee: 4500, avgDeliveryHours: '48 ساعة' },
  { id: 'صلاح الدين', nameAr: 'صلاح الدين (تكريت)', region: 'الوسط', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'ديالى', nameAr: 'ديالى (بعقوبة)', region: 'الوسط', deliveryFee: 4500, avgDeliveryHours: '48 ساعة' },
  { id: 'ذي قار', nameAr: 'ذي قار (الناصرية)', region: 'الجنوب', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'ميسان', nameAr: 'ميسان (العمارة)', region: 'الجنوب', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'المثنى', nameAr: 'المثنى (السماوة)', region: 'الجنوب', deliveryFee: 5000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'القادسية', nameAr: 'القادسية (الديوانية)', region: 'الفرات الأوسط', deliveryFee: 4500, avgDeliveryHours: '48 ساعة' },
  { id: 'دهوك', nameAr: 'دهوك', region: 'إقليم كردستان', deliveryFee: 6000, avgDeliveryHours: '48-72 ساعة' },
  { id: 'السليمانية', nameAr: 'السليمانية', region: 'إقليم كردستان', deliveryFee: 6000, avgDeliveryHours: '48-72 ساعة' },
];

export const GOVERNORATE_NAMES: IraqiGovernorate[] = IRAQI_GOVERNORATES.map(g => g.id);
